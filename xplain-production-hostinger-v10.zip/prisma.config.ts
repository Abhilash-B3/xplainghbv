import { defineConfig } from '@prisma/config';

export default defineConfig({
  schema: 'prisma/schema.prisma',

  migrations: {
    seed: 'npx tsx prisma/seed.ts',
  },

  datasource: {
    url:
      process.env.DATABASE_URL ||
      'postgresql://postgres:postgres@localhost:5432/xplainghbv_db?schema=public',
  },
});