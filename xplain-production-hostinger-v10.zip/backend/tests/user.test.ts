import { describe, it, expect, vi } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { AuthService } from '../src/services/auth.service.js';
import { UserService } from '../src/services/user.service.js';

describe('User Profile API (/api/v1/users/me)', () => {
  const mockSafeUser = {
    id: 'user-uuid-9999',
    email: 'abena.osei@example.com',
    phone: '+233555999999',
    role: 'INVESTOR' as const,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: false,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'profile-uuid-9999',
      fullName: 'Abena Osei',
      preferredCurrency: 'EUR' as const,
      referralCode: 'XP-ABENA1',
      kycStatus: 'NOT_SUBMITTED' as const,
      resalePlan: 'DIRECT' as const,
    },
  };

  it('should retrieve profile with GET /api/v1/users/me when authenticated', async () => {
    const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockSafeUser);
    const getProfileSpy = vi.spyOn(UserService, 'getProfile').mockResolvedValueOnce(mockSafeUser as any);

    const res = await request(app)
      .get('/api/v1/users/me')
      .set('Cookie', ['xplain_session=valid_token']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.email).toBe('abena.osei@example.com');
    expect(res.body.data.user.partnerProfile.fullName).toBe('Abena Osei');

    validateSpy.mockRestore();
    getProfileSpy.mockRestore();
  });

  it('should update profile with PATCH /api/v1/users/me when authenticated', async () => {
    const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockSafeUser);
    const updateProfileSpy = vi.spyOn(UserService, 'updateProfile').mockResolvedValueOnce({
      ...mockSafeUser,
      partnerProfile: {
        ...mockSafeUser.partnerProfile,
        fullName: 'Abena Osei Updated',
        preferredCurrency: 'GHS',
      },
    } as any);

    const res = await request(app)
      .patch('/api/v1/users/me')
      .set('Cookie', ['xplain_session=valid_token'])
      .send({
        fullName: 'Abena Osei Updated',
        preferredCurrency: 'GHS',
      });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.partnerProfile.fullName).toBe('Abena Osei Updated');
    expect(res.body.data.user.partnerProfile.preferredCurrency).toBe('GHS');

    validateSpy.mockRestore();
    updateProfileSpy.mockRestore();
  });

  it('should reject mass assignment attempts to elevate role or status with 400 VALIDATION_ERROR', async () => {
    const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockSafeUser);

    const res = await request(app)
      .patch('/api/v1/users/me')
      .set('Cookie', ['xplain_session=valid_token'])
      .send({
        fullName: 'Abena Hacked',
        role: 'SUPERADMIN',
        status: 'ACTIVE',
        balance: 1000000,
      });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');

    validateSpy.mockRestore();
  });
});
