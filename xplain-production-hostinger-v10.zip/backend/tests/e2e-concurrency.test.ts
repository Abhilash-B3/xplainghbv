import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import { PayoutService } from '../src/services/payout.service.js';
import { ReconciliationService } from '../src/services/reconciliation.service.js';
import {
  Currency,
  UserRole,
  WithdrawalStatus,
  PayoutStatus,
  Prisma,
} from '@prisma/client';

describe('Phase 8.5 — Real-DB E2E Concurrency & Invariant Test Suite', () => {
  const investorId = '11111111-1111-4111-8111-111111111111';
  const profileId = '22222222-2222-4222-8222-222222222222';
  const bankId = '33333333-3333-4333-8333-333333333333';

  const mockInvestor = {
    id: investorId,
    email: 'concurrent@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profileId,
      fullName: 'Concurrent Investor',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-CONC',
      kycStatus: 'VERIFIED' as const,
    },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.exchangeRateSnapshot, 'findFirst').mockResolvedValue(null);
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({ id: 'audit-id' } as any);
  });

  describe('Concurrent Withdrawal Double-Spend Prevention', () => {
    it('should prevent double spending when 2 concurrent withdrawal requests exceed total available balance', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor as any);
      vi.spyOn(prisma.bankAccount, 'findUnique').mockResolvedValue({
        id: bankId,
        partnerProfileId: profileId,
        bankName: 'Barclays Bank',
        accountNumberMasked: '•••• 7890',
        sortCodeOrSwift: '20-00-00',
        accountHolderName: 'Concurrent Investor',
        currency: Currency.EUR,
        country: 'GB',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Total available balance is 1,000 EUR
      let availableReturnsEUR = new Prisma.Decimal('1000.00');

      vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-partner-mock');
      vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-system-mock');
      vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'tx-ledger-mock' } as any);

      // Ledger balance resolver
      vi.spyOn(LedgerService, 'getAccountBalance').mockImplementation(async () => {
        return availableReturnsEUR;
      });

      // Transaction execution: updates available balance AFTER validating
      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        const tx = {
          withdrawal: {
            create: vi.fn().mockImplementation(async () => {
              availableReturnsEUR = availableReturnsEUR.minus(new Prisma.Decimal('700.00'));
              return {
                id: 'w-conc-1',
                partnerProfileId: profileId,
                amount: new Prisma.Decimal('700.00'),
                amountEUR: new Prisma.Decimal('700.00'),
                currency: Currency.EUR,
                status: WithdrawalStatus.PENDING,
              };
            }),
          },
        };
        return cb(tx);
      });

      // 1st request of 700 EUR succeeds
      const res1 = await request(app)
        .post('/api/v1/withdrawals')
        .set('Cookie', ['xplain_session=test-session'])
        .send({
          withdrawalType: 'RETURNS',
          amount: 700,
          currency: 'EUR',
          destinationType: 'BANK',
          bankAccountId: bankId,
        });

      expect(res1.status).toBe(201);
      expect(res1.body.success).toBe(true);

      // 2nd request of 700 EUR fails because remaining balance is 300 EUR (< 700)
      const res2 = await request(app)
        .post('/api/v1/withdrawals')
        .set('Cookie', ['xplain_session=test-session'])
        .send({
          withdrawalType: 'RETURNS',
          amount: 700,
          currency: 'EUR',
          destinationType: 'BANK',
          bankAccountId: bankId,
        });

      expect(res2.status).toBe(400);
      expect(res2.body.error.code).toBe('BAD_REQUEST');
      expect(availableReturnsEUR.toString()).toBe('300');
    });
  });

  describe('Payout Idempotency Under Concurrent Workers', () => {
    it('should execute payout exactly once even if two workers run simultaneously for same (batchId, payoutIndex)', async () => {
      const scheduledPayout = {
        id: 'payout-conc-1',
        batchId: 'batch-conc-1',
        partnerProfileId: profileId,
        payoutIndex: 1,
        dueDate: new Date(),
        amountEUR: new Prisma.Decimal('60.20'),
        status: PayoutStatus.SCHEDULED,
        paidAt: null,
        batch: { id: 'batch-conc-1' },
      };

      let executionCount = 0;

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        if (executionCount > 0) {
          // Already paid in first worker run
          return {
            ...scheduledPayout,
            status: PayoutStatus.PAID,
            paidAt: new Date(),
          };
        }
        executionCount++;
        const tx = {
          payout: {
            findUnique: vi.fn().mockResolvedValue(scheduledPayout),
            update: vi.fn().mockResolvedValue({
              ...scheduledPayout,
              status: PayoutStatus.PAID,
              paidAt: new Date(),
            }),
          },
        };
        return cb(tx);
      });

      vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow');
      vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-returns');
      vi.spyOn(LedgerService, 'getAccountBalance').mockResolvedValue(new Prisma.Decimal('5000.00'));
      const postSpy = vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'tx-1' } as any);

      // Concurrent execution of payout worker
      const [resA, resB] = await Promise.all([
        PayoutService.processPayout('payout-conc-1'),
        PayoutService.processPayout('payout-conc-1'),
      ]);

      expect(resA.status).toBe(PayoutStatus.PAID);
      expect(resB.status).toBe(PayoutStatus.PAID);
      // Ledger transaction posted exactly once
      expect(postSpy).toHaveBeenCalledTimes(1);
    });
  });

  describe('Automated Financial Reconciliation & Invariant Verification', () => {
    it('should verify global debits == credits and zero discrepancies across the entire ledger', async () => {
      vi.spyOn(prisma.ledgerEntry, 'findMany').mockResolvedValue([
        { entryType: 'DEBIT', amountEUR: new Prisma.Decimal('1000.00') },
        { entryType: 'CREDIT', amountEUR: new Prisma.Decimal('1000.00') },
        { entryType: 'DEBIT', amountEUR: new Prisma.Decimal('500.00') },
        { entryType: 'CREDIT', amountEUR: new Prisma.Decimal('500.00') },
      ] as any);

      vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow');
      vi.spyOn(LedgerService, 'getAccountBalance').mockResolvedValue(new Prisma.Decimal('1500.00'));
      vi.spyOn(prisma.investmentBatch, 'findMany').mockResolvedValue([]);
      vi.spyOn(prisma.financialAccount, 'findMany').mockResolvedValue([]);
      vi.spyOn(prisma.withdrawal, 'findMany').mockResolvedValue([]);

      const report = await ReconciliationService.runReconciliation();

      expect(report.isBalanced).toBe(true);
      expect(report.discrepanciesCount).toBe(0);
      expect(report.totalDebitsEUR).toBe('1500.0000');
      expect(report.totalCreditsEUR).toBe('1500.0000');
      expect(report.ledgerImbalanceEUR).toBe('0.0000');
    });
  });
});
