import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { ReconciliationService } from '../src/services/reconciliation.service.js';
import {
  Currency,
  UserRole,
} from '@prisma/client';

describe('Phase 7 — Admin Platform, RBAC & Reconciliation Audit', () => {
  const investorUserId = '11111111-1111-4111-8111-111111111111';
  const adminUserId = '22222222-2222-4222-8222-222222222222';
  const targetUserId = '44444444-4444-4444-8444-444444444444';

  const mockInvestor = {
    id: investorUserId,
    email: 'investor@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'prof-investor',
      fullName: 'Investor User',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-INV',
      kycStatus: 'VERIFIED' as const,
    },
  };

  const mockAdmin = {
    id: adminUserId,
    email: 'admin@xplain.com',
    phone: '+447500000002',
    role: UserRole.ADMIN,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'prof-admin',
      fullName: 'Admin User',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-ADM',
      kycStatus: 'VERIFIED' as const,
    },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({ id: 'audit-id' } as any);
  });

  describe('RBAC Gating', () => {
    it('should reject unauthenticated access to admin endpoints with 401', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(null);

      const res = await request(app).get('/api/v1/admin/users');
      expect(res.status).toBe(401);
    });

    it('should reject INVESTOR access to admin endpoints with 403 Forbidden', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor as any);

      const res = await request(app)
        .get('/api/v1/admin/users')
        .set('Cookie', ['xplain_session=test-session-investor']);

      expect(res.status).toBe(403);
      expect(res.body.error.code).toBe('FORBIDDEN');
    });

    it('should allow ADMIN access to admin endpoints', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockAdmin as any);
      vi.spyOn(prisma.user, 'findMany').mockResolvedValue([]);
      vi.spyOn(prisma.user, 'count').mockResolvedValue(0);

      const res = await request(app)
        .get('/api/v1/admin/users')
        .set('Cookie', ['xplain_session=test-session-admin']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });
  });

  describe('Admin Operations', () => {
    it('should update user status with audit trail', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockAdmin as any);
      vi.spyOn(prisma.user, 'findUnique').mockResolvedValue({
        id: targetUserId,
        email: 'target@xplain.com',
        phone: '+447900000000',
        role: UserRole.INVESTOR,
        status: 'ACTIVE',
        isEmailVerified: true,
        isPhoneVerified: true,
        twoFactorEnabled: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      vi.spyOn(prisma.user, 'update').mockResolvedValue({
        id: targetUserId,
        email: 'target@xplain.com',
        phone: '+447900000000',
        role: UserRole.INVESTOR,
        status: 'SUSPENDED',
        isEmailVerified: true,
        isPhoneVerified: true,
        twoFactorEnabled: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const res = await request(app)
        .patch(`/api/v1/admin/users/${targetUserId}/status`)
        .set('Cookie', ['xplain_session=test-session-admin'])
        .send({ status: 'SUSPENDED' });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('SUSPENDED');
    });

    it('should return automated financial reconciliation report', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockAdmin as any);
      vi.spyOn(ReconciliationService, 'runReconciliation').mockResolvedValue({
        timestamp: new Date().toISOString(),
        isBalanced: true,
        totalDebitsEUR: '10000.00',
        totalCreditsEUR: '10000.00',
        ledgerImbalanceEUR: '0.00',
        platformEscrowBalanceEUR: '10000.00',
        lockedCapitalBalanceEUR: '8000.00',
        totalActiveBatchesCapitalEUR: '8000.00',
        capitalDiscrepancyEUR: '0.00',
        withdrawalReservedBalanceEUR: '500.00',
        pendingWithdrawalsSumEUR: '500.00',
        withdrawalReservationDiscrepancyEUR: '0.00',
        discrepanciesCount: 0,
        discrepancies: [],
      });

      const res = await request(app)
        .get('/api/v1/admin/reconciliation/report')
        .set('Cookie', ['xplain_session=test-session-admin']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.isBalanced).toBe(true);
      expect(res.body.data.discrepanciesCount).toBe(0);
      expect(res.body.data.ledgerImbalanceEUR).toBe('0.00');
    });
  });
});
