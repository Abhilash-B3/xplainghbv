import { describe, it, expect } from 'vitest';
import { hashPassword, verifyPassword, validatePasswordStrength } from '../src/utils/password.js';

describe('Password Utility (Argon2id)', () => {
  it('should hash password and produce valid Argon2id hash', async () => {
    const rawPassword = 'SecretPassword123';
    const hash = await hashPassword(rawPassword);

    expect(hash).toBeDefined();
    expect(typeof hash).toBe('string');
    expect(hash.startsWith('$argon2id$')).toBe(true);
  });

  it('should verify correct password successfully', async () => {
    const rawPassword = 'CorrectPassword99';
    const hash = await hashPassword(rawPassword);

    const isMatch = await verifyPassword(rawPassword, hash);
    expect(isMatch).toBe(true);
  });

  it('should reject incorrect password', async () => {
    const rawPassword = 'CorrectPassword99';
    const hash = await hashPassword(rawPassword);

    const isMatch = await verifyPassword('WrongPassword123', hash);
    expect(isMatch).toBe(false);
  });

  it('should validate password complexity requirements correctly', () => {
    expect(validatePasswordStrength('short').isValid).toBe(false);
    expect(validatePasswordStrength('alllowercase123').isValid).toBe(false);
    expect(validatePasswordStrength('ALLUPPERCASE123').isValid).toBe(false);
    expect(validatePasswordStrength('NoNumbersHere').isValid).toBe(false);
    expect(validatePasswordStrength('ValidPassword1').isValid).toBe(true);
  });
});
