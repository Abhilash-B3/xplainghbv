import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { stripeClient } from '../src/config/stripe.js';
import { AuthService } from '../src/services/auth.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import {
  ResalePlan,
  Currency,
  InvestmentStatus,
  Prisma,
  UserRole,
  PaymentProvider,
  TransactionType,
  TransactionStatus,
  EntryType,
  AccountType,
} from '@prisma/client';

describe('Phase 6 Final Verification Audit Suite', () => {
  const userAId = '11111111-1111-4111-8111-111111111111';
  const profileAId = '22222222-2222-4222-8222-222222222222';
  const userBId = '33333333-3333-4333-8333-333333333333';
  const profileBId = '44444444-4444-4444-8444-444444444444';
  
  const investmentAId = '55555555-5555-4555-8555-555555555555';
  const paymentTxAId = '66666666-6666-4666-8666-666666666666';
  const paymentIntentAId = 'pi_test_userA_investment_1050';

  const mockUserA = {
    id: userAId,
    email: 'usera@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profileAId,
      fullName: 'User A',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-USERA',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockUserB = {
    id: userBId,
    email: 'userb@xplain.com',
    phone: '+447400000002',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profileBId,
      fullName: 'User B',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-USERB',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockInvestmentA = {
    id: investmentAId,
    partnerProfileId: profileAId,
    resalePlan: ResalePlan.SELLFOR,
    status: InvestmentStatus.PAYMENT_PENDING,
    currency: Currency.EUR,
    subtotalInCurrency: new Prisma.Decimal('1050.00'),
    discountAmountInCurrency: new Prisma.Decimal('147.00'), // 14% wholesale discount
    totalAmountInCurrency: new Prisma.Decimal('903.00'),
    totalAmountEUR: new Prisma.Decimal('903.00'),
    exchangeRateToEUR: new Prisma.Decimal('1.00000000'),
    deliveryAddressId: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    paymentTransactions: [
      {
        id: paymentTxAId,
        referenceNumber: 'TX-INV-AUDIT-001',
        investmentId: investmentAId,
        partnerProfileId: profileAId,
        provider: PaymentProvider.STRIPE,
        providerTransactionId: null,
        stripePaymentIntentId: null,
        stripeCustomerId: null,
        stripePaymentStatus: null,
        stripeLatestEventId: null,
        type: TransactionType.DEPOSIT,
        amount: new Prisma.Decimal('903.00'),
        currency: Currency.EUR,
        canonicalAmountEUR: new Prisma.Decimal('903.00'),
        status: TransactionStatus.PENDING,
        paidAt: null,
        failureCode: null,
        failureMessage: null,
        idempotencyKey: null,
        providerMetadata: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ],
    items: [],
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({} as any);
    vi.spyOn(prisma.stripePaymentEvent, 'create').mockResolvedValue({} as any);
  });

  // ─── 1. End-to-End Stripe Test Mode Successful Payment Flow ────────
  it('1. End-to-end Stripe card payment: Intent -> Webhook -> Succeeded -> Investment Activated -> Balanced Ledger', async () => {
    // Step 1: User A requests PaymentIntent for their investment
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUserA as any);
    vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(mockInvestmentA as any);
    vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);

    const mockStripeIntent = {
      id: paymentIntentAId,
      client_secret: `${paymentIntentAId}_secret_test_4242`,
      status: 'requires_payment_method',
      amount: 90300, // 903.00 EUR in cents
      currency: 'eur',
    };

    vi.spyOn(stripeClient.paymentIntents, 'create').mockResolvedValue(mockStripeIntent as any);

    const intentRes = await request(app)
      .post('/api/v1/payments/create-intent')
      .set('Cookie', ['xplain_session=token-user-a'])
      .send({ investmentId: investmentAId });

    expect(intentRes.status).toBe(200);
    expect(intentRes.body.success).toBe(true);
    expect(intentRes.body.data.clientSecret).toBe(`${paymentIntentAId}_secret_test_4242`);
    expect(intentRes.body.data.amount).toBe('903');

    // Step 2: Stripe webhook payment_intent.succeeded arrives
    const webhookEvent = {
      id: 'evt_e2e_test_4242_success',
      type: 'payment_intent.succeeded',
      data: {
        object: {
          id: paymentIntentAId,
          amount: 90300,
          currency: 'eur',
          status: 'succeeded',
          metadata: {
            paymentTransactionId: paymentTxAId,
            investmentId: investmentAId,
          },
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(webhookEvent as any);
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
    vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue({
      ...mockInvestmentA.paymentTransactions[0],
      investment: mockInvestmentA,
    } as any);

    const txMock = {
      paymentTransaction: { update: vi.fn().mockResolvedValue({}) },
      investment: { update: vi.fn().mockResolvedValue({}) },
      investmentBatch: { create: vi.fn().mockResolvedValue({ id: 'batch-e2e' }) },
      payout: { createMany: vi.fn().mockResolvedValue({}) },
      stripePaymentEvent: { create: vi.fn().mockResolvedValue({}) },
      auditLog: { create: vi.fn().mockResolvedValue({}) },
    };

    vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => cb(txMock));
    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow-e2e');
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-locked-e2e');
    const ledgerSpy = vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'lt-e2e' } as any);

    const webhookRes = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(webhookEvent));

    expect(webhookRes.status).toBe(200);
    expect(webhookRes.body.received).toBe(true);

    // Verify atomic updates
    expect(txMock.paymentTransaction.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: TransactionStatus.SUCCESSFUL, stripePaymentStatus: 'succeeded' }),
      })
    );
    expect(txMock.investment.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: { status: InvestmentStatus.ACTIVE } })
    );
    expect(txMock.investmentBatch.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          investmentId: investmentAId,
          capitalEUR: mockInvestmentA.totalAmountEUR,
          lockDurationMonths: 12,
        }),
      })
    );
    expect(txMock.payout.createMany).toHaveBeenCalled();

    // Verify balanced ledger entry: Debits === Credits
    expect(ledgerSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        sourceEntityId: investmentAId,
        entries: [
          expect.objectContaining({ accountId: 'acc-escrow-e2e', entryType: EntryType.DEBIT }),
          expect.objectContaining({ accountId: 'acc-locked-e2e', entryType: EntryType.CREDIT }),
        ],
      }),
      expect.anything()
    );
  });

  // ─── 2. 3DS Authentication Required Test ───────────────────────────
  it('2. 3DS / Authentication required test (4000 0025 0000 3155): Payment remains pending and does not activate investment', async () => {
    const processingEvent = {
      id: 'evt_3ds_processing',
      type: 'payment_intent.processing',
      data: {
        object: {
          id: paymentIntentAId,
          status: 'processing',
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(processingEvent as any);
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
    vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockInvestmentA.paymentTransactions[0] as any);
    const updateSpy = vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);
    const invUpdateSpy = vi.spyOn(prisma.investment, 'update');

    const res = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(processingEvent));

    expect(res.status).toBe(200);
    expect(updateSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ stripePaymentStatus: 'processing' }),
      })
    );
    // Investment must NOT become active during 3DS processing
    expect(invUpdateSpy).not.toHaveBeenCalled();
  });

  // ─── 3. Declined Card Test ─────────────────────────────────────────
  it('3. Declined card test (4000 0000 0000 9995): Marks transaction FAILED, investment remains inactive, safe for retry', async () => {
    const failedEvent = {
      id: 'evt_declined_9995',
      type: 'payment_intent.payment_failed',
      data: {
        object: {
          id: paymentIntentAId,
          status: 'requires_payment_method',
          last_payment_error: {
            code: 'card_declined',
            message: 'Your card was declined.',
          },
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(failedEvent as any);
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
    vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockInvestmentA.paymentTransactions[0] as any);
    const updateSpy = vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);
    const invUpdateSpy = vi.spyOn(prisma.investment, 'update');

    const res = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(failedEvent));

    expect(res.status).toBe(200);
    expect(updateSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          status: TransactionStatus.FAILED,
          failureCode: 'card_declined',
          failureMessage: 'Your card was declined.',
        }),
      })
    );
    expect(invUpdateSpy).not.toHaveBeenCalled();
  });

  // ─── 4. Duplicate & Concurrent Webhook Test ────────────────────────
  it('4. Duplicate & Concurrent webhook delivery: Safely skipped by database unique eventId constraint without duplicate settlement', async () => {
    const duplicateEvent = {
      id: 'evt_duplicate_id_001',
      type: 'payment_intent.succeeded',
      data: {
        object: {
          id: paymentIntentAId,
          amount: 90300,
          currency: 'eur',
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(duplicateEvent as any);
    
    // Simulate eventId already recorded in PostgreSQL
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue({
      id: 'event-uuid-dup',
      eventId: 'evt_duplicate_id_001',
      eventType: 'payment_intent.succeeded',
      status: 'PROCESSED',
      errorMessage: null,
      paymentIntentId: paymentIntentAId,
      processedAt: new Date(),
      createdAt: new Date(),
    });

    const txSpy = vi.spyOn(prisma, '$transaction');

    const res = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(duplicateEvent));

    expect(res.status).toBe(200);
    expect(res.body.duplicate).toBe(true);
    // Database transaction must NOT execute a second time
    expect(txSpy).not.toHaveBeenCalled();
  });

  // ─── 5. Amount Tampering Rejection ─────────────────────────────────
  it('5. Amount tampering test: Rejects client-supplied amount or webhook amount discrepancy with security audit', async () => {
    const tamperedEvent = {
      id: 'evt_tampered_amount',
      type: 'payment_intent.succeeded',
      data: {
        object: {
          id: paymentIntentAId,
          amount: 10000, // 100.00 EUR instead of 903.00 EUR
          currency: 'eur',
          metadata: {
            paymentTransactionId: paymentTxAId,
            investmentId: investmentAId,
          },
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(tamperedEvent as any);
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
    vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue({
      ...mockInvestmentA.paymentTransactions[0],
      investment: mockInvestmentA,
    } as any);

    const eventCreateSpy = vi.spyOn(prisma.stripePaymentEvent, 'create').mockResolvedValue({} as any);
    const txSpy = vi.spyOn(prisma, '$transaction');

    const res = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(tamperedEvent));

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.message).toContain('amount mismatch');
    expect(eventCreateSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'AMOUNT_MISMATCH_REJECTED' }),
      })
    );
    expect(txSpy).not.toHaveBeenCalled();
  });

  // ─── 6. Currency Tampering Rejection ───────────────────────────────
  it('6. Currency tampering test: Rejects currency modification with security audit without silent conversion', async () => {
    const tamperedCurrencyEvent = {
      id: 'evt_tampered_currency',
      type: 'payment_intent.succeeded',
      data: {
        object: {
          id: paymentIntentAId,
          amount: 90300,
          currency: 'usd', // USD instead of frozen EUR
          metadata: {
            paymentTransactionId: paymentTxAId,
            investmentId: investmentAId,
          },
        },
      },
    };

    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(tamperedCurrencyEvent as any);
    vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
    vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue({
      ...mockInvestmentA.paymentTransactions[0],
      investment: mockInvestmentA,
    } as any);

    const eventCreateSpy = vi.spyOn(prisma.stripePaymentEvent, 'create').mockResolvedValue({} as any);
    const txSpy = vi.spyOn(prisma, '$transaction');

    const res = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=valid_sig')
      .send(JSON.stringify(tamperedCurrencyEvent));

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.message).toContain('currency mismatch');
    expect(eventCreateSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'CURRENCY_MISMATCH_REJECTED' }),
      })
    );
    expect(txSpy).not.toHaveBeenCalled();
  });

  // ─── 7. IDOR Protection Test ───────────────────────────────────────
  it('7. IDOR test: User B cannot create PaymentIntent or query User A investment payment', async () => {
    // User B tries to create a PaymentIntent for User A's investment
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUserB as any);
    vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(mockInvestmentA as any);

    const createRes = await request(app)
      .post('/api/v1/payments/create-intent')
      .set('Cookie', ['xplain_session=token-user-b'])
      .send({ investmentId: investmentAId });

    expect(createRes.status).toBe(403);
    expect(createRes.body.success).toBe(false);
    expect(createRes.body.error.code).toBe('FORBIDDEN');

    // User B tries to query User A's payment transaction status
    vi.spyOn(prisma.paymentTransaction, 'findUnique').mockResolvedValue({
      ...mockInvestmentA.paymentTransactions[0],
      investment: mockInvestmentA,
    } as any);

    const getRes = await request(app)
      .get(`/api/v1/payments/${paymentTxAId}`)
      .set('Cookie', ['xplain_session=token-user-b']);

    expect(getRes.status).toBe(403);
    expect(getRes.body.success).toBe(false);
    expect(getRes.body.error.code).toBe('FORBIDDEN');
  });

  // ─── 8. Webhook Cryptographic Signature Test ──────────────────────
  it('8. Webhook signature test: Rejects missing signature, invalid signature, and malformed payload', async () => {
    // Missing header
    const noHeaderRes = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .send(JSON.stringify({ id: 'evt_no_header' }));

    expect(noHeaderRes.status).toBe(400);
    expect(noHeaderRes.body.error.code).toBe('BAD_REQUEST');

    // Invalid signature
    vi.spyOn(stripeClient.webhooks, 'constructEvent').mockImplementation(() => {
      throw new Error('signature verification failed');
    });

    const badSigRes = await request(app)
      .post('/api/v1/webhooks/stripe')
      .set('Content-Type', 'application/json')
      .set('Stripe-Signature', 't=123,v1=bad_signature')
      .send(JSON.stringify({ id: 'evt_bad_sig' }));

    expect(badSigRes.status).toBe(400);
    expect(badSigRes.body.error.message).toContain('signature verification failed');
  });

  // ─── 9. Double-Entry Financial Ledger Audit ────────────────────────
  it('9. Double-Entry Ledger Invariant: Total Debits === Total Credits strictly verified for funding settlement', async () => {
    const entries = [
      {
        accountId: 'acc-system-escrow',
        entryType: EntryType.DEBIT,
        amount: new Prisma.Decimal('903.00'),
        currency: Currency.EUR,
        amountEUR: new Prisma.Decimal('903.0000'),
      },
      {
        accountId: 'acc-partner-locked-capital',
        entryType: EntryType.CREDIT,
        amount: new Prisma.Decimal('903.00'),
        currency: Currency.EUR,
        amountEUR: new Prisma.Decimal('903.0000'),
      },
    ];

    const txMock = {
      ledgerTransaction: {
        findUnique: vi.fn().mockResolvedValue(null),
        create: vi.fn().mockResolvedValue({ id: 'lt-audit-1', referenceNumber: 'LEDGER-FUND-AUDIT-001' }),
      },
      ledgerEntry: {
        createMany: vi.fn().mockResolvedValue({ count: 2 }),
      },
    };

    const result = await LedgerService.postTransaction(
      {
        referenceNumber: 'LEDGER-FUND-AUDIT-001',
        description: 'Stripe funding settlement audit',
        sourceEntity: 'Investment',
        sourceEntityId: investmentAId,
        entries,
      },
      txMock as any
    );

    expect(result).toBeDefined();
    expect(txMock.ledgerTransaction.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ referenceNumber: 'LEDGER-FUND-AUDIT-001' }),
      })
    );
    expect(txMock.ledgerEntry.createMany).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.arrayContaining([
          expect.objectContaining({ entryType: EntryType.DEBIT, amountEUR: new Prisma.Decimal('903.0000') }),
          expect.objectContaining({ entryType: EntryType.CREDIT, amountEUR: new Prisma.Decimal('903.0000') }),
        ]),
      })
    );
  });
});
