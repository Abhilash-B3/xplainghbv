import { describe, it, expect } from 'vitest';
import request from 'supertest';
import express, { type Express } from 'express';
import { z } from 'zod';
import { app } from '../src/app.js';
import { AppError } from '../src/utils/appError.js';
import { errorHandler } from '../src/middleware/errorHandler.js';
import { validate } from '../src/middleware/validate.js';
import { requestIdMiddleware } from '../src/middleware/requestId.js';

describe('Error Handling & 404 Middleware', () => {
  it('should return 404 NOT_FOUND for unknown routes', async () => {
    const res = await request(app).get('/api/v1/nonexistent-endpoint-xyz');

    expect(res.status).toBe(404);
    expect(res.body).toHaveProperty('success', false);
    expect(res.body.error).toHaveProperty('code', 'NOT_FOUND');
    expect(res.body.error.message).toContain('Cannot GET /api/v1/nonexistent-endpoint-xyz');
    expect(res.headers).toHaveProperty('x-request-id');
  });

  it('should handle malformed JSON gracefully with 400 BAD_REQUEST', async () => {
    const res = await request(app)
      .post('/api/v1/health')
      .set('Content-Type', 'application/json')
      .send('{ "invalidJson": broken }');

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty('success', false);
    expect(res.body.error.code).toBe('BAD_REQUEST');
  });

  it('should format Zod validation errors with 400 VALIDATION_ERROR and field details', async () => {
    const testApp: Express = express();
    testApp.use(express.json());
    testApp.use(requestIdMiddleware);

    const testSchema = z.object({
      email: z.string().email('Invalid email address format'),
      amount: z.number().positive('Amount must be positive'),
    });

    testApp.post(
      '/test-validate',
      validate({ body: testSchema }),
      (_req, res) => {
        res.json({ success: true });
      }
    );

    testApp.use(errorHandler);

    const res = await request(testApp)
      .post('/test-validate')
      .send({ email: 'not-an-email', amount: -50 });

    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty('success', false);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(Array.isArray(res.body.error.details)).toBe(true);
    expect(res.body.error.details.length).toBeGreaterThanOrEqual(2);
  });

  it('should correctly map AppError subclasses to HTTP status codes', async () => {
    const testApp: Express = express();
    testApp.use(requestIdMiddleware);

    testApp.get('/test-unauthorized', () => {
      throw AppError.unauthorized('Session token has expired');
    });

    testApp.get('/test-forbidden', () => {
      throw AppError.forbidden('Requires ADMIN role');
    });

    testApp.get('/test-conflict', () => {
      throw AppError.conflict('Email address already registered');
    });

    testApp.use(errorHandler);

    const res401 = await request(testApp).get('/test-unauthorized');
    expect(res401.status).toBe(401);
    expect(res401.body.error.code).toBe('UNAUTHORIZED');

    const res403 = await request(testApp).get('/test-forbidden');
    expect(res403.status).toBe(403);
    expect(res403.body.error.code).toBe('FORBIDDEN');

    const res409 = await request(testApp).get('/test-conflict');
    expect(res409.status).toBe(409);
    expect(res409.body.error.code).toBe('CONFLICT');
  });
});
