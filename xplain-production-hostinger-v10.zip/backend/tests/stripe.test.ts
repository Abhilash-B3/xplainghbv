import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { stripeClient } from '../src/config/stripe.js';
import {
  ResalePlan,
  Currency,
  InvestmentStatus,
  Prisma,
  UserRole,
  PaymentProvider,
  TransactionType,
  TransactionStatus,
} from '@prisma/client';

describe('Stripe Payment & PaymentIntent API (/api/v1/payments)', () => {
  const investor1Id = '11111111-1111-4111-8111-111111111111';
  const profile1Id = '22222222-2222-4222-8222-222222222222';
  const investor2Id = '33333333-3333-4333-8333-333333333333';
  const profile2Id = '44444444-4444-4444-8444-444444444444';
  const investment1Id = '55555555-5555-4555-8555-555555555555';
  const paymentTx1Id = '66666666-6666-4666-8666-666666666666';

  const mockInvestor1 = {
    id: investor1Id,
    email: 'investor1@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profile1Id,
      fullName: 'Investor One',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-INV1',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockInvestor2 = {
    id: investor2Id,
    email: 'investor2@xplain.com',
    phone: '+447400000002',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profile2Id,
      fullName: 'Investor Two',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-INV2',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockInvestment = {
    id: investment1Id,
    partnerProfileId: profile1Id,
    resalePlan: ResalePlan.SELLFOR,
    status: InvestmentStatus.PAYMENT_PENDING,
    currency: Currency.EUR,
    subtotalInCurrency: new Prisma.Decimal('1000.00'),
    discountAmountInCurrency: new Prisma.Decimal('140.00'),
    totalAmountInCurrency: new Prisma.Decimal('860.00'),
    totalAmountEUR: new Prisma.Decimal('860.00'),
    exchangeRateToEUR: new Prisma.Decimal('1.00000000'),
    deliveryAddressId: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    paymentTransactions: [
      {
        id: paymentTx1Id,
        referenceNumber: 'TX-INV-TEST-001',
        investmentId: investment1Id,
        partnerProfileId: profile1Id,
        provider: PaymentProvider.STRIPE,
        providerTransactionId: null,
        stripePaymentIntentId: null,
        stripeCustomerId: null,
        stripePaymentStatus: null,
        stripeLatestEventId: null,
        type: TransactionType.DEPOSIT,
        amount: new Prisma.Decimal('860.00'),
        currency: Currency.EUR,
        canonicalAmountEUR: new Prisma.Decimal('860.00'),
        status: TransactionStatus.PENDING,
        paidAt: null,
        failureCode: null,
        failureMessage: null,
        idempotencyKey: null,
        providerMetadata: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ],
    items: [],
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({} as any);
  });

  describe('POST /api/v1/payments/create-intent', () => {
    it('should reject unauthenticated request with 401 UNAUTHORIZED', async () => {
      const res = await request(app)
        .post('/api/v1/payments/create-intent')
        .send({ investmentId: investment1Id });

      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('UNAUTHORIZED');
    });

    it('should reject when user does not own the investment with 403 FORBIDDEN (IDOR protection)', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor2 as any);
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(mockInvestment as any);

      const res = await request(app)
        .post('/api/v1/payments/create-intent')
        .set('Cookie', ['xplain_session=token-investor-2'])
        .send({ investmentId: investment1Id });

      expect(res.status).toBe(403);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('FORBIDDEN');
    });

    it('should create a Stripe PaymentIntent using server-authoritative frozen amount', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor1 as any);
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(mockInvestment as any);
      vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);

      const mockStripeIntent = {
        id: 'pi_test_1234567890',
        client_secret: 'pi_test_1234567890_secret_abc123',
        status: 'requires_payment_method',
        amount: 86000,
        currency: 'eur',
      };

      const stripeCreateSpy = vi
        .spyOn(stripeClient.paymentIntents, 'create')
        .mockResolvedValue(mockStripeIntent as any);

      const res = await request(app)
        .post('/api/v1/payments/create-intent')
        .set('Cookie', ['xplain_session=token-investor-1'])
        .send({ investmentId: investment1Id });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.clientSecret).toBe('pi_test_1234567890_secret_abc123');
      expect(res.body.data.paymentTransactionId).toBe(paymentTx1Id);
      expect(res.body.data.currency).toBe(Currency.EUR);
      expect(res.body.data.amount).toBe('860');

      // Verify Stripe SDK call parameters: card only, exact cents (860.00 EUR -> 86000 cents)
      expect(stripeCreateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          amount: 86000,
          currency: 'eur',
          payment_method_types: ['card'],
          metadata: expect.objectContaining({
            investmentId: investment1Id,
            paymentTransactionId: paymentTx1Id,
          }),
        }),
        expect.any(Object)
      );
    });

    it('should reject intent creation if investment is already ACTIVE with 409 CONFLICT', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor1 as any);
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue({
        ...mockInvestment,
        status: InvestmentStatus.ACTIVE,
      } as any);

      const res = await request(app)
        .post('/api/v1/payments/create-intent')
        .set('Cookie', ['xplain_session=token-investor-1'])
        .send({ investmentId: investment1Id });

      expect(res.status).toBe(409);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('CONFLICT');
    });

    it('should reuse existing active Stripe PaymentIntent if one already exists and is pending', async () => {
      const investmentWithExistingIntent = {
        ...mockInvestment,
        paymentTransactions: [
          {
            ...mockInvestment.paymentTransactions[0],
            stripePaymentIntentId: 'pi_existing_99999',
          },
        ],
      };

      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor1 as any);
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(investmentWithExistingIntent as any);

      const mockExistingIntent = {
        id: 'pi_existing_99999',
        client_secret: 'pi_existing_99999_secret_xyz789',
        status: 'requires_payment_method',
      };

      const retrieveSpy = vi
        .spyOn(stripeClient.paymentIntents, 'retrieve')
        .mockResolvedValue(mockExistingIntent as any);

      const createSpy = vi.spyOn(stripeClient.paymentIntents, 'create');

      const res = await request(app)
        .post('/api/v1/payments/create-intent')
        .set('Cookie', ['xplain_session=token-investor-1'])
        .send({ investmentId: investment1Id });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.clientSecret).toBe('pi_existing_99999_secret_xyz789');
      expect(retrieveSpy).toHaveBeenCalledWith('pi_existing_99999');
      expect(createSpy).not.toHaveBeenCalled();
    });
  });

  describe('GET /api/v1/payments/:paymentTransactionId', () => {
    it('should reject unauthenticated request with 401 UNAUTHORIZED', async () => {
      const res = await request(app).get(`/api/v1/payments/${paymentTx1Id}`);
      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('UNAUTHORIZED');
    });

    it('should reject when user does not own payment transaction with 403 FORBIDDEN', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor2 as any);
      vi.spyOn(prisma.paymentTransaction, 'findUnique').mockResolvedValue({
        ...mockInvestment.paymentTransactions[0],
        investment: {
          id: investment1Id,
          status: InvestmentStatus.PAYMENT_PENDING,
          resalePlan: ResalePlan.SELLFOR,
          totalAmountEUR: new Prisma.Decimal('860.00'),
        },
      } as any);

      const res = await request(app)
        .get(`/api/v1/payments/${paymentTx1Id}`)
        .set('Cookie', ['xplain_session=token-investor-2']);

      expect(res.status).toBe(403);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('FORBIDDEN');
    });

    it('should return safe payment transaction details for owner', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor1 as any);
      vi.spyOn(prisma.paymentTransaction, 'findUnique').mockResolvedValue({
        ...mockInvestment.paymentTransactions[0],
        status: TransactionStatus.SUCCESSFUL,
        paidAt: new Date(),
        stripePaymentStatus: 'succeeded',
        investment: {
          id: investment1Id,
          status: InvestmentStatus.ACTIVE,
          resalePlan: ResalePlan.SELLFOR,
          totalAmountEUR: new Prisma.Decimal('860.00'),
        },
      } as any);

      const res = await request(app)
        .get(`/api/v1/payments/${paymentTx1Id}`)
        .set('Cookie', ['xplain_session=token-investor-1']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.id).toBe(paymentTx1Id);
      expect(res.body.data.status).toBe('SUCCESSFUL');
      expect(res.body.data.stripePaymentStatus).toBe('succeeded');
      expect(res.body.data.investment.status).toBe('ACTIVE');
    });
  });
});
