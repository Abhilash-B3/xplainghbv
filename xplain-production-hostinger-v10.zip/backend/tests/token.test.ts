import { describe, it, expect } from 'vitest';
import { generateSecureToken, hashToken } from '../src/utils/token.js';

describe('Token Utility', () => {
  it('should generate secure 32-byte (64 hex char) random token', () => {
    const token1 = generateSecureToken(32);
    const token2 = generateSecureToken(32);

    expect(token1.length).toBe(64);
    expect(token2.length).toBe(64);
    expect(token1).not.toBe(token2);
  });

  it('should deterministically produce SHA-256 hash', () => {
    const rawToken = 'my_fixed_raw_token_value_for_testing';
    const hash1 = hashToken(rawToken);
    const hash2 = hashToken(rawToken);

    expect(hash1).toBe(hash2);
    expect(hash1.length).toBe(64);
  });
});
