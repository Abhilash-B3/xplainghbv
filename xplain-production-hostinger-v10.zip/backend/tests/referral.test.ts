import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { ReferralService } from '../src/services/referral.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import {
  Currency,
  UserRole,
  ReferralStatus,
  Prisma,
} from '@prisma/client';

describe('Phase 7 — Referral Engine & 3% Monthly Commission Tests', () => {
  const referrerUserId = '11111111-1111-4111-8111-111111111111';
  const referrerProfileId = '22222222-2222-4222-8222-222222222222';
  const refereeUserId = '33333333-3333-4333-8333-333333333333';
  const refereeProfileId = '44444444-4444-4444-8444-444444444444';
  const referralId = '55555555-5555-4555-8555-555555555555';

  const mockReferrer = {
    id: referrerUserId,
    email: 'referrer@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: referrerProfileId,
      fullName: 'Referrer Boss',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-BOSS',
      kycStatus: 'VERIFIED' as const,
    },
  };

  const mockReferee = {
    id: refereeUserId,
    email: 'referee@xplain.com',
    phone: '+447400000002',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: refereeProfileId,
      fullName: 'Referee User',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-NEWBIE',
      kycStatus: 'VERIFIED' as const,
    },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.exchangeRateSnapshot, 'findFirst').mockResolvedValue(null);
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({ id: 'audit-id' } as any);
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-partner-mock');
    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-system-mock');
    vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'tx-ledger-mock' } as any);
  });

  describe('Referral Attribution & Anti-Self-Referral', () => {
    it('should successfully attribute referee to valid referrer code', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockReferee as any);
      vi.spyOn(prisma.partnerProfile, 'findUnique').mockResolvedValue({
        id: referrerProfileId,
        referralCode: 'XP-BOSS',
        userId: referrerUserId,
      } as any);
      vi.spyOn(prisma.referral, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.referral, 'create').mockResolvedValue({
        id: referralId,
        referrerProfileId: referrerProfileId,
        refereeProfileId,
        status: ReferralStatus.REGISTERED,
        attributionDate: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
        referrer: { fullName: 'Referrer Boss', referralCode: 'XP-BOSS' },
      } as any);

      const res = await request(app)
        .post('/api/v1/referrals/attribute')
        .set('Cookie', ['xplain_session=test-session-referee'])
        .send({ referralCode: 'XP-BOSS' });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
    });

    it('should reject self-referral attempts', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockReferrer as any);
      vi.spyOn(prisma.partnerProfile, 'findUnique').mockResolvedValue({
        id: referrerProfileId, // Same ID as user's partnerProfile
        referralCode: 'XP-BOSS',
        userId: referrerUserId,
      } as any);

      const res = await request(app)
        .post('/api/v1/referrals/attribute')
        .set('Cookie', ['xplain_session=test-session-referrer'])
        .send({ referralCode: 'XP-BOSS' });

      expect(res.status).toBe(400);
      expect(res.body.error.code).toBe('BAD_REQUEST');
    });

    it('should reject non-existent referral code', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockReferee as any);
      vi.spyOn(prisma.partnerProfile, 'findUnique').mockResolvedValue(null);

      const res = await request(app)
        .post('/api/v1/referrals/attribute')
        .set('Cookie', ['xplain_session=test-session-referee'])
        .send({ referralCode: 'XP-NONEXISTENT' });

      expect(res.status).toBe(404);
      expect(res.body.error.code).toBe('NOT_FOUND');
    });
  });

  describe('Referral Summary & Economics', () => {
    it('should calculate monthly estimated bonus and summary accurately', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockReferrer as any);
      vi.spyOn(prisma.partnerProfile, 'findUnique').mockResolvedValue({
        id: referrerProfileId,
        referralCode: 'XP-BOSS',
        preferredCurrency: Currency.EUR,
        referees: [
          {
            id: referralId,
            attributionDate: new Date('2026-08-01'),
            referee: {
              fullName: 'Referee User',
              preferredCurrency: Currency.EUR,
              createdAt: new Date('2026-08-01'),
              investmentBatches: [
                {
                  capitalEUR: new Prisma.Decimal('1000.00'),
                },
              ],
            },
          },
        ],
        commissionsEarned: [
          {
            id: 'comm-1',
            periodMonth: '2026-08',
            refereeCapitalEUR: new Prisma.Decimal('1000.00'),
            commissionAmountEUR: new Prisma.Decimal('30.00'),
            status: 'PAID',
            paidAt: new Date('2026-08-31'),
            referee: { fullName: 'Referee User' },
          },
        ],
      } as any);

      const res = await request(app)
        .get('/api/v1/referrals/summary')
        .set('Cookie', ['xplain_session=test-session-referrer']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.referralCode).toBe('XP-BOSS');
      expect(res.body.data.totalReferrals).toBe(1);
      expect(res.body.data.activeReferrals).toBe(1);
      // 3% of 1000 EUR = 30 EUR/month
      expect(res.body.data.monthlyEstimatedBonusEUR).toBe('30.00');
      expect(res.body.data.totalCommissionsEarnedEUR).toBe('30.00');
      expect(res.body.data.referees.length).toBe(1);
      expect(res.body.data.referees[0].capitalEUR).toBe('1000.00');
    });

    it('should calculate monthly commissions with 3% rate and double-entry ledger posting', async () => {
      vi.spyOn(prisma.referral, 'findMany').mockResolvedValue([
        {
          id: referralId,
          referrerProfileId,
          refereeProfileId,
          status: ReferralStatus.ACTIVE,
          referrer: { id: referrerProfileId },
          referee: {
            id: refereeProfileId,
            investmentBatches: [
              {
                id: 'batch-1',
                status: 'ACTIVE',
                capitalEUR: new Prisma.Decimal('2000.00'),
              },
            ],
          },
        } as any,
      ]);

      vi.spyOn(prisma.referralCommission, 'findUnique').mockResolvedValue(null);

      const txMock = {
        referralCommission: {
          create: vi.fn().mockResolvedValue({ id: 'comm-new-1' }),
        },
      };

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        return cb(txMock);
      });

      const result = await ReferralService.calculateMonthlyCommissions('2026-09');

      expect(result.periodMonth).toBe('2026-09');
      expect(result.count).toBe(1);
      expect(result.results[0].commissionEUR).toBe('60.00'); // 3% of 2000 = 60
    });
  });
});
