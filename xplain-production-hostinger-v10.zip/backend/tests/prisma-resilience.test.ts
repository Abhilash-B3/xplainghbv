import { describe, it, expect } from 'vitest';
import { prisma, checkDatabaseHealth, connectDatabase } from '../src/config/database.js';

describe('Prisma 7 & PostgreSQL Driver Resilience Audit', () => {
  it('should execute checkDatabaseHealth and return status healthy with numeric latency', async () => {
    const health = await checkDatabaseHealth();
    expect(health.status).toBe('healthy');
    expect(typeof health.latencyMs).toBe('number');
    expect(health.latencyMs).toBeGreaterThanOrEqual(0);
  });

  it('should connect to database without errors via connectDatabase()', async () => {
    await expect(connectDatabase(2, 500)).resolves.not.toThrow();
  });

  it('should execute prisma.user.findUnique successfully without throwing unhandled exceptions', async () => {
    const result = await prisma.user.findUnique({
      where: { email: 'nonexistent.user.audit.2026@xplainghbv.com' },
      include: { partnerProfile: true },
    });
    expect(result).toBeNull();
  });

  it('should handle rapid concurrent queries (20 parallel requests) without pool exhaustion', async () => {
    const promises = Array.from({ length: 20 }).map((_, i) =>
      prisma.user.findFirst({
        select: { id: true, email: true },
      })
    );

    const results = await Promise.all(promises);
    expect(results).toHaveLength(20);
  });
});
