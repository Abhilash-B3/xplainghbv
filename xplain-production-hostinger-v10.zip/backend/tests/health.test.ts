import { describe, it, expect, vi } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import * as databaseModule from '../src/config/database.js';
import * as redisModule from '../src/config/redis.js';

describe('GET /api/v1/health', () => {
  it('should return 200 and healthy status when database is reachable', async () => {
    const dbSpy = vi.spyOn(databaseModule, 'checkDatabaseHealth').mockResolvedValueOnce({
      status: 'healthy',
      latencyMs: 5,
    });
    const redisSpy = vi.spyOn(redisModule, 'checkRedisHealth').mockResolvedValueOnce({
      status: 'healthy',
      latencyMs: 2,
    });

    const res = await request(app).get('/api/v1/health');

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('success', true);
    expect(res.body).toHaveProperty('data');
    expect(res.body.data).toHaveProperty('status', 'healthy');
    expect(res.body.data).toHaveProperty('timestamp');
    expect(res.body.data).toHaveProperty('uptimeSeconds');
    expect(res.body.data).toHaveProperty('services');
    expect(res.body.data.services.database.status).toBe('healthy');
    expect(res.headers).toHaveProperty('x-request-id');

    dbSpy.mockRestore();
  });

  it('should return 503 and DATABASE_ERROR when database check fails', async () => {
    const dbSpy = vi.spyOn(databaseModule, 'checkDatabaseHealth').mockResolvedValueOnce({
      status: 'unhealthy',
      error: 'Connection refused to PostgreSQL on port 5432',
    });

    const res = await request(app).get('/api/v1/health');

    expect(res.status).toBe(503);
    expect(res.body).toHaveProperty('success', false);
    expect(res.body.error).toHaveProperty('code', 'DATABASE_ERROR');
    expect(res.body.error.message).toContain('database is unavailable');
    expect(res.body.error.details.services.database.status).toBe('unhealthy');

    dbSpy.mockRestore();
  });
});
