import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { PayoutService } from '../src/services/payout.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import { PayoutStatus, Prisma, UserRole } from '@prisma/client';

describe('Return & Payout Engine (PayoutService & Financial Summary)', () => {
  const mockInvestor = {
    id: 'user-uuid-1',
    email: 'payout-user@xplain.com',
    phone: '+447500000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'profile-uuid-1',
      fullName: 'Payout Test Investor',
      preferredCurrency: 'EUR' as const,
      referralCode: 'XP-PAYOUT1',
      kycStatus: 'VERIFIED' as const,
      resalePlan: 'SELLFOR' as const,
      investmentBatches: [
        {
          id: 'batch-uuid-1',
          capitalEUR: new Prisma.Decimal('860.00'),
          status: 'ACTIVE',
          payouts: [
            {
              id: 'payout-uuid-1',
              batchId: 'batch-uuid-1',
              payoutIndex: 1,
              amountEUR: new Prisma.Decimal('60.20'),
              status: PayoutStatus.PAID,
            },
          ],
        },
      ],
    },
  };

  const mockScheduledPayout = {
    id: 'payout-uuid-1',
    batchId: 'batch-uuid-1',
    partnerProfileId: 'profile-uuid-1',
    payoutIndex: 1,
    dueDate: new Date(),
    amountEUR: new Prisma.Decimal('60.20'),
    status: PayoutStatus.SCHEDULED,
    paidAt: null,
    batch: { id: 'batch-uuid-1' },
    partnerProfile: { id: 'profile-uuid-1' },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('should process a scheduled monthly payout and credit AVAILABLE_RETURNS via double-entry ledger', async () => {
    // Mock interactive transaction
    vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => {
      const mockTx = {
        payout: {
          findUnique: vi.fn().mockResolvedValue(mockScheduledPayout),
          update: vi.fn().mockResolvedValue({
            ...mockScheduledPayout,
            status: PayoutStatus.PAID,
            paidAt: new Date(),
          }),
        },
      };
      return cb(mockTx);
    });

    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow-uuid');
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-returns-uuid');
    vi.spyOn(LedgerService, 'getAccountBalance').mockResolvedValue(new Prisma.Decimal('5000.0000'));
    vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'ledger-tx-1' } as any);

    const processed = await PayoutService.processPayout('payout-uuid-1');

    expect(processed.status).toBe(PayoutStatus.PAID);
    expect(processed.paidAt).toBeDefined();
    expect(LedgerService.postTransaction).toHaveBeenCalledWith(
      expect.objectContaining({
        referenceNumber: 'PAYOUT-batch-uuid-1-1',
        entries: expect.arrayContaining([
          expect.objectContaining({ accountId: 'acc-escrow-uuid', amountEUR: new Prisma.Decimal('60.20') }),
          expect.objectContaining({ accountId: 'acc-returns-uuid', amountEUR: new Prisma.Decimal('60.20') }),
        ]),
      }),
      expect.anything()
    );
  });

  it('should be idempotent and prevent double-crediting if payout is already marked PAID', async () => {
    const alreadyPaidPayout = {
      ...mockScheduledPayout,
      status: PayoutStatus.PAID,
      paidAt: new Date(),
    };

    vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => {
      const mockTx = {
        payout: {
          findUnique: vi.fn().mockResolvedValue(alreadyPaidPayout),
        },
      };
      return cb(mockTx);
    });

    const postSpy = vi.spyOn(LedgerService, 'postTransaction');

    const result = await PayoutService.processPayout('payout-uuid-1');

    expect(result.status).toBe(PayoutStatus.PAID);
    expect(postSpy).not.toHaveBeenCalled();
  });

  it('should reject payout processing if PLATFORM_ESCROW has insufficient funds to back the return', async () => {
    vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => {
      const mockTx = {
        payout: {
          findUnique: vi.fn().mockResolvedValue(mockScheduledPayout),
        },
      };
      return cb(mockTx);
    });

    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow-uuid');
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-returns-uuid');
    vi.spyOn(LedgerService, 'getAccountBalance').mockResolvedValue(new Prisma.Decimal('10.0000')); // Insufficient: 10 < 60.20

    await expect(PayoutService.processPayout('payout-uuid-1')).rejects.toThrow(/insufficient funding in PLATFORM_ESCROW/i);
  });

  it('should return authoritative financial summary from PostgreSQL ledger at /api/v1/users/me/financial-summary', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor);
    vi.spyOn(prisma.partnerProfile, 'findUnique').mockResolvedValueOnce(mockInvestor.partnerProfile as any);

    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-id');
    vi.spyOn(LedgerService, 'getAccountBalance')
      .mockResolvedValueOnce(new Prisma.Decimal('60.20')) // available returns
      .mockResolvedValueOnce(new Prisma.Decimal('860.00')) // locked capital
      .mockResolvedValueOnce(new Prisma.Decimal('0.00')); // unlocked capital

    const res = await request(app)
      .get('/api/v1/users/me/financial-summary')
      .set('Cookie', ['xplain_session=valid_token']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.availableReturnsEUR).toBe('60.20');
    expect(res.body.data.lockedCapitalEUR).toBe('860.00');
    expect(res.body.data.totalInvestedEUR).toBe('860.00');
    expect(res.body.data.totalPaidOutEUR).toBe('60.20');
    expect(res.body.data.activeBatchesCount).toBe(1);
  });
});
