import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { UserRole, Prisma } from '@prisma/client';

describe('Product Catalogue & Category API (/api/v1/products, /api/v1/categories, /api/v1/showcase)', () => {
  const testCategoryId = '11111111-1111-4111-8111-111111111111';
  const testProductId = '22222222-2222-4222-8222-222222222222';

  const mockAdminUser = {
    id: '33333333-3333-4333-8333-333333333333',
    email: 'admin@xplain.com',
    phone: '+447000000001',
    role: UserRole.ADMIN,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
  };

  const mockInvestorUser = {
    id: '44444444-4444-4444-8444-444444444444',
    email: 'investor@xplain.com',
    phone: '+447100000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: '55555555-5555-4555-8555-555555555555',
      fullName: 'Test Investor',
      preferredCurrency: 'EUR' as const,
      referralCode: 'XP-TEST1',
      kycStatus: 'VERIFIED' as const,
      resalePlan: 'SELLFOR' as const,
    },
  };

  const mockProduct = {
    id: testProductId,
    categoryId: testCategoryId,
    ref: 'TEST-PROD-001',
    name: 'Premium Test Refrigerator',
    description: 'Stainless steel high-efficiency cooling appliance',
    priceEUR: new Prisma.Decimal('850.00'),
    imageUrl: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500',
    stockQuantity: 50,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    category: {
      id: testCategoryId,
      name: 'Refrigerators',
      slug: 'refrigerators',
    },
  };

  const mockCategory = {
    id: testCategoryId,
    name: 'Refrigerators',
    slug: 'refrigerators',
    displayOrder: 1,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    _count: { products: 1 },
  };

  const mockShowcase = [
    {
      id: '66666666-6666-4666-8666-666666666666',
      name: 'French Door Fridge',
      desc: 'Stainless steel multi-door',
      imageUrl: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=500',
      tag: 'POPULAR',
      displayOrder: 1,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  describe('GET /api/v1/products', () => {
    it('should return list of products from PostgreSQL with pagination', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);
      vi.spyOn(prisma.product, 'count').mockResolvedValueOnce(1);

      const res = await request(app).get('/api/v1/products?page=1&limit=10');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.products.length).toBe(1);
      expect(res.body.data.pagination.page).toBe(1);
      expect(res.body.data.pagination.total).toBe(1);
    });

    it('should filter products by category slug', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);
      vi.spyOn(prisma.product, 'count').mockResolvedValueOnce(1);

      const res = await request(app).get('/api/v1/products?category=refrigerators');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.products[0].category.slug).toBe('refrigerators');
    });

    it('should search products by keyword parameter safely', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);
      vi.spyOn(prisma.product, 'count').mockResolvedValueOnce(1);

      const res = await request(app).get('/api/v1/products?search=Refrigerator');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.products.length).toBe(1);
    });
  });

  describe('GET /api/v1/products/:idOrRef', () => {
    it('should return product details by UUID', async () => {
      vi.spyOn(prisma.product, 'findFirst').mockResolvedValueOnce(mockProduct as any);

      const res = await request(app).get(`/api/v1/products/${testProductId}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.id).toBe(testProductId);
      expect(res.body.data.ref).toBe('TEST-PROD-001');
    });

    it('should return product details by SKU reference', async () => {
      vi.spyOn(prisma.product, 'findFirst').mockResolvedValueOnce(mockProduct as any);

      const res = await request(app).get('/api/v1/products/TEST-PROD-001');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.ref).toBe('TEST-PROD-001');
    });

    it('should return 404 NOT_FOUND for nonexistent product', async () => {
      vi.spyOn(prisma.product, 'findFirst').mockResolvedValueOnce(null);

      const res = await request(app).get('/api/v1/products/NONEXISTENT-REF');

      expect(res.status).toBe(404);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('NOT_FOUND');
    });
  });

  describe('GET /api/v1/categories & GET /api/v1/showcase', () => {
    it('should return active categories', async () => {
      vi.spyOn(prisma.productCategory, 'findMany').mockResolvedValueOnce([mockCategory] as any);

      const res = await request(app).get('/api/v1/categories');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.length).toBe(1);
      expect(res.body.data[0].slug).toBe('refrigerators');
    });

    it('should return showcase appliances', async () => {
      vi.spyOn(prisma.showcaseAppliance, 'findMany').mockResolvedValueOnce(mockShowcase as any);

      const res = await request(app).get('/api/v1/showcase');

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.length).toBe(1);
      expect(res.body.data[0].tag).toBe('POPULAR');
    });
  });

  describe('Admin CMS Operations (/api/v1/products)', () => {
    it('should allow ADMIN to create a new product', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockAdminUser);
      vi.spyOn(prisma.product, 'findUnique').mockResolvedValueOnce(null);
      vi.spyOn(prisma.productCategory, 'findUnique').mockResolvedValueOnce(mockCategory as any);
      vi.spyOn(prisma.product, 'create').mockResolvedValueOnce({
        ...mockProduct,
        ref: 'NEW-REF-001',
        name: 'New Washer',
      } as any);

      const res = await request(app)
        .post('/api/v1/products')
        .set('Cookie', ['xplain_session=admin_token'])
        .send({
          categoryId: testCategoryId,
          ref: 'NEW-REF-001',
          name: 'New Washer',
          description: '10kg front load smart washer',
          priceEUR: 920.00,
          imageUrl: 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500',
          stockQuantity: 40,
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.ref).toBe('NEW-REF-001');
    });

    it('should reject non-admin investor from creating a product with 403 FORBIDDEN', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestorUser);

      const res = await request(app)
        .post('/api/v1/products')
        .set('Cookie', ['xplain_session=investor_token'])
        .send({
          categoryId: testCategoryId,
          ref: 'ATTACK-001',
          name: 'Hacked Product',
          priceEUR: 10.00,
          imageUrl: 'https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=500',
        });

      expect(res.status).toBe(403);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('FORBIDDEN');
    });

    it('should allow ADMIN to soft-archive a product (isActive = false)', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockAdminUser);
      vi.spyOn(prisma.product, 'findFirst').mockResolvedValueOnce(mockProduct as any);
      vi.spyOn(prisma.product, 'update').mockResolvedValueOnce({
        ...mockProduct,
        isActive: false,
      } as any);

      const res = await request(app)
        .delete(`/api/v1/products/${testProductId}`)
        .set('Cookie', ['xplain_session=admin_token']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.isActive).toBe(false);
    });
  });
});
