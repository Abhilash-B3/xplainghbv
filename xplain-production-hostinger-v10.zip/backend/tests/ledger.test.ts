import { describe, it, expect, vi, beforeEach } from 'vitest';
import { Prisma, AccountType, EntryType, Currency } from '@prisma/client';
import { LedgerService } from '../src/services/ledger.service.js';
import { prisma } from '../src/config/database.js';

describe('Double-Entry Financial Ledger Engine (LedgerService)', () => {
  const escrowAccountId = 'acc-escrow-uuid';
  const lockedCapitalAccountId = 'acc-locked-uuid';
  const availableReturnsAccountId = 'acc-returns-uuid';

  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('should post a balanced double-entry transaction (Debits === Credits)', async () => {
    const amountEUR = new Prisma.Decimal('1500.0000');
    const ref = 'LEDGER-TEST-001';

    // Mock findUnique for idempotency check (none exists)
    vi.spyOn(prisma.ledgerTransaction, 'findUnique').mockResolvedValueOnce(null);

    // Mock create for transaction
    const mockTx = {
      id: 'tx-uuid-1',
      referenceNumber: ref,
      description: 'Capital investment funding',
      sourceEntity: 'Investment',
      sourceEntityId: 'test-inv-001',
      createdAt: new Date(),
    };
    vi.spyOn(prisma.ledgerTransaction, 'create').mockResolvedValueOnce(mockTx as any);
    vi.spyOn(prisma.ledgerEntry, 'createMany').mockResolvedValueOnce({ count: 2 });

    // Mock $transaction to simply run callback
    vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => cb(prisma));

    const tx = await LedgerService.postTransaction({
      referenceNumber: ref,
      description: 'Capital investment funding',
      sourceEntity: 'Investment',
      sourceEntityId: 'test-inv-001',
      entries: [
        {
          accountId: escrowAccountId,
          entryType: EntryType.DEBIT,
          amount: amountEUR,
          currency: Currency.EUR,
          amountEUR,
        },
        {
          accountId: lockedCapitalAccountId,
          entryType: EntryType.CREDIT,
          amount: amountEUR,
          currency: Currency.EUR,
          amountEUR,
        },
      ],
    });

    expect(tx).toBeDefined();
    expect(tx.referenceNumber).toBe(ref);
  });

  it('should reject an imbalanced transaction and throw BAD_REQUEST before creating records', async () => {
    const ref = 'IMBALANCE-001';

    await expect(
      LedgerService.postTransaction({
        referenceNumber: ref,
        description: 'Imbalanced attack attempt',
        sourceEntity: 'Investment',
        sourceEntityId: 'test-inv-imbalance',
        entries: [
          {
            accountId: escrowAccountId,
            entryType: EntryType.DEBIT,
            amount: new Prisma.Decimal('2000.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('2000.0000'),
          },
          {
            accountId: lockedCapitalAccountId,
            entryType: EntryType.CREDIT,
            amount: new Prisma.Decimal('1000.0000'), // Imbalance: 2000 != 1000
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('1000.0000'),
          },
        ],
      })
    ).rejects.toThrow(/does not balance/i);
  });

  it('should handle duplicate reference numbers idempotently', async () => {
    const amountEUR = new Prisma.Decimal('250.0000');
    const ref = 'IDEMPOTENT-LEDGER-001';

    const existingTx = {
      id: 'tx-existing-1',
      referenceNumber: ref,
      description: 'Existing transaction',
      sourceEntity: 'Test',
      sourceEntityId: 'idemp-001',
      createdAt: new Date(),
    };

    vi.spyOn(prisma.ledgerTransaction, 'findUnique').mockResolvedValueOnce(existingTx as any);
    vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => cb(prisma));

    const tx = await LedgerService.postTransaction({
      referenceNumber: ref,
      description: 'Idempotent test duplicate',
      sourceEntity: 'Test',
      sourceEntityId: 'idemp-001',
      entries: [
        {
          accountId: escrowAccountId,
          entryType: EntryType.DEBIT,
          amount: amountEUR,
          currency: Currency.EUR,
          amountEUR,
        },
        {
          accountId: availableReturnsAccountId,
          entryType: EntryType.CREDIT,
          amount: amountEUR,
          currency: Currency.EUR,
          amountEUR,
        },
      ],
    });

    expect(tx.id).toBe('tx-existing-1');
  });

  it('should reject transactions with non-positive or negative entry amounts', async () => {
    const ref = 'NEGATIVE-ATTACK-001';

    await expect(
      LedgerService.postTransaction({
        referenceNumber: ref,
        description: 'Negative amount attempt',
        sourceEntity: 'Test',
        sourceEntityId: 'neg-001',
        entries: [
          {
            accountId: escrowAccountId,
            entryType: EntryType.DEBIT,
            amount: new Prisma.Decimal('-500.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('-500.0000'),
          },
          {
            accountId: availableReturnsAccountId,
            entryType: EntryType.CREDIT,
            amount: new Prisma.Decimal('-500.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('-500.0000'),
          },
        ],
      })
    ).rejects.toThrow(/must be strictly positive/i);
  });

  it('should compute authoritative balance correctly for CREDIT and DEBIT accounts', async () => {
    // Test normal CREDIT account balance calculation
    vi.spyOn(prisma.financialAccount, 'findUnique').mockResolvedValueOnce({
      id: availableReturnsAccountId,
      accountType: AccountType.AVAILABLE_RETURNS,
    } as any);

    vi.spyOn(prisma.ledgerEntry, 'findMany').mockResolvedValueOnce([
      { entryType: EntryType.CREDIT, amountEUR: new Prisma.Decimal('150.0000') },
      { entryType: EntryType.CREDIT, amountEUR: new Prisma.Decimal('50.0000') },
      { entryType: EntryType.DEBIT, amountEUR: new Prisma.Decimal('30.0000') },
    ] as any);

    const creditBal = await LedgerService.getAccountBalance(availableReturnsAccountId);
    expect(creditBal.toNumber()).toBe(170); // (150 + 50) - 30 = 170

    // Test normal DEBIT (Escrow) account balance calculation
    vi.spyOn(prisma.financialAccount, 'findUnique').mockResolvedValueOnce({
      id: escrowAccountId,
      accountType: AccountType.PLATFORM_ESCROW,
    } as any);

    vi.spyOn(prisma.ledgerEntry, 'findMany').mockResolvedValueOnce([
      { entryType: EntryType.DEBIT, amountEUR: new Prisma.Decimal('1000.0000') },
      { entryType: EntryType.CREDIT, amountEUR: new Prisma.Decimal('200.0000') },
    ] as any);

    const escrowBal = await LedgerService.getAccountBalance(escrowAccountId);
    expect(escrowBal.toNumber()).toBe(800); // 1000 - 200 = 800
  });
});
