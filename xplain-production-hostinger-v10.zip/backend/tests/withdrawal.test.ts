import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import {
  Currency,
  UserRole,
  WithdrawalStatus,
  WithdrawalType,
  DestinationType,
  Prisma,
} from '@prisma/client';

describe('Phase 7 — Withdrawal & Destination Management Tests', () => {
  const user1Id = '11111111-1111-4111-8111-111111111111';
  const profile1Id = '22222222-2222-4222-8222-222222222222';
  const user2Id = '33333333-3333-4333-8333-333333333333';
  const profile2Id = '44444444-4444-4444-8444-444444444444';
  const adminId = '55555555-5555-4555-8555-555555555555';
  const adminProfileId = '66666666-6666-4666-8666-666666666666';

  const bank1Id = '77777777-7777-4777-8777-777777777777';
  const momo1Id = '88888888-8888-4888-8888-888888888888';
  const withdrawal1Id = '99999999-9999-4999-8999-999999999999';

  const mockUser1 = {
    id: user1Id,
    email: 'user1@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profile1Id,
      fullName: 'User One',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-USER1',
      kycStatus: 'VERIFIED' as const,
    },
  };

  const mockUser2 = {
    id: user2Id,
    email: 'user2@xplain.com',
    phone: '+447400000002',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: profile2Id,
      fullName: 'User Two',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-USER2',
      kycStatus: 'VERIFIED' as const,
    },
  };

  const mockAdmin = {
    id: adminId,
    email: 'admin@xplain.com',
    phone: '+447500000003',
    role: UserRole.ADMIN,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: adminProfileId,
      fullName: 'Platform Admin',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-ADMIN',
      kycStatus: 'VERIFIED' as const,
    },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.exchangeRateSnapshot, 'findFirst').mockResolvedValue(null);
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({ id: 'audit-id' } as any);
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-partner-mock');
    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-system-mock');
    vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'tx-ledger-mock' } as any);
  });

  describe('Destination Management (Bank & MoMo)', () => {
    it('should add a bank account with masking and validation', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
      vi.spyOn(prisma.bankAccount, 'create').mockResolvedValue({
        id: bank1Id,
        partnerProfileId: profile1Id,
        bankName: 'Barclays Bank',
        accountNumberMasked: '•••• 7890',
        sortCodeOrSwift: '20-00-00',
        accountHolderName: 'User One',
        currency: Currency.EUR,
        country: 'GB',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const res = await request(app)
        .post('/api/v1/bank-accounts')
        .set('Cookie', ['xplain_session=test-session-user1'])
        .send({
          bankName: 'Barclays Bank',
          accountNumber: '1234567890',
          sortCodeOrSwift: '20-00-00',
          accountHolderName: 'User One',
          currency: 'EUR',
          country: 'GB',
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.bankName).toBe('Barclays Bank');
      expect(res.body.data.accountNumberMasked).toBe('•••• 7890');
    });

    it('should add a MoMo account with masking', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
      vi.spyOn(prisma.moMoAccount, 'create').mockResolvedValue({
        id: momo1Id,
        partnerProfileId: profile1Id,
        provider: 'MTN_MOMO',
        phoneNumberMasked: '•••• 5678',
        accountHolderName: 'User One',
        country: 'GH',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const res = await request(app)
        .post('/api/v1/momo-accounts')
        .set('Cookie', ['xplain_session=test-session-user1'])
        .send({
          provider: 'MTN_MOMO',
          phoneNumber: '+233241235678',
          accountHolderName: 'User One',
          country: 'GH',
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.provider).toBe('MTN_MOMO');
      expect(res.body.data.phoneNumberMasked).toBe('•••• 5678');
    });

    it('should prevent IDOR when deleting a destination belonging to another user', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser2 as any);
      vi.spyOn(prisma.bankAccount, 'findUnique').mockResolvedValue({
        id: bank1Id,
        partnerProfileId: profile1Id, // Belongs to User 1!
        bankName: 'Barclays Bank',
        accountNumberMasked: '•••• 7890',
        sortCodeOrSwift: '20-00-00',
        accountHolderName: 'User One',
        currency: Currency.EUR,
        country: 'GB',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const res = await request(app)
        .delete(`/api/v1/bank-accounts/${bank1Id}`)
        .set('Cookie', ['xplain_session=test-session-user2']);

      expect(res.status).toBe(403);
    });
  });

  describe('Authoritative Withdrawable Balance & Reservations', () => {
    it('should calculate balance directly from double-entry ledger without double-subtracting reservations', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);

      // Ledger: AVAILABLE_RETURNS = 500, UNLOCKED_CAPITAL = 1000, WITHDRAWAL_RESERVED = 200
      vi.spyOn(LedgerService, 'getAccountBalance')
        .mockResolvedValueOnce(new Prisma.Decimal('500.00')) // AVAILABLE_RETURNS
        .mockResolvedValueOnce(new Prisma.Decimal('1000.00')) // UNLOCKED_CAPITAL
        .mockResolvedValueOnce(new Prisma.Decimal('200.00')); // WITHDRAWAL_RESERVED

      const res = await request(app)
        .get('/api/v1/withdrawals/balance')
        .set('Cookie', ['xplain_session=test-session-user1']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.availableReturnsEUR).toBe('500.00');
      expect(res.body.data.unlockedCapitalEUR).toBe('1000.00');
      expect(res.body.data.totalWithdrawableEUR).toBe('1500.00');
      expect(res.body.data.reservedWithdrawalsEUR).toBe('200.00');
    });

    it('should reject withdrawal when requested amount exceeds available ledger balance', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
      vi.spyOn(prisma.bankAccount, 'findUnique').mockResolvedValue({
        id: bank1Id,
        partnerProfileId: profile1Id,
        bankName: 'Barclays Bank',
        accountNumberMasked: '•••• 7890',
        sortCodeOrSwift: '20-00-00',
        accountHolderName: 'User One',
        currency: Currency.EUR,
        country: 'GB',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // User has only 100 EUR available returns
      vi.spyOn(LedgerService, 'getAccountBalance')
        .mockResolvedValueOnce(new Prisma.Decimal('100.00')) // AVAILABLE_RETURNS
        .mockResolvedValueOnce(new Prisma.Decimal('0.00')) // UNLOCKED_CAPITAL
        .mockResolvedValueOnce(new Prisma.Decimal('0.00')); // WITHDRAWAL_RESERVED

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        return cb(prisma);
      });

      const res = await request(app)
        .post('/api/v1/withdrawals')
        .set('Cookie', ['xplain_session=test-session-user1'])
        .send({
          withdrawalType: 'RETURNS',
          amount: 500, // Exceeds 100 available!
          currency: 'EUR',
          destinationType: 'BANK',
          bankAccountId: bank1Id,
        });

      expect(res.status).toBe(400);
      expect(res.body.error.code).toBe('BAD_REQUEST');
    });

    it('should successfully reserve funds and create withdrawal in PENDING state', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
      vi.spyOn(prisma.bankAccount, 'findUnique').mockResolvedValue({
        id: bank1Id,
        partnerProfileId: profile1Id,
        bankName: 'Barclays Bank',
        accountNumberMasked: '•••• 7890',
        sortCodeOrSwift: '20-00-00',
        accountHolderName: 'User One',
        currency: Currency.EUR,
        country: 'GB',
        isVerified: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      vi.spyOn(LedgerService, 'getAccountBalance')
        .mockResolvedValueOnce(new Prisma.Decimal('500.00')) // AVAILABLE_RETURNS
        .mockResolvedValueOnce(new Prisma.Decimal('0.00')) // UNLOCKED_CAPITAL
        .mockResolvedValueOnce(new Prisma.Decimal('0.00')); // WITHDRAWAL_RESERVED

      const createdWithdrawalMock = {
        id: withdrawal1Id,
        partnerProfileId: profile1Id,
        withdrawalType: WithdrawalType.RETURNS,
        amount: new Prisma.Decimal('100.00'),
        currency: Currency.EUR,
        amountEUR: new Prisma.Decimal('100.00'),
        destinationType: DestinationType.BANK,
        bankAccountId: bank1Id,
        status: WithdrawalStatus.PENDING,
        createdAt: new Date(),
        bankAccount: { bankName: 'Barclays Bank', accountNumberMasked: '•••• 7890' },
      };

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        const tx = {
          withdrawal: {
            create: vi.fn().mockResolvedValue(createdWithdrawalMock),
          },
        };
        return cb(tx);
      });

      const res = await request(app)
        .post('/api/v1/withdrawals')
        .set('Cookie', ['xplain_session=test-session-user1'])
        .send({
          withdrawalType: 'RETURNS',
          amount: 100,
          currency: 'EUR',
          destinationType: 'BANK',
          bankAccountId: bank1Id,
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('PENDING');
      expect(Number(res.body.data.amountEUR)).toBe(100);
    });

    it('should cancel pending withdrawal and release reserved balance back to AVAILABLE_RETURNS', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        const tx = {
          withdrawal: {
            findUnique: vi.fn().mockResolvedValue({
              id: withdrawal1Id,
              partnerProfileId: profile1Id,
              withdrawalType: WithdrawalType.RETURNS,
              amount: new Prisma.Decimal('100.00'),
              currency: Currency.EUR,
              amountEUR: new Prisma.Decimal('100.00'),
              status: WithdrawalStatus.PENDING,
            }),
            update: vi.fn().mockResolvedValue({
              id: withdrawal1Id,
              status: WithdrawalStatus.CANCELLED,
            }),
          },
        };
        return cb(tx);
      });

      const res = await request(app)
        .post(`/api/v1/withdrawals/${withdrawal1Id}/cancel`)
        .set('Cookie', ['xplain_session=test-session-user1']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('CANCELLED');
    });
  });

  describe('Admin Settlement & Rejection Verification', () => {
    it('should require genuine settlement reference to complete withdrawal', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockAdmin as any);

      // Attempt complete without settlement reference
      const res = await request(app)
        .post(`/api/v1/admin/withdrawals/${withdrawal1Id}/complete`)
        .set('Cookie', ['xplain_session=test-session-admin'])
        .send({
          settlementReference: '   ', // blank
        });

      expect(res.status).toBe(400);
      expect(res.body.error.code).toBe('VALIDATION_ERROR');
    });

    it('should complete withdrawal with genuine settlement proof and post clearing ledger entry', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockAdmin as any);

      vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
        const tx = {
          withdrawal: {
            findUnique: vi.fn().mockResolvedValue({
              id: withdrawal1Id,
              partnerProfileId: profile1Id,
              withdrawalType: WithdrawalType.RETURNS,
              amount: new Prisma.Decimal('100.00'),
              currency: Currency.EUR,
              amountEUR: new Prisma.Decimal('100.00'),
              status: WithdrawalStatus.PROCESSING,
            }),
            update: vi.fn().mockResolvedValue({
              id: withdrawal1Id,
              status: WithdrawalStatus.COMPLETED,
              settlementReference: 'BARC-REF-2026-9921',
            }),
          },
        };
        return cb(tx);
      });

      const res = await request(app)
        .post(`/api/v1/admin/withdrawals/${withdrawal1Id}/complete`)
        .set('Cookie', ['xplain_session=test-session-admin'])
        .send({
          settlementReference: 'BARC-REF-2026-9921',
          settlementProof: { bankBatchId: 'B-8832', timestamp: '2026-09-12T12:00:00Z' },
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe('COMPLETED');
      expect(res.body.data.settlementReference).toBe('BARC-REF-2026-9921');
    });
  });
});
