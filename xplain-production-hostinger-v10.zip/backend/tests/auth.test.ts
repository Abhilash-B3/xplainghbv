import { describe, it, expect, vi } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { AuthService } from '../src/services/auth.service.js';
import { AppError } from '../src/utils/appError.js';

describe('Authentication & Identity API (/api/v1/auth)', () => {
  const testEmail = 'kwame.mensah@example.com';
  const testPassword = 'StrongPassword123';
  const mockSafeUser = {
    id: 'user-uuid-1234',
    email: testEmail,
    phone: '+233555555555',
    role: 'INVESTOR' as const,
    status: 'ACTIVE' as const,
    isEmailVerified: false,
    isPhoneVerified: false,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'profile-uuid-1234',
      fullName: 'Kwame Mensah',
      preferredCurrency: 'EUR' as const,
      referralCode: 'XP-ABC123',
      kycStatus: 'NOT_SUBMITTED' as const,
      resalePlan: 'DIRECT' as const,
    },
  };

  describe('POST /api/v1/auth/register', () => {
    it('should register a new investor, return 201, set session cookie, and return safe user', async () => {
      const registerSpy = vi.spyOn(AuthService, 'register').mockResolvedValueOnce({
        user: mockSafeUser,
        sessionToken: 'raw_session_token_xyz123',
      });

      const res = await request(app)
        .post('/api/v1/auth/register')
        .send({
          email: testEmail,
          password: testPassword,
          phone: '+233555555555',
          fullName: 'Kwame Mensah',
          preferredCurrency: 'EUR',
          resalePlan: 'DIRECT',
        });

      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('success', true);
      expect(res.body.data.user).toHaveProperty('email', testEmail);
      expect(res.body.data.user).not.toHaveProperty('password');
      expect(res.body.data.user).not.toHaveProperty('passwordHash');

      const cookies = res.headers['set-cookie'];
      expect(cookies).toBeDefined();
      const sessionCookieHeader = cookies.find((c: string) => c.startsWith('xplain_session='));
      expect(sessionCookieHeader).toBeDefined();

      registerSpy.mockRestore();
    });

    it('should reject registration with duplicate email with 409 CONFLICT', async () => {
      const registerSpy = vi.spyOn(AuthService, 'register').mockRejectedValueOnce(
        AppError.conflict('An account with this email address already exists')
      );

      const res = await request(app)
        .post('/api/v1/auth/register')
        .send({
          email: testEmail,
          password: testPassword,
          phone: '+233555555555',
          fullName: 'Kwame Mensah',
        });

      expect(res.status).toBe(409);
      expect(res.body.error.code).toBe('CONFLICT');
      expect(res.body.error.message).toContain('email');

      registerSpy.mockRestore();
    });

    it('should reject invalid password format with 400 VALIDATION_ERROR', async () => {
      const res = await request(app)
        .post('/api/v1/auth/register')
        .send({
          email: 'invalid@example.com',
          password: 'short',
          phone: '+233555555555',
          fullName: 'Invalid User',
        });

      expect(res.status).toBe(400);
      expect(res.body.error.code).toBe('VALIDATION_ERROR');
      expect(Array.isArray(res.body.error.details)).toBe(true);
    });
  });

  describe('POST /api/v1/auth/login', () => {
    it('should log in successfully with valid credentials and return 200 with cookie', async () => {
      const loginSpy = vi.spyOn(AuthService, 'login').mockResolvedValueOnce({
        user: mockSafeUser,
        sessionToken: 'raw_session_token_xyz123',
      });

      const res = await request(app)
        .post('/api/v1/auth/login')
        .send({
          email: testEmail,
          password: testPassword,
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.user.email).toBe(testEmail);
      expect(res.headers['set-cookie']).toBeDefined();

      loginSpy.mockRestore();
    });

    it('should reject invalid credentials with 401 UNAUTHORIZED', async () => {
      const loginSpy = vi.spyOn(AuthService, 'login').mockRejectedValueOnce(
        AppError.unauthorized('Invalid email or password')
      );

      const res = await request(app)
        .post('/api/v1/auth/login')
        .send({
          email: testEmail,
          password: 'WrongPassword999',
        });

      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe('UNAUTHORIZED');
      expect(res.body.error.message).toContain('Invalid email or password');

      loginSpy.mockRestore();
    });
  });

  describe('GET /api/v1/auth/me', () => {
    it('should return authenticated user profile when session cookie is valid', async () => {
      const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockSafeUser);

      const res = await request(app)
        .get('/api/v1/auth/me')
        .set('Cookie', ['xplain_session=valid_raw_token_xyz']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.user.email).toBe(testEmail);
      expect(res.body.data.user).not.toHaveProperty('passwordHash');

      validateSpy.mockRestore();
    });

    it('should return 401 UNAUTHORIZED when no session cookie is provided', async () => {
      const res = await request(app).get('/api/v1/auth/me');

      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe('UNAUTHORIZED');
    });

    it('should return 401 UNAUTHORIZED when session is expired or invalid in database', async () => {
      const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(null);

      const res = await request(app)
        .get('/api/v1/auth/me')
        .set('Cookie', ['xplain_session=expired_or_revoked_token']);

      expect(res.status).toBe(401);
      expect(res.body.error.code).toBe('UNAUTHORIZED');

      validateSpy.mockRestore();
    });
  });

  describe('POST /api/v1/auth/logout', () => {
    it('should call AuthService.logout and clear session cookie', async () => {
      const validateSpy = vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockSafeUser);
      const logoutSpy = vi.spyOn(AuthService, 'logout').mockResolvedValueOnce();

      const res = await request(app)
        .post('/api/v1/auth/logout')
        .set('Cookie', ['xplain_session=valid_raw_token_xyz']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(logoutSpy).toHaveBeenCalled();

      validateSpy.mockRestore();
      logoutSpy.mockRestore();
    });
  });

  describe('POST /api/v1/auth/forgot-password & reset-password', () => {
    it('should accept forgot-password and return generic 200 message', async () => {
      const forgotSpy = vi.spyOn(AuthService, 'forgotPassword').mockResolvedValueOnce();

      const res = await request(app)
        .post('/api/v1/auth/forgot-password')
        .send({ email: testEmail });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.message).toContain('instructions');

      forgotSpy.mockRestore();
    });

    it('should reset password with valid token and return 200', async () => {
      const resetSpy = vi.spyOn(AuthService, 'resetPassword').mockResolvedValueOnce();

      const res = await request(app)
        .post('/api/v1/auth/reset-password')
        .send({
          token: 'valid_secure_token_minimum_16_characters',
          newPassword: 'BrandNewPassword123',
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.message).toContain('reset successfully');

      resetSpy.mockRestore();
    });
  });

  describe('POST /api/v1/auth/verify-email', () => {
    it('should verify email with valid token and return 200', async () => {
      const verifySpy = vi.spyOn(AuthService, 'verifyEmail').mockResolvedValueOnce();

      const res = await request(app)
        .post('/api/v1/auth/verify-email')
        .send({
          token: 'valid_verification_token_minimum_16_chars',
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.message).toContain('verified');

      verifySpy.mockRestore();
    });
  });
});
