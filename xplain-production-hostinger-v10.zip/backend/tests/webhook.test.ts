import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { stripeClient } from '../src/config/stripe.js';
import { LedgerService } from '../src/services/ledger.service.js';
import {
  ResalePlan,
  Currency,
  InvestmentStatus,
  Prisma,
  PaymentProvider,
  TransactionType,
  TransactionStatus,
  EntryType,
} from '@prisma/client';

describe('Stripe Webhook & Authoritative Financial Settlement API (/api/v1/webhooks/stripe)', () => {
  const profileId = '22222222-2222-4222-8222-222222222222';
  const investmentId = '55555555-5555-4555-8555-555555555555';
  const paymentTxId = '66666666-6666-4666-8666-666666666666';
  const paymentIntentId = 'pi_test_settlement_12345';
  const eventId = 'evt_test_webhook_00001';

  const mockInvestment = {
    id: investmentId,
    partnerProfileId: profileId,
    resalePlan: ResalePlan.SELLFOR,
    status: InvestmentStatus.PAYMENT_PENDING,
    currency: Currency.EUR,
    subtotalInCurrency: new Prisma.Decimal('1000.00'),
    discountAmountInCurrency: new Prisma.Decimal('140.00'),
    totalAmountInCurrency: new Prisma.Decimal('860.00'),
    totalAmountEUR: new Prisma.Decimal('860.00'),
    exchangeRateToEUR: new Prisma.Decimal('1.00000000'),
    deliveryAddressId: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockPaymentTx = {
    id: paymentTxId,
    referenceNumber: 'TX-INV-TEST-001',
    investmentId: investmentId,
    partnerProfileId: profileId,
    provider: PaymentProvider.STRIPE,
    providerTransactionId: paymentIntentId,
    stripePaymentIntentId: paymentIntentId,
    stripeCustomerId: null,
    stripePaymentStatus: 'requires_payment_method',
    stripeLatestEventId: null,
    type: TransactionType.DEPOSIT,
    amount: new Prisma.Decimal('860.00'),
    currency: Currency.EUR,
    canonicalAmountEUR: new Prisma.Decimal('860.00'),
    status: TransactionStatus.PENDING,
    paidAt: null,
    failureCode: null,
    failureMessage: null,
    idempotencyKey: null,
    providerMetadata: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    investment: mockInvestment,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({} as any);
  });

  describe('POST /api/v1/webhooks/stripe - Security & Signature Verification', () => {
    it('should reject requests without Stripe-Signature header with 400 Bad Request', async () => {
      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .send(JSON.stringify({ id: 'evt_test' }));

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('BAD_REQUEST');
    });

    it('should reject requests with invalid Stripe signature with 400 Bad Request', async () => {
      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockImplementation(() => {
        throw new Error('signature verification failed');
      });

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=invalid_signature')
        .send(JSON.stringify({ id: 'evt_test' }));

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.message).toContain('signature verification failed');
    });
  });

  describe('POST /api/v1/webhooks/stripe - payment_intent.succeeded Settlement', () => {
    it('should atomically settle payment, activate investment, create Option B batch with 12 payouts, and post balanced ledger entries', async () => {
      const mockEvent = {
        id: eventId,
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: paymentIntentId,
            amount: 86000, // 860.00 EUR in cents
            currency: 'eur',
            status: 'succeeded',
            metadata: {
              paymentTransactionId: paymentTxId,
              investmentId: investmentId,
            },
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);

      // Mock Prisma transaction operations
      const txMock = {
        paymentTransaction: { update: vi.fn().mockResolvedValue({}) },
        investment: { update: vi.fn().mockResolvedValue({}) },
        financialAccount: { findFirst: vi.fn(), findUnique: vi.fn(), create: vi.fn() },
        ledgerTransaction: { findUnique: vi.fn().mockResolvedValue(null), create: vi.fn().mockResolvedValue({ id: 'lt-1' }) },
        ledgerEntry: { createMany: vi.fn().mockResolvedValue({}) },
        investmentBatch: { create: vi.fn().mockResolvedValue({ id: 'batch-1' }) },
        payout: { createMany: vi.fn().mockResolvedValue({}) },
        stripePaymentEvent: { create: vi.fn().mockResolvedValue({}) },
        auditLog: { create: vi.fn().mockResolvedValue({}) },
      };

      vi.spyOn(prisma, '$transaction').mockImplementation(async (callback: any) => {
        return callback(txMock);
      });

      vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow-1');
      vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-locked-1');
      const postTransactionSpy = vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'lt-1' } as any);

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(200);
      expect(res.body.received).toBe(true);
      expect(res.body.eventType).toBe('payment_intent.succeeded');

      // Verify PaymentTransaction was updated to SUCCESSFUL
      expect(txMock.paymentTransaction.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: paymentTxId },
          data: expect.objectContaining({
            status: TransactionStatus.SUCCESSFUL,
            stripePaymentStatus: 'succeeded',
          }),
        })
      );

      // Verify Investment was activated
      expect(txMock.investment.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: investmentId },
          data: { status: InvestmentStatus.ACTIVE },
        })
      );

      // Verify Option B Batch and 12 Payout schedules created
      expect(txMock.investmentBatch.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            investmentId,
            partnerProfileId: profileId,
            lockDurationMonths: 12,
          }),
        })
      );
      expect(txMock.payout.createMany).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.arrayContaining([
            expect.objectContaining({ payoutIndex: 1, status: 'SCHEDULED' }),
            expect.objectContaining({ payoutIndex: 12, status: 'SCHEDULED' }),
          ]),
        })
      );

      // Verify Balanced Ledger Transaction posted (DEBIT Escrow, CREDIT Locked Capital)
      expect(postTransactionSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          sourceEntity: 'Investment',
          sourceEntityId: investmentId,
          entries: expect.arrayContaining([
            expect.objectContaining({
              accountId: 'acc-escrow-1',
              entryType: EntryType.DEBIT,
            }),
            expect.objectContaining({
              accountId: 'acc-locked-1',
              entryType: EntryType.CREDIT,
            }),
          ]),
        }),
        expect.anything()
      );
    });

    it('should be completely idempotent when receiving the same webhook event ID twice', async () => {
      const mockEvent = {
        id: eventId,
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: paymentIntentId,
            amount: 86000,
            currency: 'eur',
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      
      // Simulate that the event ID was already recorded in database
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue({
        id: 'event-uuid-1',
        eventId: eventId,
        eventType: 'payment_intent.succeeded',
        status: 'PROCESSED',
        processedAt: new Date(),
        createdAt: new Date(),
        errorMessage: null,
        paymentIntentId,
      });

      const txSpy = vi.spyOn(prisma, '$transaction');

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(200);
      expect(res.body.duplicate).toBe(true);
      expect(txSpy).not.toHaveBeenCalled();
    });

    it('should reject settlement and log security event on amount mismatch', async () => {
      const mockEvent = {
        id: 'evt_amount_mismatch',
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: paymentIntentId,
            amount: 50000, // 500.00 EUR instead of 860.00 EUR
            currency: 'eur',
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);
      const eventCreateSpy = vi.spyOn(prisma.stripePaymentEvent, 'create').mockResolvedValue({} as any);
      const txSpy = vi.spyOn(prisma, '$transaction');

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.message).toContain('amount mismatch');
      expect(eventCreateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'AMOUNT_MISMATCH_REJECTED',
          }),
        })
      );
      expect(txSpy).not.toHaveBeenCalled();
    });

    it('should reject settlement and log security event on currency mismatch', async () => {
      const mockEvent = {
        id: 'evt_currency_mismatch',
        type: 'payment_intent.succeeded',
        data: {
          object: {
            id: paymentIntentId,
            amount: 86000,
            currency: 'usd', // USD instead of EUR
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);
      const eventCreateSpy = vi.spyOn(prisma.stripePaymentEvent, 'create').mockResolvedValue({} as any);
      const txSpy = vi.spyOn(prisma, '$transaction');

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.message).toContain('currency mismatch');
      expect(eventCreateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'CURRENCY_MISMATCH_REJECTED',
          }),
        })
      );
      expect(txSpy).not.toHaveBeenCalled();
    });
  });

  describe('POST /api/v1/webhooks/stripe - Payment Failure, Processing, and Cancellation', () => {
    it('should handle payment_intent.payment_failed by recording failure details without activating investment', async () => {
      const mockEvent = {
        id: 'evt_failed_001',
        type: 'payment_intent.payment_failed',
        data: {
          object: {
            id: paymentIntentId,
            last_payment_error: {
              code: 'card_declined',
              message: 'Your card has insufficient funds.',
            },
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);
      const updateSpy = vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);
      const investmentUpdateSpy = vi.spyOn(prisma.investment, 'update');

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(200);
      expect(updateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: TransactionStatus.FAILED,
            failureCode: 'card_declined',
            failureMessage: 'Your card has insufficient funds.',
          }),
        })
      );
      expect(investmentUpdateSpy).not.toHaveBeenCalled();
    });

    it('should handle payment_intent.processing by keeping investment pending', async () => {
      const mockEvent = {
        id: 'evt_processing_001',
        type: 'payment_intent.processing',
        data: {
          object: {
            id: paymentIntentId,
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);
      const updateSpy = vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(200);
      expect(updateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            stripePaymentStatus: 'processing',
          }),
        })
      );
    });

    it('should handle payment_intent.canceled by updating transaction status to CANCELLED', async () => {
      const mockEvent = {
        id: 'evt_canceled_001',
        type: 'payment_intent.canceled',
        data: {
          object: {
            id: paymentIntentId,
          },
        },
      };

      vi.spyOn(stripeClient.webhooks, 'constructEvent').mockReturnValue(mockEvent as any);
      vi.spyOn(prisma.stripePaymentEvent, 'findUnique').mockResolvedValue(null);
      vi.spyOn(prisma.paymentTransaction, 'findFirst').mockResolvedValue(mockPaymentTx as any);
      const updateSpy = vi.spyOn(prisma.paymentTransaction, 'update').mockResolvedValue({} as any);

      const res = await request(app)
        .post('/api/v1/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', 't=123,v1=valid_sig')
        .send(JSON.stringify(mockEvent));

      expect(res.status).toBe(200);
      expect(updateSpy).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: TransactionStatus.CANCELLED,
            stripePaymentStatus: 'canceled',
          }),
        })
      );
    });
  });
});
