import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { ResalePlan, Currency, InvestmentStatus, Prisma, UserRole } from '@prisma/client';

describe('Investment & Authoritative Pricing API (/api/v1/investments)', () => {
  const testProductId = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  const cheapProductId = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
  const limitedStockProductId = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
  const testAddressId = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';

  const mockInvestor1 = {
    id: '11111111-1111-4111-8111-111111111111',
    email: 'investor1@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: '22222222-2222-4222-8222-222222222222',
      fullName: 'Investor One',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-INV1',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockInvestor2 = {
    id: '33333333-3333-4333-8333-333333333333',
    email: 'investor2@xplain.com',
    phone: '+447400000002',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: '44444444-4444-4444-8444-444444444444',
      fullName: 'Investor Two',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-INV2',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockProduct = {
    id: testProductId,
    categoryId: '55555555-5555-4555-8555-555555555555',
    ref: 'INV-TEST-001',
    name: 'Smart Induction Cooktop',
    priceEUR: new Prisma.Decimal('500.00'),
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=500',
    stockQuantity: 100,
    isActive: true,
  };

  const mockCheapProduct = {
    id: cheapProductId,
    categoryId: '55555555-5555-4555-8555-555555555555',
    ref: 'INV-CHEAP-001',
    name: 'Spare Cable Accessory',
    priceEUR: new Prisma.Decimal('0.50'),
    imageUrl: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=500',
    stockQuantity: 100,
    isActive: true,
  };

  const mockLimitedStockProduct = {
    id: limitedStockProductId,
    categoryId: '55555555-5555-4555-8555-555555555555',
    ref: 'INV-LIMITED-001',
    name: 'Limited Espresso Machine',
    priceEUR: new Prisma.Decimal('400.00'),
    imageUrl: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500',
    stockQuantity: 2,
    isActive: true,
  };

  const mockCreatedInvestment = {
    id: '66666666-6666-4666-8666-666666666666',
    partnerProfileId: '22222222-2222-4222-8222-222222222222',
    resalePlan: ResalePlan.SELLFOR,
    status: InvestmentStatus.PAYMENT_PENDING,
    currency: Currency.EUR,
    subtotalInCurrency: new Prisma.Decimal('1000.00'),
    discountAmountInCurrency: new Prisma.Decimal('140.00'),
    totalAmountInCurrency: new Prisma.Decimal('860.00'),
    totalAmountEUR: new Prisma.Decimal('860.00'),
    exchangeRateToEUR: new Prisma.Decimal('1.00000000'),
    deliveryAddressId: null,
    idempotencyKey: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [
      {
        id: '77777777-7777-4777-8777-777777777777',
        investmentId: '66666666-6666-4666-8666-666666666666',
        productId: testProductId,
        productRef: 'INV-TEST-001',
        productName: 'Smart Induction Cooktop',
        unitPriceEUR: new Prisma.Decimal('500.00'),
        discountMultiplier: new Prisma.Decimal('0.86'),
        quantity: 2,
        lineTotalEUR: new Prisma.Decimal('860.00'),
      },
    ],
    paymentTransactions: [
      {
        id: '88888888-8888-4888-8888-888888888888',
        referenceNumber: 'TX-INV-TEST123',
        status: 'PENDING',
        amount: new Prisma.Decimal('860.00'),
        currency: Currency.EUR,
      },
    ],
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.exchangeRateSnapshot, 'findFirst').mockResolvedValue(null);
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({} as any);
  });

  describe('POST /api/v1/investments/quote', () => {
    it('should calculate Option A quote with 0% discount and 0% monthly return', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);

      const res = await request(app)
        .post('/api/v1/investments/quote')
        .send({
          resalePlan: 'DIRECT',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 2 }],
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.subtotalEUR).toBe('1000');
      expect(res.body.data.discountMultiplier).toBe('1');
      expect(res.body.data.totalAmountEUR).toBe('1000');
      expect(res.body.data.monthlyReturnRate).toBe('0');
      expect(res.body.data.estimatedMonthlyReturnEUR).toBe('0');
      expect(res.body.data.lockDurationMonths).toBe(0);
      expect(new Date(res.body.data.expiresAt).getTime()).toBeGreaterThan(Date.now());
    });

    it('should calculate Option B quote with 14% discount and 7% monthly return', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);

      const res = await request(app)
        .post('/api/v1/investments/quote')
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 2 }],
        });

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.subtotalEUR).toBe('1000');
      expect(res.body.data.discountMultiplier).toBe('0.86');
      expect(res.body.data.discountAmountEUR).toBe('140');
      expect(res.body.data.totalAmountEUR).toBe('860');
      expect(res.body.data.monthlyReturnRate).toBe('0.07');
      expect(res.body.data.estimatedMonthlyReturnEUR).toBe('60.2'); // 860 * 0.07 = 60.20
      expect(res.body.data.lockDurationMonths).toBe(12);
    });

    it('should reject quotes below the minimum €1.00 threshold with 422 UNPROCESSABLE_ENTITY', async () => {
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockCheapProduct] as any);

      const res = await request(app)
        .post('/api/v1/investments/quote')
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: cheapProductId, quantity: 1 }], // 0.50 EUR << 1.00 EUR min
        });

      expect(res.status).toBe(422);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('UNPROCESSABLE_ENTITY');
      expect(res.body.error.message).toMatch(/below the minimum required threshold/i);
    });
  });

  describe('POST /api/v1/investments', () => {
    it('should create real investment in PostgreSQL with pending payment and decrement stock', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findFirst').mockResolvedValueOnce(null);
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);

      // Mock interactive transaction
      vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => {
        const mockTx = {
          product: {
            findUnique: vi.fn().mockResolvedValue(mockProduct),
            update: vi.fn().mockResolvedValue({ ...mockProduct, stockQuantity: 98 }),
          },
          investment: {
            create: vi.fn().mockResolvedValue(mockCreatedInvestment),
          },
          investmentItem: {
            createMany: vi.fn().mockResolvedValue({ count: 1 }),
          },
          paymentTransaction: {
            create: vi.fn().mockResolvedValue(mockCreatedInvestment.paymentTransactions[0]),
          },
        };
        return cb(mockTx);
      });

      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValueOnce(mockCreatedInvestment as any);

      const res = await request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 2 }],
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.status).toBe(InvestmentStatus.PAYMENT_PENDING);
      expect(res.body.data.totalAmountEUR).toBe('860');
      expect(res.body.data.items.length).toBe(1);
      expect(res.body.data.paymentTransactions[0].status).toBe('PENDING');
    });

    it('should reject investment if requested quantity exceeds available stock with 409 CONFLICT', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findFirst').mockResolvedValueOnce(null);
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockLimitedStockProduct] as any);

      const res = await request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: limitedStockProductId, quantity: 5 }], // Stock is only 2
        });

      expect(res.status).toBe(409);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('CONFLICT');
      expect(res.body.error.message).toMatch(/insufficient stock/i);
    });

    it('should allow Option A (DIRECT) investment creation with pending payment without requiring delivery address upfront', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findFirst').mockResolvedValueOnce(null);
      vi.spyOn(prisma.product, 'findMany').mockResolvedValueOnce([mockProduct] as any);

      const mockOptionAInvestment = {
        ...mockCreatedInvestment,
        resalePlan: ResalePlan.DIRECT,
        discountAmountInCurrency: new Prisma.Decimal('0.00'),
        totalAmountInCurrency: new Prisma.Decimal('1000.00'),
        totalAmountEUR: new Prisma.Decimal('1000.00'),
        deliveryAddressId: null,
      };

      vi.spyOn(prisma, '$transaction').mockImplementationOnce(async (cb: any) => {
        const mockTx = {
          product: {
            findUnique: vi.fn().mockResolvedValue(mockProduct),
            update: vi.fn().mockResolvedValue({ ...mockProduct, stockQuantity: 98 }),
          },
          investment: {
            create: vi.fn().mockResolvedValue(mockOptionAInvestment),
          },
          investmentItem: {
            createMany: vi.fn().mockResolvedValue({ count: 1 }),
          },
          paymentTransaction: {
            create: vi.fn().mockResolvedValue(mockCreatedInvestment.paymentTransactions[0]),
          },
        };
        return cb(mockTx);
      });

      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValueOnce(mockOptionAInvestment as any);

      const res = await request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .send({
          resalePlan: 'DIRECT',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 2 }],
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.resalePlan).toBe('DIRECT');
      expect(res.body.data.totalAmountEUR).toBe('1000');
    });

    it('should enforce idempotency and return existing investment if duplicate key is received', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findFirst').mockResolvedValueOnce({
        ...mockCreatedInvestment,
        idempotencyKey: 'KEY-IDEMP-123',
      } as any);

      const res = await request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .set('Idempotency-Key', 'KEY-IDEMP-123')
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 2 }],
        });

      expect(res.status).toBe(201);
      expect(res.body.data.id).toBe('66666666-6666-4666-8666-666666666666');
    });
  });

  describe('GET /api/v1/investments & GET /api/v1/investments/:id (Ownership Protection)', () => {
    it('should return investments for the authenticated owner', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findMany').mockResolvedValueOnce([mockCreatedInvestment] as any);
      vi.spyOn(prisma.investment, 'count').mockResolvedValueOnce(1);

      const res = await request(app)
        .get('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.investments.length).toBe(1);
    });

    it('should allow owner to access their own investment by ID', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor1);
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValueOnce(mockCreatedInvestment as any);

      const res = await request(app)
        .get('/api/v1/investments/66666666-6666-4666-8666-666666666666')
        .set('Cookie', ['xplain_session=valid_token']);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.id).toBe('66666666-6666-4666-8666-666666666666');
    });

    it('should reject another user attempting to access investment with 403 FORBIDDEN (IDOR protection)', async () => {
      vi.spyOn(AuthService, 'validateSession').mockResolvedValueOnce(mockInvestor2); // User 2 session
      vi.spyOn(prisma.investment, 'findUnique').mockResolvedValueOnce(mockCreatedInvestment as any); // Owned by User 1

      const res = await request(app)
        .get('/api/v1/investments/66666666-6666-4666-8666-666666666666')
        .set('Cookie', ['xplain_session=user2_token']);

      expect(res.status).toBe(403);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('FORBIDDEN');
    });
  });
});
