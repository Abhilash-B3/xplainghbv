import { describe, it, expect, vi } from 'vitest';
import { runLedgerReconciliation } from '../src/utils/reconciliation.js';
import { prisma } from '../src/config/database.js';
import { Prisma, EntryType, AccountType, Currency } from '@prisma/client';

describe('Financial Ledger Reconciliation Audit', () => {
  it('should verify that all ledger transactions in PostgreSQL are strictly balanced (Debits === Credits)', async () => {
    const mockTx = [
      {
        id: 'tx-1',
        referenceNumber: 'LEDGER-001',
        description: 'Test investment funding',
        sourceEntity: 'Investment',
        sourceEntityId: 'inv-1',
        createdAt: new Date(),
        entries: [
          {
            id: 'entry-1',
            transactionId: 'tx-1',
            accountId: 'acc-escrow',
            entryType: EntryType.DEBIT,
            amount: new Prisma.Decimal('1000.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('1000.0000'),
            createdAt: new Date(),
          },
          {
            id: 'entry-2',
            transactionId: 'tx-1',
            accountId: 'acc-locked',
            entryType: EntryType.CREDIT,
            amount: new Prisma.Decimal('1000.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('1000.0000'),
            createdAt: new Date(),
          },
        ],
      },
    ];

    const mockAccounts = [
      {
        id: 'acc-escrow',
        partnerProfileId: null,
        accountType: AccountType.PLATFORM_ESCROW,
        currency: Currency.EUR,
        createdAt: new Date(),
        updatedAt: new Date(),
        ledgerEntries: [mockTx[0].entries[0]],
      },
      {
        id: 'acc-locked',
        partnerProfileId: 'profile-1',
        accountType: AccountType.LOCKED_CAPITAL,
        currency: Currency.EUR,
        createdAt: new Date(),
        updatedAt: new Date(),
        ledgerEntries: [mockTx[0].entries[1]],
      },
    ];

    vi.spyOn(prisma.ledgerTransaction, 'findMany').mockResolvedValueOnce(mockTx as any);
    vi.spyOn(prisma.financialAccount, 'findMany').mockResolvedValueOnce(mockAccounts as any);

    const report = await runLedgerReconciliation();

    expect(report.isBalanced).toBe(true);
    expect(report.imbalancedTransactions).toEqual([]);
    expect(report.totalTransactionsChecked).toBe(1);
    expect(report.totalAccountsChecked).toBe(2);
  });

  it('should detect and report imbalanced transactions if debits != credits', async () => {
    const imbalancedTx = [
      {
        id: 'tx-bad',
        referenceNumber: 'LEDGER-CORRUPTED',
        description: 'Corrupted transaction',
        sourceEntity: 'Test',
        sourceEntityId: 'bad-1',
        createdAt: new Date(),
        entries: [
          {
            id: 'entry-1',
            transactionId: 'tx-bad',
            accountId: 'acc-escrow',
            entryType: EntryType.DEBIT,
            amount: new Prisma.Decimal('1000.0000'),
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('1000.0000'),
            createdAt: new Date(),
          },
          {
            id: 'entry-2',
            transactionId: 'tx-bad',
            accountId: 'acc-locked',
            entryType: EntryType.CREDIT,
            amount: new Prisma.Decimal('800.0000'), // Imbalance of 200 EUR
            currency: Currency.EUR,
            amountEUR: new Prisma.Decimal('800.0000'),
            createdAt: new Date(),
          },
        ],
      },
    ];

    vi.spyOn(prisma.ledgerTransaction, 'findMany').mockResolvedValueOnce(imbalancedTx as any);
    vi.spyOn(prisma.financialAccount, 'findMany').mockResolvedValueOnce([] as any);

    const report = await runLedgerReconciliation();

    expect(report.isBalanced).toBe(false);
    expect(report.imbalancedTransactions.length).toBe(1);
    expect(report.imbalancedTransactions[0].referenceNumber).toBe('LEDGER-CORRUPTED');
    expect(report.imbalancedTransactions[0].difference).toBe('200');
  });
});
