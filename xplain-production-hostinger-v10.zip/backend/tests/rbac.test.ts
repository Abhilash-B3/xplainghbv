import { describe, it, expect } from 'vitest';
import request from 'supertest';
import express, { type Express } from 'express';
import cookieParser from 'cookie-parser';
import { requireAuth, requireRole, type AuthenticatedRequest } from '../src/middleware/auth.js';
import { errorHandler } from '../src/middleware/errorHandler.js';
import { AuthService } from '../src/services/auth.service.js';

describe('RBAC Authorization Middleware (requireRole)', () => {
  const testApp: Express = express();
  testApp.use(cookieParser());

  // Setup test protected routes
  testApp.get('/test-investor-only', requireAuth, requireRole('INVESTOR'), (_req, res) => {
    res.json({ success: true, message: 'Welcome Investor' });
  });

  testApp.get('/test-admin-only', requireAuth, requireRole('ADMIN', 'SUPERADMIN'), (_req, res) => {
    res.json({ success: true, message: 'Welcome Admin' });
  });

  testApp.use(errorHandler);

  it('should allow INVESTOR role to access investor-only endpoint', async () => {
    // Mock AuthService.validateSession to return an INVESTOR user
    const originalValidate = AuthService.validateSession;
    AuthService.validateSession = async () => ({
      id: 'mock-investor-id',
      email: 'investor@test.com',
      phone: '+23300000000',
      role: 'INVESTOR',
      status: 'ACTIVE',
      isEmailVerified: true,
      isPhoneVerified: false,
      twoFactorEnabled: false,
      createdAt: new Date(),
      partnerProfile: null,
    });

    const res = await request(testApp)
      .get('/test-investor-only')
      .set('Cookie', ['xplain_session=valid_token']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);

    AuthService.validateSession = originalValidate;
  });

  it('should block INVESTOR role from accessing admin-only endpoint with 403 FORBIDDEN', async () => {
    const originalValidate = AuthService.validateSession;
    AuthService.validateSession = async () => ({
      id: 'mock-investor-id',
      email: 'investor@test.com',
      phone: '+23300000000',
      role: 'INVESTOR',
      status: 'ACTIVE',
      isEmailVerified: true,
      isPhoneVerified: false,
      twoFactorEnabled: false,
      createdAt: new Date(),
      partnerProfile: null,
    });

    const res = await request(testApp)
      .get('/test-admin-only')
      .set('Cookie', ['xplain_session=valid_token']);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
    expect(res.body.error.message).toContain("Role 'INVESTOR' is not authorized");

    AuthService.validateSession = originalValidate;
  });

  it('should allow ADMIN role to access admin-only endpoint', async () => {
    const originalValidate = AuthService.validateSession;
    AuthService.validateSession = async () => ({
      id: 'mock-admin-id',
      email: 'admin@test.com',
      phone: '+23300000001',
      role: 'ADMIN',
      status: 'ACTIVE',
      isEmailVerified: true,
      isPhoneVerified: false,
      twoFactorEnabled: false,
      createdAt: new Date(),
      partnerProfile: null,
    });

    const res = await request(testApp)
      .get('/test-admin-only')
      .set('Cookie', ['xplain_session=valid_token']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);

    AuthService.validateSession = originalValidate;
  });
});
