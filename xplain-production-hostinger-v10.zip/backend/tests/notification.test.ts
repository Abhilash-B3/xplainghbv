import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import {
  Currency,
  UserRole,
  NotificationType,
} from '@prisma/client';

describe('Phase 7 — In-App Notifications & Preference Management', () => {
  const user1Id = '11111111-1111-4111-8111-111111111111';
  const notif1Id = '22222222-2222-4222-8222-222222222222';

  const mockUser1 = {
    id: user1Id,
    email: 'user1@xplain.com',
    phone: '+447300000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: 'profile-1',
      fullName: 'User One',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-USER1',
      kycStatus: 'VERIFIED' as const,
    },
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({ id: 'audit-id' } as any);
  });

  it('should list notifications for user and calculate unread count', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
    vi.spyOn(prisma.notification, 'findMany').mockResolvedValue([
      {
        id: notif1Id,
        userId: user1Id,
        type: NotificationType.INVESTMENT,
        title: 'Investment Confirmed',
        message: 'Your investment of €1,000.00 is active.',
        readAt: null,
        createdAt: new Date(),
      } as any,
    ]);
    vi.spyOn(prisma.notification, 'count')
      .mockResolvedValueOnce(1) // total
      .mockResolvedValueOnce(1); // unread

    const res = await request(app)
      .get('/api/v1/notifications')
      .set('Cookie', ['xplain_session=test-session-user1']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.notifications.length).toBe(1);
    expect(res.body.data.unreadCount).toBe(1);
    expect(res.body.data.notifications[0].title).toBe('Investment Confirmed');
  });

  it('should get unread count via /unread-count endpoint', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
    vi.spyOn(prisma.notification, 'count').mockResolvedValue(3);

    const res = await request(app)
      .get('/api/v1/notifications/unread-count')
      .set('Cookie', ['xplain_session=test-session-user1']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.unreadCount).toBe(3);
  });

  it('should mark an individual notification as read', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
    vi.spyOn(prisma.notification, 'findUnique').mockResolvedValue({
      id: notif1Id,
      userId: user1Id,
      title: 'Test',
      message: 'Test message',
      type: NotificationType.SYSTEM,
      readAt: null,
      createdAt: new Date(),
      eventKey: null,
      metadata: null,
    });
    vi.spyOn(prisma.notification, 'update').mockResolvedValue({
      id: notif1Id,
      userId: user1Id,
      title: 'Test',
      message: 'Test message',
      type: NotificationType.SYSTEM,
      readAt: new Date(),
      createdAt: new Date(),
      eventKey: null,
      metadata: null,
    });

    const res = await request(app)
      .patch(`/api/v1/notifications/${notif1Id}/read`)
      .set('Cookie', ['xplain_session=test-session-user1']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });

  it('should mark all notifications as read', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockUser1 as any);
    vi.spyOn(prisma.notification, 'updateMany').mockResolvedValue({ count: 5 });

    const res = await request(app)
      .patch('/api/v1/notifications/read-all')
      .set('Cookie', ['xplain_session=test-session-user1']);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });
});
