import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import * as databaseModule from '../src/config/database.js';
import * as redisModule from '../src/config/redis.js';

describe('Security Middlewares & Headers', () => {
  beforeEach(() => {
    vi.spyOn(databaseModule, 'checkDatabaseHealth').mockResolvedValue({
      status: 'healthy',
      latencyMs: 1,
    });
    vi.spyOn(redisModule, 'checkRedisHealth').mockResolvedValue({
      status: 'healthy',
      latencyMs: 1,
    });
  });

  it('should generate and return an X-Request-Id header when none is provided', async () => {
    const res = await request(app).get('/api/v1/health');

    expect(res.headers).toHaveProperty('x-request-id');
    expect(typeof res.headers['x-request-id']).toBe('string');
    expect(res.headers['x-request-id'].length).toBeGreaterThan(10);
  });

  it('should preserve and reflect client-provided X-Request-Id header', async () => {
    const customId = 'req-custom-audit-tracing-12345';
    const res = await request(app)
      .get('/api/v1/health')
      .set('X-Request-Id', customId);

    expect(res.headers).toHaveProperty('x-request-id');
    expect(res.headers['x-request-id']).toBe(customId);
  });

  it('should set security headers via Helmet', async () => {
    const res = await request(app).get('/api/v1/health');

    expect(res.headers).toHaveProperty('x-content-type-options', 'nosniff');
    expect(res.headers).toHaveProperty('x-frame-options');
  });

  it('should reject unauthorized cross-origin requests with CORS error', async () => {
    const res = await request(app)
      .get('/api/v1/health')
      .set('Origin', 'https://malicious-phishing-site.example.com');

    // CORS middleware with custom callback rejects with error in Express
    expect(res.status).toBe(500);
    expect(res.body.error.message).toContain('not allowed by CORS policy');
  });

  it('should allow whitelisted frontend origin with proper CORS headers', async () => {
    const res = await request(app)
      .get('/api/v1/health')
      .set('Origin', 'http://localhost:3000');

    expect(res.status).toBe(200);
    expect(res.headers['access-control-allow-origin']).toBe('http://localhost:3000');
    expect(res.headers['access-control-allow-credentials']).toBe('true');
  });
});
