import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/database.js';
import { AuthService } from '../src/services/auth.service.js';
import { PayoutService } from '../src/services/payout.service.js';
import { LedgerService } from '../src/services/ledger.service.js';
import { ResalePlan, Currency, InvestmentStatus, Prisma, UserRole, PayoutStatus } from '@prisma/client';

describe('Financial Concurrency & Race Condition Protections', () => {
  const testProductId = '99999999-9999-4999-8999-999999999999';

  const mockInvestor = {
    id: '11111111-1111-4111-8111-111111111111',
    email: 'concurrency@xplain.com',
    phone: '+447600000001',
    role: UserRole.INVESTOR,
    status: 'ACTIVE' as const,
    isEmailVerified: true,
    isPhoneVerified: true,
    twoFactorEnabled: false,
    createdAt: new Date(),
    partnerProfile: {
      id: '22222222-2222-4222-8222-222222222222',
      fullName: 'Concurrency Test User',
      preferredCurrency: Currency.EUR,
      referralCode: 'XP-CONC1',
      kycStatus: 'VERIFIED' as const,
      resalePlan: ResalePlan.SELLFOR,
    },
  };

  const mockProduct = {
    id: testProductId,
    categoryId: '33333333-3333-4333-8333-333333333333',
    ref: 'CONC-SINGLE-001',
    name: 'Last Unit Luxury Oven',
    priceEUR: new Prisma.Decimal('600.00'),
    imageUrl: 'https://images.unsplash.com/photo-1588854337236-6889d631faa8?w=500',
    stockQuantity: 1,
    isActive: true,
  };

  const mockCreatedInvestment = {
    id: '44444444-4444-4444-8444-444444444444',
    partnerProfileId: '22222222-2222-4222-8222-222222222222',
    resalePlan: ResalePlan.SELLFOR,
    status: InvestmentStatus.PAYMENT_PENDING,
    currency: Currency.EUR,
    subtotalInCurrency: new Prisma.Decimal('600.00'),
    discountAmountInCurrency: new Prisma.Decimal('84.00'),
    totalAmountInCurrency: new Prisma.Decimal('516.00'),
    totalAmountEUR: new Prisma.Decimal('516.00'),
    exchangeRateToEUR: new Prisma.Decimal('1.00000000'),
    deliveryAddressId: null,
    idempotencyKey: 'CONC-KEY-1',
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [],
    paymentTransactions: [{ id: 'pay-1', status: 'PENDING' }],
  };

  beforeEach(() => {
    vi.restoreAllMocks();
    vi.spyOn(prisma.exchangeRateSnapshot, 'findFirst').mockResolvedValue(null);
    vi.spyOn(prisma.auditLog, 'create').mockResolvedValue({} as any);
  });

  it('should handle simultaneous investment requests with the same idempotency key safely', async () => {
    vi.spyOn(AuthService, 'validateSession').mockResolvedValue(mockInvestor);

    // First lookup finds nothing, second lookup finds the created one
    let created = false;
    vi.spyOn(prisma.investment, 'findFirst').mockImplementation(async () => {
      if (created) return mockCreatedInvestment as any;
      created = true;
      return null;
    });

    vi.spyOn(prisma.product, 'findMany').mockResolvedValue([mockProduct] as any);

    vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
      const mockTx = {
        product: {
          findUnique: vi.fn().mockResolvedValue(mockProduct),
          update: vi.fn().mockResolvedValue({ ...mockProduct, stockQuantity: 0 }),
        },
        investment: {
          create: vi.fn().mockResolvedValue(mockCreatedInvestment),
        },
        investmentItem: {
          createMany: vi.fn().mockResolvedValue({ count: 1 }),
        },
        paymentTransaction: {
          create: vi.fn().mockResolvedValue(mockCreatedInvestment.paymentTransactions[0]),
        },
      };
      return cb(mockTx);
    });

    vi.spyOn(prisma.investment, 'findUnique').mockResolvedValue(mockCreatedInvestment as any);

    const [res1, res2] = await Promise.all([
      request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .set('Idempotency-Key', 'CONC-KEY-1')
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 1 }],
        }),
      request(app)
        .post('/api/v1/investments')
        .set('Cookie', ['xplain_session=valid_token'])
        .set('Idempotency-Key', 'CONC-KEY-1')
        .send({
          resalePlan: 'SELLFOR',
          currency: 'EUR',
          items: [{ productId: testProductId, quantity: 1 }],
        }),
    ]);

    expect(res1.status).toBe(201);
    expect(res2.status).toBe(201);
    expect(res1.body.data.id).toBe(res2.body.data.id);
  });

  it('should process concurrent payout executions without double-crediting', async () => {
    const mockPayout = {
      id: 'payout-conc-1',
      batchId: 'batch-conc-1',
      partnerProfileId: '22222222-2222-4222-8222-222222222222',
      payoutIndex: 1,
      dueDate: new Date(),
      amountEUR: new Prisma.Decimal('36.12'),
      status: PayoutStatus.SCHEDULED,
      paidAt: null,
      batch: { id: 'batch-conc-1' },
      partnerProfile: { id: '22222222-2222-4222-8222-222222222222' },
    };

    let callCount = 0;
    vi.spyOn(prisma, '$transaction').mockImplementation(async (cb: any) => {
      callCount++;
      const currentStatus = callCount === 1 ? PayoutStatus.SCHEDULED : PayoutStatus.PAID;
      const mockTx = {
        payout: {
          findUnique: vi.fn().mockResolvedValue({
            ...mockPayout,
            status: currentStatus,
            paidAt: currentStatus === PayoutStatus.PAID ? new Date() : null,
          }),
          update: vi.fn().mockResolvedValue({
            ...mockPayout,
            status: PayoutStatus.PAID,
            paidAt: new Date(),
          }),
        },
      };
      return cb(mockTx);
    });

    vi.spyOn(LedgerService, 'ensureSystemAccount').mockResolvedValue('acc-escrow-uuid');
    vi.spyOn(LedgerService, 'ensurePartnerAccount').mockResolvedValue('acc-returns-uuid');
    vi.spyOn(LedgerService, 'getAccountBalance').mockResolvedValue(new Prisma.Decimal('5000.0000'));
    const postSpy = vi.spyOn(LedgerService, 'postTransaction').mockResolvedValue({ id: 'tx-1' } as any);

    await Promise.all([
      PayoutService.processPayout('payout-conc-1'),
      PayoutService.processPayout('payout-conc-1'),
    ]);

    // postTransaction was called exactly once, preventing double credit
    expect(postSpy).toHaveBeenCalledTimes(1);
  });
});
