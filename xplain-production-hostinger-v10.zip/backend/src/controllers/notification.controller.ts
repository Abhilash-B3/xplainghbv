import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { NotificationService } from '../services/notification.service.js';
import { updateNotificationPreferencesSchema } from '../validators/notification.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';

export class NotificationController {
  /**
   * GET /api/v1/notifications
   * Lists notifications for authenticated user.
   */
  static async getMyNotifications(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const unreadOnly = req.query.unreadOnly === 'true';
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 20;
      const offset = req.query.offset ? parseInt(String(req.query.offset), 10) : 0;

      const result = await NotificationService.getUserNotifications(
        req.user!.id,
        unreadOnly,
        limit,
        offset
      );

      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/notifications/unread-count
   */
  static async getUnreadCount(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const count = await NotificationService.getUnreadCount(req.user!.id);
      sendSuccess(res, { unreadCount: count });
    } catch (err) {
      next(err);
    }
  }

  /**
   * PATCH /api/v1/notifications/:id/read
   */
  static async markAsRead(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const notificationId = String(req.params.id || '');
      const updated = await NotificationService.markAsRead(notificationId, req.user!.id);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  /**
   * PATCH /api/v1/notifications/read-all
   */
  static async markAllAsRead(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const result = await NotificationService.markAllAsRead(req.user!.id);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/notifications/preferences
   */
  static async getPreferences(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const prefs = await NotificationService.getPreferences(req.user!.id);
      sendSuccess(res, prefs);
    } catch (err) {
      next(err);
    }
  }

  /**
   * PUT /api/v1/notifications/preferences
   */
  static async updatePreferences(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const input = updateNotificationPreferencesSchema.parse(req.body);
      const updated = await NotificationService.updatePreferences(req.user!.id, input);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }
}
