import type { Response, NextFunction } from 'express';
import { FinancialService } from '../services/financial.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';

export class FinancialController {
  /**
   * Get the authoritative financial summary of the authenticated user from PostgreSQL ledger.
   */
  static async getMyFinancialSummary(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user || !req.user.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const summary = await FinancialService.getPartnerFinancialSummary(req.user.partnerProfile.id);
      sendSuccess(res, summary);
    } catch (err) {
      next(err);
    }
  }
}
