import type { Response, NextFunction } from 'express';
import { InvestmentService } from '../services/investment.service.js';
import { PricingService } from '../services/pricing.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import { quoteRequestSchema, createInvestmentSchema } from '../validators/investment.validator.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { UserRole } from '@prisma/client';

export class InvestmentController {
  /**
   * Request an authoritative quote for investment items and resale plan.
   */
  static async requestQuote(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const input = quoteRequestSchema.parse(req.body);
      const quote = await PricingService.calculateQuote({
        items: input.items,
        resalePlan: input.resalePlan,
        currency: input.currency,
      });

      sendSuccess(res, quote);
    } catch (err) {
      next(err);
    }
  }

  /**
   * Create a real investment intent in PostgreSQL.
   */
  static async createInvestment(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user || !req.user.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = createInvestmentSchema.parse(req.body);
      const idempotencyKey = (req.headers['idempotency-key'] as string) || (req.body.idempotencyKey as string);

      const investment = await InvestmentService.createInvestment({
        partnerProfileId: req.user.partnerProfile.id,
        resalePlan: input.resalePlan,
        currency: input.currency,
        items: input.items,
        deliveryAddressId: input.deliveryAddressId,
        idempotencyKey,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
        userId: req.user.id,
      });

      sendSuccess(res, investment, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  /**
   * List investments for the authenticated partner profile.
   */
  static async listInvestments(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        throw AppError.unauthorized('Authentication required');
      }

      const page = req.query.page ? Number(req.query.page) : 1;
      const limit = req.query.limit ? Number(req.query.limit) : 20;
      const status = req.query.status as any;

      const isAdmin = req.user.role === UserRole.ADMIN || req.user.role === UserRole.SUPERADMIN;
      const partnerProfileId = isAdmin && req.query.partnerProfileId
        ? String(req.query.partnerProfileId)
        : req.user.partnerProfile?.id;

      if (!partnerProfileId && !isAdmin) {
        sendSuccess(res, { investments: [], pagination: { page: 1, limit, total: 0, totalPages: 0 } });
        return;
      }

      const result = await InvestmentService.getInvestments({
        partnerProfileId: partnerProfileId || undefined,
        status,
        page,
        limit,
      });

      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  /**
   * Get single investment detail with ownership protection.
   */
  static async getInvestment(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user || !req.user.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const id = String(req.params.id);
      const isAdmin = req.user.role === UserRole.ADMIN || req.user.role === UserRole.SUPERADMIN;

      const investment = await InvestmentService.getInvestmentById(
        id,
        req.user.partnerProfile.id,
        isAdmin
      );

      sendSuccess(res, investment);
    } catch (err) {
      next(err);
    }
  }
}
