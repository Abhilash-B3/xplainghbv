import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { DestinationService } from '../services/destination.service.js';
import { createBankAccountSchema, createMoMoAccountSchema } from '../validators/destination.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';

export class DestinationController {
  // ─── Bank Accounts ──────────────────────────────────────────────────

  static async addBankAccount(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = createBankAccountSchema.parse(req.body);

      const account = await DestinationService.addBankAccount({
        partnerProfileId: req.user.partnerProfile.id,
        bankName: input.bankName,
        accountNumber: input.accountNumber,
        sortCodeOrSwift: input.sortCodeOrSwift,
        accountHolderName: input.accountHolderName,
        currency: input.currency,
        country: input.country,
        userId: req.user.id,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, account, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  static async listBankAccounts(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const accounts = await DestinationService.listBankAccounts(req.user.partnerProfile.id);
      sendSuccess(res, { accounts });
    } catch (err) {
      next(err);
    }
  }

  static async deleteBankAccount(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const id = String(req.params.id || '');
      const result = await DestinationService.deleteBankAccount(id, req.user.partnerProfile.id, req.user.id);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  // ─── MoMo Accounts (Withdrawal Only) ────────────────────────────────

  static async addMoMoAccount(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = createMoMoAccountSchema.parse(req.body);

      const account = await DestinationService.addMoMoAccount({
        partnerProfileId: req.user.partnerProfile.id,
        provider: input.provider,
        phoneNumber: input.phoneNumber,
        accountHolderName: input.accountHolderName,
        country: input.country,
        userId: req.user.id,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, account, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  static async listMoMoAccounts(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const accounts = await DestinationService.listMoMoAccounts(req.user.partnerProfile.id);
      sendSuccess(res, { accounts });
    } catch (err) {
      next(err);
    }
  }

  static async deleteMoMoAccount(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const id = String(req.params.id || '');
      const result = await DestinationService.deleteMoMoAccount(id, req.user.partnerProfile.id, req.user.id);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }
}
