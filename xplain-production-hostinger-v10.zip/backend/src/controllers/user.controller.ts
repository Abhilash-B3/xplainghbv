import type { Response, NextFunction } from 'express';
import { UserService } from '../services/user.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { AppError } from '../utils/appError.js';

export async function getMe(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.user) {
      throw AppError.unauthorized('Authentication required');
    }

    const profile = await UserService.getProfile(req.user.id);
    sendSuccess(res, { user: profile }, undefined, 200);
  } catch (error) {
    next(error);
  }
}

export async function updateMe(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.user) {
      throw AppError.unauthorized('Authentication required');
    }

    const updated = await UserService.updateProfile(req.user.id, req.body);
    sendSuccess(res, { user: updated }, undefined, 200);
  } catch (error) {
    next(error);
  }
}
