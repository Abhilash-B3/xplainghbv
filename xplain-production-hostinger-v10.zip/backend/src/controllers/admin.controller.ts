import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { AdminService } from '../services/admin.service.js';
import { WithdrawalService } from '../services/withdrawal.service.js';
import { ReconciliationService } from '../services/reconciliation.service.js';
import {
  adminUserListQuerySchema,
  adminInvestmentListQuerySchema,
  adminWithdrawalListQuerySchema,
  updateUserStatusSchema,
  updateUserRoleSchema,
} from '../validators/admin.validator.js';
import {
  completeWithdrawalSchema,
  rejectWithdrawalSchema,
} from '../validators/withdrawal.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import { UserRole } from '@prisma/client';

export class AdminController {
  // ─── Users ──────────────────────────────────────────────────────────

  static async getUsers(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = adminUserListQuerySchema.parse(req.query);
      const result = await AdminService.getUsers(query);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  static async getUserDetails(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = String(req.params.id || '');
      const user = await AdminService.getUserDetails(userId);
      sendSuccess(res, user);
    } catch (err) {
      next(err);
    }
  }

  static async updateUserStatus(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = String(req.params.id || '');
      const input = updateUserStatusSchema.parse(req.body);

      const updated = await AdminService.updateUserStatus(userId, input.status, req.user!.id);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  static async updateUserRole(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (req.user?.role !== UserRole.SUPERADMIN) {
        throw AppError.forbidden('Only superadmins can change user roles');
      }

      const userId = String(req.params.id || '');
      const input = updateUserRoleSchema.parse(req.body);

      const updated = await AdminService.updateUserRole(userId, input.role, req.user!.id);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  // ─── Investments ────────────────────────────────────────────────────

  static async getInvestments(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = adminInvestmentListQuerySchema.parse(req.query);
      const result = await AdminService.getInvestments(query);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  // ─── Withdrawals Operations ─────────────────────────────────────────

  static async getWithdrawals(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = adminWithdrawalListQuerySchema.parse(req.query);
      const result = await AdminService.getWithdrawals(query);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  static async approveWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const withdrawalId = String(req.params.id || '');
      const updated = await WithdrawalService.approveWithdrawal(withdrawalId, req.user!.id);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  static async processWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const withdrawalId = String(req.params.id || '');
      const updated = await WithdrawalService.processWithdrawal(withdrawalId, req.user!.id);
      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  static async completeWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const withdrawalId = String(req.params.id || '');
      const input = completeWithdrawalSchema.parse(req.body);

      const updated = await WithdrawalService.completeWithdrawal({
        withdrawalId,
        adminUserId: req.user!.id,
        settlementReference: input.settlementReference,
        settlementProof: input.settlementProof,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  static async rejectWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const withdrawalId = String(req.params.id || '');
      const input = rejectWithdrawalSchema.parse(req.body);

      const updated = await WithdrawalService.rejectWithdrawal(
        withdrawalId,
        req.user!.id,
        input.reason
      );

      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }

  // ─── Referrals ──────────────────────────────────────────────────────

  static async getReferrals(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 20;
      const offset = req.query.offset ? parseInt(String(req.query.offset), 10) : 0;
      const result = await AdminService.getReferrals(limit, offset);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  // ─── Ledger & Audits ────────────────────────────────────────────────

  static async getLedgerTransactions(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 30;
      const offset = req.query.offset ? parseInt(String(req.query.offset), 10) : 0;
      const result = await AdminService.getLedgerTransactions(limit, offset);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  static async getAuditLogs(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 50;
      const offset = req.query.offset ? parseInt(String(req.query.offset), 10) : 0;
      const result = await AdminService.getAuditLogs(limit, offset);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  // ─── Financial Reconciliation ───────────────────────────────────────

  static async getReconciliation(_req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const report = await ReconciliationService.runReconciliation();
      sendSuccess(res, report);
    } catch (err) {
      next(err);
    }
  }
}
