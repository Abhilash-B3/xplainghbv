import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { ReferralService } from '../services/referral.service.js';
import { attributeReferralSchema, triggerMonthlyCommissionSchema } from '../validators/referral.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import { Currency } from '@prisma/client';

export class ReferralController {
  /**
   * POST /api/v1/referrals/attribute
   * Attributes the authenticated user to a referrer via code.
   */
  static async attribute(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = attributeReferralSchema.parse(req.body);

      const referral = await ReferralService.attributeReferral({
        refereeProfileId: req.user.partnerProfile.id,
        referralCode: input.referralCode,
        userId: req.user.id,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, referral, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/referrals/summary
   * Returns authoritative referral statistics, referees list, and commission history.
   */
  static async getSummary(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const currencyQuery = req.query.currency as Currency | undefined;
      const summary = await ReferralService.getReferralSummary(
        req.user.partnerProfile.id,
        currencyQuery
      );

      sendSuccess(res, summary);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/referrals/code
   * Retrieves partner referral code and sharing link.
   */
  static async getCode(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      sendSuccess(res, {
        referralCode: req.user.partnerProfile.referralCode,
        referralLink: `https://xplainghbv.com/ref/${req.user.partnerProfile.referralCode}`,
      });
    } catch (err) {
      next(err);
    }
  }

  /**
   * POST /api/v1/referrals/commissions/trigger-monthly (Admin only)
   * Manually or worker triggered monthly calculation.
   */
  static async triggerMonthlyCommissions(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const input = triggerMonthlyCommissionSchema.parse(req.body);
      const result = await ReferralService.calculateMonthlyCommissions(input.periodMonth);
      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }
}
