import type { Request, Response, NextFunction } from 'express';
import { getSystemHealth } from '../services/health.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import type { RequestWithId } from '../types/index.js';

export async function getHealth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { isHealthy, data } = await getSystemHealth();

    if (!isHealthy) {
      res.status(503).json({
        success: false,
        error: {
          code: 'DATABASE_ERROR',
          message: 'System database is unavailable or unhealthy',
          details: data,
          requestId: (req as RequestWithId).id,
        },
      });
      return;
    }

    sendSuccess(res, data, undefined, 200);
  } catch (error) {
    next(error);
  }
}
