import type { Response, NextFunction } from 'express';
import { StripeService } from '../services/stripe.service.js';
import { createPaymentIntentSchema } from '../validators/payment.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { UserRole } from '@prisma/client';

export class PaymentController {
  /**
   * POST /api/v1/payments/create-intent
   * Creates or retrieves a Stripe PaymentIntent for the authenticated user's investment.
   */
  static async createIntent(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user || !req.user.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = createPaymentIntentSchema.parse(req.body);
      const idempotencyKey = (req.headers['idempotency-key'] as string) || input.idempotencyKey;

      const result = await StripeService.createOrRetrievePaymentIntent({
        investmentId: input.investmentId,
        partnerProfileId: req.user.partnerProfile.id,
        userId: req.user.id,
        idempotencyKey,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/payments/:paymentTransactionId
   * Retrieves payment transaction status with strict ownership and IDOR protection.
   */
  static async getStatus(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const paymentTransactionId = String(req.params.paymentTransactionId || '');

      if (!paymentTransactionId) {
        throw AppError.badRequest('Payment transaction ID is required');
      }

      const isAdmin = req.user?.role === UserRole.ADMIN || req.user?.role === UserRole.SUPERADMIN;
      const partnerProfileId = req.user?.partnerProfile?.id || '';

      const status = await StripeService.getPaymentStatus(
        paymentTransactionId,
        partnerProfileId,
        isAdmin
      );

      sendSuccess(res, status);
    } catch (err) {
      next(err);
    }
  }
}
