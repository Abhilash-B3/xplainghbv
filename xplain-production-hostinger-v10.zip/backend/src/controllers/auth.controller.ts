import type { Response, NextFunction } from 'express';
import { AuthService } from '../services/auth.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { setSessionCookie, clearSessionCookie } from '../utils/cookie.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { AppError } from '../utils/appError.js';

export async function register(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const result = await AuthService.register({
      ...req.body,
      ipAddress: req.ip,
      userAgent: req.get('user-agent'),
    });

    setSessionCookie(res, result.sessionToken);
    sendSuccess(res, { user: result.user }, undefined, 201);
  } catch (error) {
    next(error);
  }
}

export async function login(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const result = await AuthService.login({
      ...req.body,
      ipAddress: req.ip,
      userAgent: req.get('user-agent'),
    });

    setSessionCookie(res, result.sessionToken);
    sendSuccess(res, { user: result.user }, undefined, 200);
  } catch (error) {
    next(error);
  }
}

export async function logout(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (req.sessionToken) {
      await AuthService.logout(req.sessionToken, req.user?.id);
    }
    clearSessionCookie(res);
    sendSuccess(res, { message: 'Successfully logged out' }, undefined, 200);
  } catch (error) {
    next(error);
  }
}

export async function me(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.user) {
      throw AppError.unauthorized('Authentication required');
    }
    sendSuccess(res, { user: req.user }, undefined, 200);
  } catch (error) {
    next(error);
  }
}

export async function changePassword(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.user) {
      throw AppError.unauthorized('Authentication required');
    }

    const { currentPassword, newPassword } = req.body;
    await AuthService.changePassword(
      req.user.id,
      currentPassword,
      newPassword,
      req.sessionToken
    );

    sendSuccess(res, { message: 'Password updated successfully' }, undefined, 200);
  } catch (error) {
    next(error);
  }
}

export async function forgotPassword(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { email } = req.body;
    await AuthService.forgotPassword(email);
    sendSuccess(
      res,
      {
        message:
          'If an account with that email exists, password reset instructions have been sent.',
      },
      undefined,
      200
    );
  } catch (error) {
    next(error);
  }
}

export async function resetPassword(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { token, newPassword } = req.body;
    await AuthService.resetPassword(token, newPassword);
    sendSuccess(
      res,
      { message: 'Password has been reset successfully. Please log in with your new password.' },
      undefined,
      200
    );
  } catch (error) {
    next(error);
  }
}

export async function verifyEmail(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const token = req.body.token || req.query.token;
    if (typeof token !== 'string') {
      throw AppError.badRequest('Verification token is required');
    }
    await AuthService.verifyEmail(token);
    sendSuccess(res, { message: 'Email address successfully verified.' }, undefined, 200);
  } catch (error) {
    next(error);
  }
}
