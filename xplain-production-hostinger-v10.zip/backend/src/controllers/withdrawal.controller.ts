import type { Response, NextFunction } from 'express';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { WithdrawalService } from '../services/withdrawal.service.js';
import { requestWithdrawalSchema } from '../validators/withdrawal.validator.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { AppError } from '../utils/appError.js';
import { UserRole } from '@prisma/client';

export class WithdrawalController {
  /**
   * POST /api/v1/withdrawals
   * Creates a withdrawal request with double-entry reservation.
   */
  static async requestWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const input = requestWithdrawalSchema.parse(req.body);
      const idempotencyKey = (req.headers['idempotency-key'] as string) || input.idempotencyKey;

      const withdrawal = await WithdrawalService.requestWithdrawal({
        partnerProfileId: req.user.partnerProfile.id,
        withdrawalType: input.withdrawalType,
        amount: input.amount,
        currency: input.currency,
        destinationType: input.destinationType,
        bankAccountId: input.bankAccountId,
        moMoAccountId: input.moMoAccountId,
        idempotencyKey,
        userId: req.user.id,
        ipAddress: req.ip,
        userAgent: req.get('user-agent'),
      });

      sendSuccess(res, withdrawal, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/withdrawals/balance
   * Retrieves authoritative withdrawable balance.
   */
  static async getBalance(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const balance = await WithdrawalService.getAuthoritativeBalance(req.user.partnerProfile.id);
      sendSuccess(res, {
        availableReturnsEUR: balance.availableReturnsEUR.toFixed(2),
        unlockedCapitalEUR: balance.unlockedCapitalEUR.toFixed(2),
        totalWithdrawableEUR: balance.totalWithdrawableEUR.toFixed(2),
        reservedWithdrawalsEUR: balance.reservedWithdrawalsEUR.toFixed(2),
        preferredCurrency: req.user.partnerProfile.preferredCurrency,
      });
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/withdrawals
   * Lists all withdrawals for the authenticated user.
   */
  static async getMyWithdrawals(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const withdrawals = await WithdrawalService.getPartnerWithdrawals(req.user.partnerProfile.id);
      sendSuccess(res, { withdrawals });
    } catch (err) {
      next(err);
    }
  }

  /**
   * GET /api/v1/withdrawals/:id
   * Retrieves a specific withdrawal with ownership/IDOR check.
   */
  static async getWithdrawalById(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const withdrawalId = String(req.params.id || '');
      const isAdmin = req.user.role === UserRole.ADMIN || req.user.role === UserRole.SUPERADMIN;

      const withdrawal = await WithdrawalService.getWithdrawalById(
        withdrawalId,
        req.user.partnerProfile.id,
        isAdmin
      );

      sendSuccess(res, withdrawal);
    } catch (err) {
      next(err);
    }
  }

  /**
   * POST /api/v1/withdrawals/:id/cancel
   * Cancels a pending withdrawal and releases reservation.
   */
  static async cancelWithdrawal(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user?.partnerProfile?.id) {
        throw AppError.forbidden('User does not have an active partner profile');
      }

      const withdrawalId = String(req.params.id || '');
      const updated = await WithdrawalService.cancelWithdrawal(
        withdrawalId,
        req.user.partnerProfile.id,
        req.user.id
      );

      sendSuccess(res, updated);
    } catch (err) {
      next(err);
    }
  }
}
