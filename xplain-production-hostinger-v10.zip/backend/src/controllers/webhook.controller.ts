import type { Request, Response, NextFunction } from 'express';
import { StripeService } from '../services/stripe.service.js';
import { AppError } from '../utils/appError.js';

export class WebhookController {
  /**
   * POST /api/v1/webhooks/stripe
   * Processes verified incoming Stripe webhooks using raw body and Stripe-Signature header.
   */
  static async handleStripeWebhook(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const signature = req.headers['stripe-signature'] as string;

      if (!signature) {
        throw AppError.badRequest('Missing Stripe-Signature header');
      }

      let payload = req.body;
      if (!payload || (Buffer.isBuffer(payload) && payload.length === 0)) {
        throw AppError.badRequest('Missing request payload');
      }

      if (typeof payload === 'object' && !Buffer.isBuffer(payload)) {
        payload = Buffer.from(JSON.stringify(payload));
      }

      // Pass the raw body buffer/string to the Stripe verification service
      const result = await StripeService.handleWebhookEvent(payload, signature);

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
}
