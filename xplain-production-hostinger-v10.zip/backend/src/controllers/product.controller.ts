import type { Request, Response, NextFunction } from 'express';
import { ProductService } from '../services/product.service.js';
import { sendSuccess } from '../utils/apiResponse.js';
import { productQuerySchema, createProductSchema, updateProductSchema } from '../validators/product.validator.js';

export class ProductController {
  static async listProducts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = productQuerySchema.parse(req.query);
      const result = await ProductService.getProducts({
        categorySlug: query.category,
        search: query.search,
        page: query.page,
        limit: query.limit,
        sort: query.sort,
        includeInactive: query.includeInactive,
      });

      sendSuccess(res, result);
    } catch (err) {
      next(err);
    }
  }

  static async getProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const idOrRef = String(req.params.idOrRef);
      const product = await ProductService.getProductByIdOrRef(idOrRef);
      sendSuccess(res, product);
    } catch (err) {
      next(err);
    }
  }

  static async listCategories(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const categories = await ProductService.getCategories();
      sendSuccess(res, categories);
    } catch (err) {
      next(err);
    }
  }

  static async listShowcase(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const showcase = await ProductService.getShowcaseAppliances();
      sendSuccess(res, showcase);
    } catch (err) {
      next(err);
    }
  }

  static async adminCreateProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const input = createProductSchema.parse(req.body);
      const product = await ProductService.createProduct(input);
      sendSuccess(res, product, undefined, 201);
    } catch (err) {
      next(err);
    }
  }

  static async adminUpdateProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = String(req.params.id);
      const input = updateProductSchema.parse(req.body);
      const product = await ProductService.updateProduct(id, input);
      sendSuccess(res, product);
    } catch (err) {
      next(err);
    }
  }

  static async adminArchiveProduct(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = String(req.params.id);
      const product = await ProductService.archiveProduct(id);
      sendSuccess(res, product);
    } catch (err) {
      next(err);
    }
  }
}
