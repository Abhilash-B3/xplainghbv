import { Prisma, Currency } from '@prisma/client';
import { prisma } from '../config/database.js';

export const MINIMUM_INVESTMENT_EUR = new Prisma.Decimal('0.85');
export const MINIMUM_INVESTMENT_GHS = new Prisma.Decimal('14.00');
export const MINIMUM_INVESTMENT_GBP = new Prisma.Decimal('0.72');
export const OPTION_B_DISCOUNT_MULTIPLIER = new Prisma.Decimal('0.86'); // 14% discount
export const OPTION_B_MONTHLY_RETURN_RATE = new Prisma.Decimal('0.0700'); // 7% monthly return
export const OPTION_B_LOCK_DURATION_MONTHS = 12;

export const SEED_EXCHANGE_RATES: Record<string, Prisma.Decimal> = {
  'EUR_TO_GBP': new Prisma.Decimal('0.85000000'),
  'EUR_TO_GHS': new Prisma.Decimal('16.00000000'),
  'GBP_TO_EUR': new Prisma.Decimal('1.17647059'),
  'GBP_TO_GHS': new Prisma.Decimal('18.82352941'),
  'GHS_TO_EUR': new Prisma.Decimal('0.06250000'),
  'GHS_TO_GBP': new Prisma.Decimal('0.05312500'),
  'EUR_TO_EUR': new Prisma.Decimal('1.00000000'),
  'GBP_TO_GBP': new Prisma.Decimal('1.00000000'),
  'GHS_TO_GHS': new Prisma.Decimal('1.00000000'),
};

export interface ResolvedExchangeRate {
  baseCurrency: Currency;
  quoteCurrency: Currency;
  rate: Prisma.Decimal;
  snapshotId: string | null;
  source: 'LIVE_PROVIDER' | 'DATABASE_SNAPSHOT' | 'DEVELOPMENT_SEED';
  effectiveAt: Date;
}

/**
 * Resolves an exchange rate snapshot between base and quote currency.
 * Distinguishes LIVE_PROVIDER, DATABASE_SNAPSHOT, and DEVELOPMENT_SEED.
 */
export async function resolveExchangeRate(
  base: Currency,
  quote: Currency
): Promise<ResolvedExchangeRate> {
  if (base === quote) {
    return {
      baseCurrency: base,
      quoteCurrency: quote,
      rate: new Prisma.Decimal('1.00000000'),
      snapshotId: null,
      source: 'DATABASE_SNAPSHOT',
      effectiveAt: new Date(),
    };
  }

  // 1. Attempt to find the most recent database snapshot
  try {
    const snapshot = await prisma.exchangeRateSnapshot.findFirst({
      where: {
        baseCurrency: base,
        quoteCurrency: quote,
      },
      orderBy: { effectiveAt: 'desc' },
    });

    if (snapshot) {
      return {
        baseCurrency: base,
        quoteCurrency: quote,
        rate: new Prisma.Decimal(snapshot.rate.toString()),
        snapshotId: snapshot.id,
        source: snapshot.source.includes('LIVE') ? 'LIVE_PROVIDER' : 'DATABASE_SNAPSHOT',
        effectiveAt: snapshot.effectiveAt,
      };
    }
  } catch {
    // Database connection fallback in test / initial boot
  }

  // 2. Fallback to development seed rates
  const key = `${base}_TO_${quote}`;
  const seedRate = SEED_EXCHANGE_RATES[key] || new Prisma.Decimal('1.00000000');

  return {
    baseCurrency: base,
    quoteCurrency: quote,
    rate: seedRate,
    snapshotId: null,
    source: 'DEVELOPMENT_SEED',
    effectiveAt: new Date(),
  };
}

/**
 * Converts a Decimal amount from base currency to target currency using provided rate.
 */
export function convertCurrency(
  amount: Prisma.Decimal,
  rate: Prisma.Decimal
): Prisma.Decimal {
  return amount.mul(rate).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);
}

/**
 * Converts a Decimal amount to canonical EUR.
 */
export async function convertToEUR(
  amount: Prisma.Decimal,
  fromCurrency: Currency
): Promise<{ amountEUR: Prisma.Decimal; rate: Prisma.Decimal; snapshot: ResolvedExchangeRate }> {
  const snapshot = await resolveExchangeRate(fromCurrency, Currency.EUR);
  const amountEUR = convertCurrency(amount, snapshot.rate);
  return { amountEUR, rate: snapshot.rate, snapshot };
}

/**
 * Validates that an investment amount meets the minimum €1.00 equivalent threshold.
 */
export async function validateMinimumInvestment(
  amountInCurrency: Prisma.Decimal,
  currency: Currency
): Promise<{ meetsMinimum: boolean; minimumInCurrency: Prisma.Decimal; minEUR: Prisma.Decimal; minGHS: Prisma.Decimal }> {
  if (currency === Currency.EUR) {
    const meets = amountInCurrency.greaterThanOrEqualTo(MINIMUM_INVESTMENT_EUR);
    return {
      meetsMinimum: meets,
      minimumInCurrency: MINIMUM_INVESTMENT_EUR,
      minEUR: MINIMUM_INVESTMENT_EUR,
      minGHS: MINIMUM_INVESTMENT_GHS,
    };
  }

  // Convert EUR 1.00 to target currency
  const eurToTarget = await resolveExchangeRate(Currency.EUR, currency);
  const minInTarget = convertCurrency(MINIMUM_INVESTMENT_EUR, eurToTarget.rate);
  const meets = amountInCurrency.greaterThanOrEqualTo(minInTarget);

  return {
    meetsMinimum: meets,
    minimumInCurrency: minInTarget,
    minEUR: MINIMUM_INVESTMENT_EUR,
    minGHS: MINIMUM_INVESTMENT_GHS,
  };
}
