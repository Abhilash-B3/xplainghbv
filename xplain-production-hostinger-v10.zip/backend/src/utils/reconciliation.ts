import { Prisma, EntryType, AccountType } from '@prisma/client';
import { prisma } from '../config/database.js';
import { logger } from './logger.js';

export interface ReconciliationReport {
  isBalanced: boolean;
  totalTransactionsChecked: number;
  imbalancedTransactions: Array<{
    transactionId: string;
    referenceNumber: string;
    totalDebitsEUR: string;
    totalCreditsEUR: string;
    difference: string;
  }>;
  totalAccountsChecked: number;
  accountSummaries: Array<{
    accountId: string;
    accountType: AccountType;
    partnerProfileId: string | null;
    computedBalanceEUR: string;
  }>;
}

/**
 * Runs a complete audit and reconciliation of all ledger transactions and accounts in PostgreSQL.
 */
export async function runLedgerReconciliation(): Promise<ReconciliationReport> {
  logger.info('Starting financial ledger reconciliation audit...');

  // 1. Audit all transactions for debit === credit balance
  const transactions = await prisma.ledgerTransaction.findMany({
    include: {
      entries: true,
    },
  });

  const imbalancedTransactions: ReconciliationReport['imbalancedTransactions'] = [];

  for (const tx of transactions) {
    let debits = new Prisma.Decimal('0.0000');
    let credits = new Prisma.Decimal('0.0000');

    for (const entry of tx.entries) {
      if (entry.entryType === EntryType.DEBIT) {
        debits = debits.plus(entry.amountEUR);
      } else {
        credits = credits.plus(entry.amountEUR);
      }
    }

    const diff = debits.minus(credits).abs();
    if (diff.greaterThan(new Prisma.Decimal('0.0001'))) {
      imbalancedTransactions.push({
        transactionId: tx.id,
        referenceNumber: tx.referenceNumber,
        totalDebitsEUR: debits.toString(),
        totalCreditsEUR: credits.toString(),
        difference: diff.toString(),
      });
    }
  }

  // 2. Audit all financial accounts
  const accounts = await prisma.financialAccount.findMany({
    include: {
      ledgerEntries: true,
    },
  });

  const accountSummaries: ReconciliationReport['accountSummaries'] = [];

  for (const acc of accounts) {
    let debits = new Prisma.Decimal('0.0000');
    let credits = new Prisma.Decimal('0.0000');

    for (const entry of acc.ledgerEntries) {
      if (entry.entryType === EntryType.DEBIT) {
        debits = debits.plus(entry.amountEUR);
      } else {
        credits = credits.plus(entry.amountEUR);
      }
    }

    let balance: Prisma.Decimal;
    if (acc.accountType === AccountType.PLATFORM_ESCROW) {
      balance = debits.minus(credits);
    } else {
      balance = credits.minus(debits);
    }

    accountSummaries.push({
      accountId: acc.id,
      accountType: acc.accountType,
      partnerProfileId: acc.partnerProfileId,
      computedBalanceEUR: balance.toDecimalPlaces(4).toString(),
    });
  }

  const isBalanced = imbalancedTransactions.length === 0;

  logger.info('Financial ledger reconciliation audit finished', {
    isBalanced,
    totalTransactionsChecked: transactions.length,
    imbalancedCount: imbalancedTransactions.length,
    totalAccountsChecked: accounts.length,
  });

  return {
    isBalanced,
    totalTransactionsChecked: transactions.length,
    imbalancedTransactions,
    totalAccountsChecked: accounts.length,
    accountSummaries,
  };
}
