import { randomBytes, createHash } from 'crypto';

/**
 * Generates a cryptographically strong random hex token.
 * 32 bytes = 256 bits of entropy.
 */
export function generateSecureToken(bytes = 32): string {
  return randomBytes(bytes).toString('hex');
}

/**
 * Computes a deterministic SHA-256 hash of a raw token for safe database persistence.
 * Raw tokens are never stored plaintext in PostgreSQL.
 */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}
