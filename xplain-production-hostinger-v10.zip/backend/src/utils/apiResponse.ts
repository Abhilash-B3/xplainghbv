import type { Response } from 'express';
import type { ApiSuccessResponse, ApiErrorResponse, ErrorCode, RequestWithId } from '../types/index.js';

export function sendSuccess<T>(
  res: Response,
  data: T,
  meta?: Record<string, unknown>,
  statusCode = 200
): Response {
  const responseBody: ApiSuccessResponse<T> = {
    success: true,
    data,
    ...(meta ? { meta } : {}),
  };
  return res.status(statusCode).json(responseBody);
}

export function sendError(
  res: Response,
  code: ErrorCode | string,
  message: string,
  statusCode = 500,
  details?: unknown,
  req?: RequestWithId
): Response {
  const responseBody: ApiErrorResponse = {
    success: false,
    error: {
      code,
      message,
      ...(details !== undefined ? { details } : {}),
      ...(req?.id ? { requestId: req.id } : {}),
    },
  };
  return res.status(statusCode).json(responseBody);
}
