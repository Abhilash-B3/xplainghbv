import { Prisma, PrismaClient } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from './appError.js';

export type PrismaTransactionClient = Omit<
  PrismaClient,
  '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'
>;

export interface TransactionOptions {
  maxWait?: number; // default: 2000
  timeout?: number; // default: 5000
  isolationLevel?: Prisma.TransactionIsolationLevel;
}

/**
 * Executes a callback function inside a Prisma transaction boundary.
 * Financial mutations and critical multi-table updates must use this.
 */
export async function runInTransaction<T>(
  action: (tx: PrismaTransactionClient) => Promise<T>,
  options?: TransactionOptions
): Promise<T> {
  try {
    return await prisma.$transaction(
      async (tx) => {
        return await action(tx as unknown as PrismaTransactionClient);
      },
      {
        maxWait: options?.maxWait ?? 3000,
        timeout: options?.timeout ?? 8000,
        isolationLevel: options?.isolationLevel,
      }
    );
  } catch (error) {
    if (error instanceof AppError) {
      throw error;
    }
    // Prisma specific error rethrow
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      throw error;
    }
    throw AppError.database(
      'Transaction failed: ' + (error instanceof Error ? error.message : 'Unknown database error')
    );
  }
}
