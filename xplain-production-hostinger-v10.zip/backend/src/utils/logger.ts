import { env } from '../config/env.js';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const SENSITIVE_KEYS = new Set([
  'password',
  'token',
  'secret',
  'authorization',
  'cookie',
  'sessionsecret',
  'stripesecretkey',
  'apiKey',
  'apikey',
  'creditcard',
  'cvv',
  'cardnumber',
]);

function redactSensitiveData(obj: unknown, depth = 0): unknown {
  if (depth > 5 || obj === null || obj === undefined) return obj;

  if (typeof obj === 'string') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => redactSensitiveData(item, depth + 1));
  }

  if (typeof obj === 'object') {
    const sanitized: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      if (SENSITIVE_KEYS.has(key.toLowerCase())) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = redactSensitiveData(value, depth + 1);
      } else {
        sanitized[key] = value;
      }
    }
    return sanitized;
  }

  return obj;
}

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  requestId?: string;
  context?: Record<string, unknown>;
  error?: {
    name?: string;
    message?: string;
    stack?: string;
  };
}

class Logger {
  private formatLog(level: LogLevel, message: string, context?: Record<string, unknown>): string {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...(context ? { context: redactSensitiveData(context) as Record<string, unknown> } : {}),
    };

    if (env.NODE_ENV === 'development') {
      const color =
        level === 'error' ? '\x1b[31m' : level === 'warn' ? '\x1b[33m' : level === 'info' ? '\x1b[36m' : '\x1b[90m';
      const reset = '\x1b[0m';
      const ctxStr = context && Object.keys(context).length > 0 ? ` ${JSON.stringify(redactSensitiveData(context))}` : '';
      return `${color}[${entry.timestamp}] [${level.toUpperCase()}]${reset} ${message}${ctxStr}`;
    }

    return JSON.stringify(entry);
  }

  debug(message: string, context?: Record<string, unknown>): void {
    if (env.NODE_ENV === 'development' || env.NODE_ENV === 'test') {
      console.debug(this.formatLog('debug', message, context));
    }
  }

  info(message: string, context?: Record<string, unknown>): void {
    console.info(this.formatLog('info', message, context));
  }

  warn(message: string, context?: Record<string, unknown>): void {
    console.warn(this.formatLog('warn', message, context));
  }

  error(message: string, errorOrContext?: Error | Record<string, unknown>): void {
    let context: Record<string, unknown> = {};
    if (errorOrContext instanceof Error) {
      context = {
        error: {
          name: errorOrContext.name,
          message: errorOrContext.message,
          ...(env.NODE_ENV !== 'production' ? { stack: errorOrContext.stack } : {}),
        },
      };
    } else if (errorOrContext && typeof errorOrContext === 'object') {
      context = errorOrContext;
    }

    console.error(this.formatLog('error', message, context));
  }
}

export const logger = new Logger();
