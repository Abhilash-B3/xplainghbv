import { PrismaClient } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import pg from 'pg';
import { env } from './env.js';
import { logger } from '../utils/logger.js';

declare global {
  // eslint-disable-next-line no-var
  var __globalPrismaClient: PrismaClient | undefined;
  // eslint-disable-next-line no-var
  var __globalPgPool: pg.Pool | undefined;
}

function createPgPool(): pg.Pool {
  const p = new pg.Pool({
    connectionString: env.DATABASE_URL,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10000,
  });

  // Attach error listener to prevent unhandled node process termination on idle socket reset
  p.on('error', (err: Error) => {
    logger.error('Unexpected error on idle PostgreSQL client in pool', {
      error: err.message,
      name: err.name,
    });
  });

  return p;
}

const pool = global.__globalPgPool ?? createPgPool();

function createPrismaClient(): PrismaClient {
  const adapter = new PrismaPg(pool);
  return new PrismaClient({
    adapter,
    log: env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });
}

export const prisma = global.__globalPrismaClient ?? createPrismaClient();

if (env.NODE_ENV !== 'production') {
  global.__globalPrismaClient = prisma;
  global.__globalPgPool = pool;
}

export interface DatabaseHealthResult {
  status: 'healthy' | 'unhealthy';
  latencyMs?: number;
  error?: string;
}

export async function checkDatabaseHealth(): Promise<DatabaseHealthResult> {
  const start = performance.now();
  try {
    // Real raw query check against PostgreSQL
    await prisma.$queryRaw`SELECT 1 as alive`;
    const latencyMs = Math.round(performance.now() - start);
    return {
      status: 'healthy',
      latencyMs,
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Database ping failed';
    return {
      status: 'unhealthy',
      error: message,
    };
  }
}

export async function connectDatabase(maxRetries = 3, retryDelayMs = 1500): Promise<void> {
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      attempt++;
      await prisma.$connect();
      // Test active query execution
      await prisma.$queryRaw`SELECT 1 as connected`;
      logger.info('Connected successfully to PostgreSQL database via Prisma', {
        attempt,
      });
      return;
    } catch (error: any) {
      logger.error(`PostgreSQL connection attempt ${attempt}/${maxRetries} failed: ${error.message}`, {
        attempt,
        maxRetries,
      });
      if (attempt >= maxRetries) {
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, retryDelayMs * attempt));
    }
  }
}

export async function disconnectDatabase(): Promise<void> {
  try {
    await prisma.$disconnect();
    await pool.end();
  } catch (error) {
    logger.error('Error disconnecting from PostgreSQL database', error as Error);
  }
}

