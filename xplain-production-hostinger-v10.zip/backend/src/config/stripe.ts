import Stripe from 'stripe';
import { Currency } from '@prisma/client';
import { env } from './env.js';
import { logger } from '../utils/logger.js';
import { AppError } from '../utils/appError.js';

/**
 * Supported charge currencies for Xplain GH BV on Stripe.
 * Each currency maps to its zero-decimal vs two-decimal unit multiplier.
 */
export const STRIPE_SUPPORTED_CURRENCIES: Record<Currency, { multiplier: number; minCharge: number }> = {
  [Currency.EUR]: { multiplier: 100, minCharge: 50 }, // 0.50 EUR min
  [Currency.GBP]: { multiplier: 100, minCharge: 30 }, // 0.30 GBP min
  [Currency.GHS]: { multiplier: 100, minCharge: 500 }, // 5.00 GHS min
};

let cachedClient: Stripe | null = null;
let lastKey = '';

/**
 * Returns a Stripe SDK client instance configured with current secret key.
 */
export function getStripeClient(): Stripe {
  const currentKey = process.env.STRIPE_SECRET_KEY || env.STRIPE_SECRET_KEY;
  if (!cachedClient || lastKey !== currentKey) {
    cachedClient = new Stripe(currentKey, {
      apiVersion: (env.STRIPE_API_VERSION as any) || '2025-02-24.acacia',
      typescript: true,
      appInfo: {
        name: 'Xplain GH BV Investment Platform',
        version: '1.0.0',
        url: 'https://xplainghbv.com',
      },
    });
    lastKey = currentKey;
  }
  return cachedClient;
}

/**
 * Dynamic Stripe client proxy that always delegates to current active client.
 */
export const stripeClient = new Proxy({} as Stripe, {
  get(_target, prop) {
    const client = getStripeClient();
    const value = (client as any)[prop];
    if (typeof value === 'function') {
      return value.bind(client);
    }
    return value;
  },
});

/**
 * Validates whether the given platform currency is supported by the configured Stripe environment.
 * Throws an explicit AppError if unsupported. Never silently converts or falls back.
 */
export function validateStripeCurrency(currency: Currency): { multiplier: number; minCharge: number } {
  const capability = STRIPE_SUPPORTED_CURRENCIES[currency];
  if (!capability) {
    logger.error('Attempted payment with unsupported Stripe charge currency', { currency });
    throw AppError.badRequest(
      `Currency '${currency}' is not supported by the platform Stripe payment configuration. Contact support.`
    );
  }
  return capability;
}

/**
 * Converts a decimal monetary amount to the Stripe integer representation in smallest currency unit.
 * Example: 1050.50 EUR -> 105050 cents.
 */
export function toStripeAmount(amount: number | string | { toString(): string }, currency: Currency): number {
  const { multiplier } = validateStripeCurrency(currency);
  const numericAmount = typeof amount === 'number' ? amount : parseFloat(amount.toString());
  
  if (isNaN(numericAmount) || numericAmount <= 0) {
    throw AppError.badRequest(`Invalid payment amount: ${amount}`);
  }

  return Math.round(numericAmount * multiplier);
}

/**
 * Redacts sensitive credentials or tokens for safe logging.
 */
export function redactSecret(secret?: string | null): string {
  if (!secret) return '[NONE]';
  if (secret.length <= 8) return '***';
  return `${secret.slice(0, 4)}...${secret.slice(-4)}`;
}
