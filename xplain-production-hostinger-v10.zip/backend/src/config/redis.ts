import { Redis } from 'ioredis';
import { env } from './env.js';

let redisClient: Redis | null = null;

if (env.REDIS_URL) {
  redisClient = new Redis(env.REDIS_URL, {
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
    lazyConnect: true,
    retryStrategy(times) {
      const delay = Math.min(times * 200, 2000);
      return delay;
    },
  });

  redisClient.on('error', (err) => {
    console.error('Redis connection error:', err);
  });
}

export function getRedisClient(): Redis | null {
  return redisClient;
}

export interface RedisHealthResult {
  status: 'healthy' | 'unhealthy' | 'disabled';
  latencyMs?: number;
  error?: string;
}

export async function checkRedisHealth(): Promise<RedisHealthResult> {
  if (!redisClient) {
    return {
      status: 'disabled',
    };
  }

  const start = performance.now();
  try {
    const pong = await redisClient.ping();
    const latencyMs = Math.round(performance.now() - start);
    if (pong === 'PONG') {
      return {
        status: 'healthy',
        latencyMs,
      };
    }
    return {
      status: 'unhealthy',
      error: 'Unexpected response from Redis ping',
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Redis ping failed';
    return {
      status: 'unhealthy',
      error: message,
    };
  }
}

export async function disconnectRedis(): Promise<void> {
  if (redisClient) {
    try {
      await redisClient.quit();
    } catch {
      redisClient.disconnect();
    }
  }
}
