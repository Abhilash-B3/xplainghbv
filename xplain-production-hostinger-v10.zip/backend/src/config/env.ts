import { z } from 'zod';
import dotenv from 'dotenv';
import path from 'path';

// Load .env file from root with override enabled
dotenv.config({ path: path.resolve(process.cwd(), '.env'), override: true });

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(5000),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  DIRECT_DATABASE_URL: z.string().optional(),
  REDIS_URL: z.string().optional(),
  FRONTEND_URL: z.string().default('http://localhost:3000'),
  SESSION_SECRET: z.string().min(16, 'SESSION_SECRET must be at least 16 characters').default('development_secret_session_key_32bytes_long'),
  COOKIE_DOMAIN: z.string().optional(),

  // Stripe Payment Gateway Configuration (Phase 6)
  STRIPE_SECRET_KEY: z.string().default('sk_test_placeholder_dev_mode'),
  STRIPE_WEBHOOK_SECRET: z.string().default('whsec_placeholder_dev_mode'),
  STRIPE_PUBLISHABLE_KEY: z.string().default('pk_test_placeholder_dev_mode'),
  STRIPE_API_VERSION: z.string().default('2025-02-24.acacia'),

  // Production email via Hostinger SMTP
  EMAIL_PROVIDER: z.string().optional(),
  EMAIL_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().optional(),
  EMAIL_SMTP_HOST: z.string().default('smtp.hostinger.com'),
  EMAIL_SMTP_PORT: z.coerce.number().int().positive().default(465),
  EMAIL_SMTP_USER: z.string().email().optional(),
  EMAIL_SMTP_PASSWORD: z.string().optional(),
});

export type Env = z.infer<typeof envSchema>;

function validateEnv(): Env {
  // If test environment and DATABASE_URL is not set, provide a test fallback if needed
  if (process.env.NODE_ENV === 'test' && !process.env.DATABASE_URL) {
    process.env.DATABASE_URL = 'postgresql://postgres:postgres@localhost:5432/xplain_test?schema=public';
  }

  const result = envSchema.safeParse(process.env);

  if (!result.success) {
    console.error('❌ Environment Variable Validation Error:');
    const formatted = result.error.format();
    console.error(JSON.stringify(formatted, null, 2));
    throw new Error('Invalid environment configuration. Check logs above.');
  }

  return result.data;
}

export const env = validateEnv();
