import express, { type Express } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';

import { env } from './config/env.js';
import { requestIdMiddleware } from './middleware/requestId.js';
import { requestLoggingMiddleware } from './middleware/logging.js';
import { globalRateLimiter } from './middleware/rateLimiter.js';
import { notFoundHandler } from './middleware/notFound.js';
import { errorHandler } from './middleware/errorHandler.js';
import apiV1Router from './routes/index.js';

export function createApp(): Express {
  const app = express();

  // Hostinger runs the application behind a reverse proxy.
  // Trust the first proxy so Express/rate-limit can correctly
  // process X-Forwarded-For and identify client IPs.
  app.set('trust proxy', 1);

  // Resolve the React production build directory.
  // backend/dist/app.js -> project/dist
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);
  const frontendDist = path.resolve(__dirname, '../../dist');

  // 1. Security Headers with Stripe Elements CSP compatibility
  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      contentSecurityPolicy:
        env.NODE_ENV === 'production'
          ? {
            directives: {
              defaultSrc: ["'self'"],
              scriptSrc: ["'self'", 'https://js.stripe.com'],
              frameSrc: [
                "'self'",
                'https://js.stripe.com',
                'https://hooks.stripe.com',
              ],
              connectSrc: [
                "'self'",
                'https://api.stripe.com',
                env.FRONTEND_URL,
              ],
              imgSrc: ["'self'", 'data:', 'https:'],
              styleSrc: [
                "'self'",
                "'unsafe-inline'",
                'https://fonts.googleapis.com',
              ],
              fontSrc: ["'self'", 'https://fonts.gstatic.com'],
            },
          }
          : false,
    })
  );

  // 2. Strict CORS Configuration
  // Production must support both the canonical root domain and www.
  // Derive the www/non-www counterpart from FRONTEND_URL so we do not
  // hard-code a second production origin into environment configuration.
  const configuredFrontendUrl = env.FRONTEND_URL.replace(/\/$/, '');
  const allowedOrigins = new Set<string>([configuredFrontendUrl]);

  try {
    const frontendUrl = new URL(configuredFrontendUrl);

    if (frontendUrl.hostname.startsWith('www.')) {
      frontendUrl.hostname = frontendUrl.hostname.slice(4);
      allowedOrigins.add(frontendUrl.origin);
    } else {
      frontendUrl.hostname = `www.${frontendUrl.hostname}`;
      allowedOrigins.add(frontendUrl.origin);
    }
  } catch {
    // FRONTEND_URL is already validated as a string; if it is malformed,
    // keep the configured origin and let the environment validation/deployment
    // surface the configuration problem.
  }

  if (env.NODE_ENV === 'development') {
    allowedOrigins.add('http://localhost:3000');
    allowedOrigins.add('http://127.0.0.1:3000');
    allowedOrigins.add('http://localhost:5173');
  }

  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow requests with no origin (curl, mobile apps,
        // server-to-server requests, etc.)
        if (!origin) {
          return callback(null, true);
        }

        if (allowedOrigins.has(origin)) {
          return callback(null, true);
        }

        return callback(
          new Error(`Origin ${origin} is not allowed by CORS policy`)
        );
      },
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Content-Type',
        'Authorization',
        'X-Request-Id',
        'Idempotency-Key',
        'Stripe-Signature',
      ],
      exposedHeaders: ['X-Request-Id'],
      maxAge: 86400,
    })
  );

  // 3. Raw Body Parser for Stripe Webhook
  // MUST be registered before express.json()
  app.use(
    '/api/v1/webhooks/stripe',
    express.raw({ type: 'application/json' })
  );

  // 4. Request Parsers & Cookie Parser
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  app.use(cookieParser());

  // 5. Request ID & Logging
  app.use(requestIdMiddleware);
  app.use(requestLoggingMiddleware);

  // 6. Rate Limiting
  app.use('/api/', globalRateLimiter);

  // 7. Application API Routes
  app.use('/api/v1', apiV1Router);

  // 8. Serve React Production Build
  app.use(express.static(frontendDist));

  // 9. React SPA Fallback
  //
  // React Router handles client-side routes such as:
  // /login
  // /register
  // /dashboard
  // /invest
  //
  // API requests are excluded so they can reach the 404/API handlers.
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api/')) {
      return res.sendFile(path.join(frontendDist, 'index.html'));
    }

    next();
  });

  // 10. 404 Handler
  app.use(notFoundHandler);

  // 11. Centralized Error Handler
  app.use(errorHandler);

  return app;
}

export const app = createApp();