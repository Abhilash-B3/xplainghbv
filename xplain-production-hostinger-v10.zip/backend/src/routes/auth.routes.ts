import { Router } from 'express';
import {
  register,
  login,
  logout,
  me,
  changePassword,
  forgotPassword,
  resetPassword,
  verifyEmail,
} from '../controllers/auth.controller.js';
import { validate } from '../middleware/validate.js';
import { requireAuth } from '../middleware/auth.js';
import { strictAuthRateLimiter } from '../middleware/rateLimiter.js';
import {
  registerSchema,
  loginSchema,
  changePasswordSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
  verifyEmailSchema,
} from '../validators/auth.validator.js';

const router = Router();

router.post('/register', validate({ body: registerSchema }), register);
router.post('/login', strictAuthRateLimiter, validate({ body: loginSchema }), login);
router.post('/logout', requireAuth, logout);
router.get('/me', requireAuth, me);
router.post('/change-password', requireAuth, validate({ body: changePasswordSchema }), changePassword);
router.post('/forgot-password', strictAuthRateLimiter, validate({ body: forgotPasswordSchema }), forgotPassword);
router.post('/reset-password', strictAuthRateLimiter, validate({ body: resetPasswordSchema }), resetPassword);
router.post('/verify-email', validate({ body: verifyEmailSchema }), verifyEmail);

export default router;
