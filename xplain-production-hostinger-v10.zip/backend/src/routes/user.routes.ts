import { Router } from 'express';
import { getMe, updateMe } from '../controllers/user.controller.js';
import { FinancialController } from '../controllers/financial.controller.js';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { updateProfileSchema } from '../validators/user.validator.js';

const router = Router();

router.get('/me', requireAuth, getMe);
router.patch('/me', requireAuth, validate({ body: updateProfileSchema }), updateMe);
router.get('/me/financial-summary', requireAuth, FinancialController.getMyFinancialSummary);

export default router;

