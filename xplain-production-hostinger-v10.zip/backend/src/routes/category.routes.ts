import { Router } from 'express';
import { ProductController } from '../controllers/product.controller.js';

const router = Router();

// Public categories route
router.get('/', ProductController.listCategories);

export default router;
