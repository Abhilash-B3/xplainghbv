import { Router } from 'express';
import { InvestmentController } from '../controllers/investment.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// Public / Authenticated quote calculation
router.post('/quote', InvestmentController.requestQuote);

// Authenticated investment operations
router.post('/', requireAuth, InvestmentController.createInvestment);
router.get('/', requireAuth, InvestmentController.listInvestments);
router.get('/:id', requireAuth, InvestmentController.getInvestment);

export default router;
