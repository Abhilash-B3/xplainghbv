import { Router } from 'express';
import healthRoutes from './health.routes.js';
import authRoutes from './auth.routes.js';
import userRoutes from './user.routes.js';
import productRoutes from './product.routes.js';
import categoryRoutes from './category.routes.js';
import showcaseRoutes from './showcase.routes.js';
import investmentRoutes from './investment.routes.js';
import financialRoutes from './financial.routes.js';
import paymentRoutes from './payment.routes.js';
import webhookRoutes from './webhook.routes.js';
import withdrawalRoutes from './withdrawal.routes.js';
import { bankRouter, momoRouter } from './destination.routes.js';
import referralRoutes from './referral.routes.js';
import notificationRoutes from './notification.routes.js';
import adminRoutes from './admin.routes.js';

const apiV1Router = Router();

// Phase 3: Real health check
apiV1Router.use('/health', healthRoutes);

// Phase 4: Authentication & User Identity Engine
apiV1Router.use('/auth', authRoutes);
apiV1Router.use('/users', userRoutes);

// Phase 5: Real Products, Investments, Financial Ledger & Payouts
apiV1Router.use('/products', productRoutes);
apiV1Router.use('/categories', categoryRoutes);
apiV1Router.use('/showcase', showcaseRoutes);
apiV1Router.use('/investments', investmentRoutes);
apiV1Router.use('/financial', financialRoutes);

// Phase 6: Stripe-Only Real Card Payment Integration
apiV1Router.use('/payments', paymentRoutes);
apiV1Router.use('/webhooks', webhookRoutes);

// Phase 7: Real Withdrawals, Referrals, Notifications & Admin
apiV1Router.use('/withdrawals', withdrawalRoutes);
apiV1Router.use('/bank-accounts', bankRouter);
apiV1Router.use('/momo-accounts', momoRouter);
apiV1Router.use('/referrals', referralRoutes);
apiV1Router.use('/notifications', notificationRoutes);
apiV1Router.use('/admin', adminRoutes);

export default apiV1Router;

