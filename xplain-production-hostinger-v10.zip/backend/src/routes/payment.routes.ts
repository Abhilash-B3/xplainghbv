import { Router } from 'express';
import { PaymentController } from '../controllers/payment.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// All payment routes require authenticated user session
router.post('/create-intent', requireAuth, PaymentController.createIntent);
router.get('/:paymentTransactionId', requireAuth, PaymentController.getStatus);

export default router;
