import { Router } from 'express';
import { ProductController } from '../controllers/product.controller.js';

const router = Router();

// Public showcase route
router.get('/', ProductController.listShowcase);

export default router;
