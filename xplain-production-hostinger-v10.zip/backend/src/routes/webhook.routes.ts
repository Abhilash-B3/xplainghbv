import { Router } from 'express';
import { WebhookController } from '../controllers/webhook.controller.js';

const router = Router();

// Public webhook endpoint - authenticity is guaranteed via cryptographic Stripe-Signature header
router.post('/stripe', WebhookController.handleStripeWebhook);

export default router;
