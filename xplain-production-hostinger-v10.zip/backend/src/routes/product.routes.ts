import { Router } from 'express';
import { ProductController } from '../controllers/product.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { UserRole } from '@prisma/client';

const router = Router();

// Public catalogue routes
router.get('/', ProductController.listProducts);
router.get('/:idOrRef', ProductController.getProduct);

// Admin CMS product management
router.post('/', requireAuth, requireRole(UserRole.ADMIN, UserRole.SUPERADMIN), ProductController.adminCreateProduct);
router.patch('/:id', requireAuth, requireRole(UserRole.ADMIN, UserRole.SUPERADMIN), ProductController.adminUpdateProduct);
router.delete('/:id', requireAuth, requireRole(UserRole.ADMIN, UserRole.SUPERADMIN), ProductController.adminArchiveProduct);

export default router;
