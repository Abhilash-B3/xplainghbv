import { Router } from 'express';
import { FinancialController } from '../controllers/financial.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

// Authenticated user financial summary
router.get('/summary', requireAuth, FinancialController.getMyFinancialSummary);

export default router;
