import { Router } from 'express';
import { AdminController } from '../controllers/admin.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { UserRole } from '@prisma/client';

const router = Router();

router.use(requireAuth);

// Read-only operational inspection (Accessible to SUPPORT, ADMIN, SUPERADMIN)
router.get(
  '/users',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getUsers
);
router.get(
  '/users/:id',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getUserDetails
);
router.get(
  '/investments',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getInvestments
);
router.get(
  '/withdrawals',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getWithdrawals
);
router.get(
  '/referrals',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getReferrals
);
router.get(
  '/ledger/transactions',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getLedgerTransactions
);
router.get(
  '/audit-logs',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getAuditLogs
);
router.get(
  '/reconciliation/report',
  requireRole(UserRole.SUPPORT, UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.getReconciliation
);

// Operational Mutations (ADMIN, SUPERADMIN)
router.patch(
  '/users/:id/status',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.updateUserStatus
);
router.post(
  '/withdrawals/:id/approve',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.approveWithdrawal
);
router.post(
  '/withdrawals/:id/process',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.processWithdrawal
);
router.post(
  '/withdrawals/:id/complete',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.completeWithdrawal
);
router.post(
  '/withdrawals/:id/reject',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  AdminController.rejectWithdrawal
);

// Elevated System Configuration (SUPERADMIN only)
router.patch(
  '/users/:id/role',
  requireRole(UserRole.SUPERADMIN),
  AdminController.updateUserRole
);

export default router;
