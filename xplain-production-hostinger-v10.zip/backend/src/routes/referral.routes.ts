import { Router } from 'express';
import { ReferralController } from '../controllers/referral.controller.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { UserRole } from '@prisma/client';

const router = Router();

router.use(requireAuth);

router.post('/attribute', ReferralController.attribute);
router.get('/summary', ReferralController.getSummary);
router.get('/code', ReferralController.getCode);

// Admin-triggered or worker-triggered monthly commission calculation
router.post(
  '/commissions/trigger-monthly',
  requireRole(UserRole.ADMIN, UserRole.SUPERADMIN),
  ReferralController.triggerMonthlyCommissions
);

export default router;
