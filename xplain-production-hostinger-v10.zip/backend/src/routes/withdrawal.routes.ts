import { Router } from 'express';
import { WithdrawalController } from '../controllers/withdrawal.controller.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

router.use(requireAuth);

router.post('/', WithdrawalController.requestWithdrawal);
router.get('/balance', WithdrawalController.getBalance);
router.get('/', WithdrawalController.getMyWithdrawals);
router.get('/:id', WithdrawalController.getWithdrawalById);
router.post('/:id/cancel', WithdrawalController.cancelWithdrawal);

export default router;
