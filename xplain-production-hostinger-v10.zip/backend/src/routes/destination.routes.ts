import { Router } from 'express';
import { DestinationController } from '../controllers/destination.controller.js';
import { requireAuth } from '../middleware/auth.js';

export const bankRouter = Router();
bankRouter.use(requireAuth);
bankRouter.post('/', DestinationController.addBankAccount);
bankRouter.get('/', DestinationController.listBankAccounts);
bankRouter.delete('/:id', DestinationController.deleteBankAccount);

export const momoRouter = Router();
momoRouter.use(requireAuth);
momoRouter.post('/', DestinationController.addMoMoAccount);
momoRouter.get('/', DestinationController.listMoMoAccounts);
momoRouter.delete('/:id', DestinationController.deleteMoMoAccount);
