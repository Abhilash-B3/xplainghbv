import { z } from 'zod';
import { Currency, DestinationType, WithdrawalType } from '@prisma/client';

export const requestWithdrawalSchema = z.object({
  withdrawalType: z.nativeEnum(WithdrawalType).default(WithdrawalType.RETURNS),
  amount: z.coerce.number().positive('Withdrawal amount must be greater than 0'),
  currency: z.nativeEnum(Currency),
  destinationType: z.nativeEnum(DestinationType),
  bankAccountId: z.string().uuid('Invalid bank account ID').optional(),
  moMoAccountId: z.string().uuid('Invalid MoMo account ID').optional(),
  idempotencyKey: z.string().max(64).optional(),
});

export const completeWithdrawalSchema = z.object({
  settlementReference: z.string().min(4, 'Settlement reference must be at least 4 characters').max(128),
  settlementProof: z.record(z.string(), z.any()).optional(),
});

export const rejectWithdrawalSchema = z.object({
  reason: z.string().min(3, 'Rejection reason must be at least 3 characters').max(500),
});
