import { z } from 'zod';

export const addressSchema = z.object({
  fullName: z.string().trim().min(2, 'Full name must be at least 2 characters').max(128),
  line1: z.string().trim().min(3, 'Address line 1 is required').max(255),
  line2: z.string().trim().max(255).optional(),
  city: z.string().trim().min(2, 'City is required').max(128),
  postcode: z.string().trim().min(2, 'Postcode is required').max(32),
  country: z.string().trim().min(2, 'Country is required').max(128),
  phone: z.string().trim().max(32).optional(),
  isDefault: z.boolean().optional(),
});

export const updateProfileSchema = z
  .object({
    fullName: z.string().trim().min(2, 'Full name must be at least 2 characters').max(128).optional(),
    preferredCurrency: z.enum(['EUR', 'GBP', 'GHS']).optional(),
    defaultPaymentMethod: z.enum(['MOMO', 'VISA']).optional(),
    resalePlan: z.enum(['DIRECT', 'SELLFOR']).optional(),
    address: addressSchema.optional(),
  })
  .strict(); // Rejects any extra unrecognized fields like role, balance, status, etc.
