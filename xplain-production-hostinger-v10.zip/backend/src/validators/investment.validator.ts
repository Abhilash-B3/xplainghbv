import { z } from 'zod';
import { ResalePlan, Currency } from '@prisma/client';

export const quoteItemSchema = z.object({
  productId: z.string().uuid({ message: 'Invalid productId UUID' }),
  quantity: z.number().int().positive({ message: 'Quantity must be a positive integer' }),
});

export const quoteRequestSchema = z.object({
  resalePlan: z.nativeEnum(ResalePlan, { message: 'Invalid resalePlan: must be DIRECT or SELLFOR' }),
  currency: z.nativeEnum(Currency, { message: 'Invalid currency: must be EUR, GBP, or GHS' }),
  items: z.array(quoteItemSchema).min(1, { message: 'At least one product item is required' }),
});

export const createInvestmentSchema = z.object({
  resalePlan: z.nativeEnum(ResalePlan, { message: 'Invalid resalePlan: must be DIRECT or SELLFOR' }),
  currency: z.nativeEnum(Currency, { message: 'Invalid currency: must be EUR, GBP, or GHS' }),
  items: z.array(quoteItemSchema).min(1, { message: 'At least one product item is required' }),
  deliveryAddressId: z.string().uuid({ message: 'Invalid deliveryAddressId UUID' }).optional(),
});
