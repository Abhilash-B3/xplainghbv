import { z } from 'zod';

export const productQuerySchema = z.object({
  category: z.string().optional(),
  search: z.string().optional(),
  page: z.coerce.number().int().positive().optional().default(1),
  limit: z.coerce.number().int().positive().max(100).optional().default(50),
  sort: z.enum(['price_asc', 'price_desc', 'name_asc', 'newest']).optional(),
  includeInactive: z.coerce.boolean().optional().default(false),
});

export const createProductSchema = z.object({
  categoryId: z.string().uuid({ message: 'Invalid categoryId UUID' }),
  ref: z.string().min(2).max(32),
  name: z.string().min(2).max(255),
  description: z.string().optional(),
  priceEUR: z.coerce.number().positive({ message: 'priceEUR must be positive' }),
  imageUrl: z.string().url({ message: 'Invalid imageUrl' }),
  stockQuantity: z.coerce.number().int().nonnegative().optional().default(100),
});

export const updateProductSchema = z.object({
  categoryId: z.string().uuid().optional(),
  name: z.string().min(2).max(255).optional(),
  description: z.string().optional(),
  priceEUR: z.coerce.number().positive().optional(),
  imageUrl: z.string().url().optional(),
  stockQuantity: z.coerce.number().int().nonnegative().optional(),
  isActive: z.boolean().optional(),
});
