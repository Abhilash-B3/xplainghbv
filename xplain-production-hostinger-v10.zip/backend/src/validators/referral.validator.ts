import { z } from 'zod';

export const attributeReferralSchema = z.object({
  referralCode: z.string().min(3, 'Referral code must be at least 3 characters').max(16),
});

export const triggerMonthlyCommissionSchema = z.object({
  periodMonth: z.string().regex(/^\d{4}-(?:0[1-9]|1[0-2])$/, 'periodMonth must be in YYYY-MM format'),
});
