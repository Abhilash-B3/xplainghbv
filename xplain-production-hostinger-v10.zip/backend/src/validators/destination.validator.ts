import { z } from 'zod';
import { Currency, PaymentProvider } from '@prisma/client';

export const createBankAccountSchema = z.object({
  bankName: z.string().min(2, 'Bank name is required').max(128),
  accountNumber: z.string().min(4, 'Account number must be at least 4 digits').max(64),
  sortCodeOrSwift: z.string().min(3, 'Sort code or SWIFT is required').max(32),
  accountHolderName: z.string().min(2, 'Account holder name is required').max(128),
  currency: z.nativeEnum(Currency).default(Currency.EUR),
  country: z.string().min(2).max(64).default('GH'),
});

export const createMoMoAccountSchema = z.object({
  provider: z.nativeEnum(PaymentProvider).refine(
    (p) => p === PaymentProvider.MTN_MOMO || p === PaymentProvider.VODAFONE_CASH || p === PaymentProvider.AIRTELTIGO_MONEY,
    { message: 'Invalid mobile money network provider' }
  ),
  phoneNumber: z.string().min(9, 'Valid phone number required').max(32),
  accountHolderName: z.string().min(2, 'Account holder name is required').max(128),
  country: z.string().default('GH'),
});
