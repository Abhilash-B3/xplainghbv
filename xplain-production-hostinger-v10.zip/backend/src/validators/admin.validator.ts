import { z } from 'zod';
import { UserRole, AccountStatus, InvestmentStatus, WithdrawalStatus } from '@prisma/client';

export const updateUserStatusSchema = z.object({
  status: z.nativeEnum(AccountStatus),
});

export const updateUserRoleSchema = z.object({
  role: z.nativeEnum(UserRole),
});

export const adminUserListQuerySchema = z.object({
  search: z.string().optional(),
  role: z.nativeEnum(UserRole).optional(),
  status: z.nativeEnum(AccountStatus).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});

export const adminInvestmentListQuerySchema = z.object({
  status: z.nativeEnum(InvestmentStatus).optional(),
  search: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});

export const adminWithdrawalListQuerySchema = z.object({
  status: z.nativeEnum(WithdrawalStatus).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).default(0),
});
