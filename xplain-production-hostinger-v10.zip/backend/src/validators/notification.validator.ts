import { z } from 'zod';

export const updateNotificationPreferencesSchema = z.object({
  emailInvestments: z.boolean().optional(),
  emailPayouts: z.boolean().optional(),
  emailWithdrawals: z.boolean().optional(),
  emailReferrals: z.boolean().optional(),
  emailMarketing: z.boolean().optional(),
});
