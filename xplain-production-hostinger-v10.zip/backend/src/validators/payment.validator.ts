import { z } from 'zod';

export const createPaymentIntentSchema = z.object({
  investmentId: z.string().uuid('Invalid investment ID format'),
  idempotencyKey: z.string().max(64, 'Idempotency key must be at most 64 characters').optional(),
});

export type CreatePaymentIntentInput = z.infer<typeof createPaymentIntentSchema>;
