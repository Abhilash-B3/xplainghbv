import crypto from 'crypto';
import {
  Prisma,
  InvestmentStatus,
  ResalePlan,
  Currency,
  PaymentProvider,
  TransactionType,
  TransactionStatus,
  BatchStatus,
  PayoutStatus,
  AccountType,
  EntryType,
} from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { PricingService, QuoteItemInput } from './pricing.service.js';
import { LedgerService } from './ledger.service.js';
import { AuditService } from './audit.service.js';

export interface CreateInvestmentInput {
  partnerProfileId: string;
  resalePlan: ResalePlan;
  currency: Currency;
  items: QuoteItemInput[];
  deliveryAddressId?: string;
  idempotencyKey?: string;
  ipAddress?: string;
  userAgent?: string;
  userId?: string;
}

export interface InvestmentFilterOptions {
  partnerProfileId?: string;
  status?: InvestmentStatus;
  page?: number;
  limit?: number;
}

export class InvestmentService {
  /**
   * Creates a new Investment intent with real PostgreSQL records and pending payment.
   * Atomic and idempotent.
   */
  static async createInvestment(input: CreateInvestmentInput) {
    const {
      partnerProfileId,
      resalePlan,
      currency,
      items,
      deliveryAddressId,
      idempotencyKey,
      ipAddress,
      userAgent,
      userId,
    } = input;

    // 1. Idempotency Check
    if (idempotencyKey) {
      const existing = await prisma.investment.findFirst({
        where: {
          partnerProfileId,
          idempotencyKey,
        },
        include: {
          items: true,
          paymentTransactions: true,
        },
      });

      if (existing) {
        logger.warn('Duplicate investment request detected (idempotent)', {
          idempotencyKey,
          investmentId: existing.id,
        });
        return existing;
      }
    }

    // 2. Validate Option A delivery address if provided
    if (deliveryAddressId) {
      const address = await prisma.address.findFirst({
        where: { id: deliveryAddressId, partnerProfileId },
      });

      if (!address) {
        throw AppError.badRequest('Delivery address not found or does not belong to this partner profile');
      }
    }

    // 3. Compute authoritative quote from server
    const quote = await PricingService.calculateQuote({
      items,
      resalePlan,
      currency,
    });

    // 4. Atomic Transaction: reserve stock, create investment, create items, create pending payment
    const result = await prisma.$transaction(async (tx) => {
      // 4a. Verify and decrement stock atomically with row locks
      for (const item of quote.items) {
        const product = await tx.product.findUnique({
          where: { id: item.productId },
        });

        if (!product || !product.isActive || product.stockQuantity < item.quantity) {
          throw AppError.conflict(
            `Insufficient stock for product ${item.productName}. Requested: ${item.quantity}, Available: ${product?.stockQuantity ?? 0}`
          );
        }

        await tx.product.update({
          where: { id: item.productId },
          data: {
            stockQuantity: { decrement: item.quantity },
          },
        });
      }

      // 4b. Create Investment
      const investment = await tx.investment.create({
        data: {
          partnerProfileId,
          resalePlan,
          status: InvestmentStatus.PAYMENT_PENDING,
          currency,
          subtotalInCurrency: quote.subtotalInCurrency,
          discountAmountInCurrency: quote.discountAmountInCurrency,
          totalAmountInCurrency: quote.totalAmountInCurrency,
          totalAmountEUR: quote.totalAmountEUR,
          exchangeRateToEUR: quote.exchangeRateToEUR,
          deliveryAddressId: resalePlan === ResalePlan.DIRECT ? deliveryAddressId : null,
          idempotencyKey: idempotencyKey || null,
        },
      });

      // 4c. Create InvestmentItems with frozen historical terms
      await tx.investmentItem.createMany({
        data: quote.items.map((item) => ({
          investmentId: investment.id,
          productId: item.productId,
          productRef: item.productRef,
          productName: item.productName,
          unitPriceEUR: item.unitPriceEUR,
          discountMultiplier: item.discountMultiplier,
          quantity: item.quantity,
          lineTotalEUR: item.lineTotalEUR,
        })),
      });

      // 4d. Create pending PaymentTransaction record
      const refNumber = `TX-INV-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      const paymentTx = await tx.paymentTransaction.create({
        data: {
          referenceNumber: refNumber,
          investmentId: investment.id,
          partnerProfileId,
          provider: PaymentProvider.MANUAL_BANK, // Default until provider is selected in Phase 6
          type: TransactionType.DEPOSIT,
          amount: quote.totalAmountInCurrency,
          currency,
          canonicalAmountEUR: quote.totalAmountEUR,
          status: TransactionStatus.PENDING,
          idempotencyKey: idempotencyKey ? `PAY-${idempotencyKey}` : null,
          providerMetadata: {
            quoteSnapshotId: quote.exchangeRateSnapshotId,
            rateSource: quote.rateSource,
          },
        },
      });

      return { investment, paymentTransaction: paymentTx };
    });

    // 5. Audit Log
    if (userId) {
      await AuditService.log({
        userId,
        action: 'INVESTMENT_CREATED',
        entityType: 'Investment',
        entityId: result.investment.id,
        newState: {
          investmentId: result.investment.id,
          amountEUR: quote.totalAmountEUR.toString(),
          currency,
          resalePlan,
        },
        ipAddress,
        userAgent,
      });
    }

    logger.info('Investment intent created with pending payment', {
      investmentId: result.investment.id,
      partnerProfileId,
      amountEUR: quote.totalAmountEUR.toString(),
      currency,
    });

    return prisma.investment.findUnique({
      where: { id: result.investment.id },
      include: {
        items: true,
        paymentTransactions: true,
        deliveryAddress: true,
      },
    });
  }

  /**
   * Retrieves investments for a partner profile or admin view with pagination.
   */
  static async getInvestments(options: InvestmentFilterOptions) {
    const page = Math.max(1, options.page || 1);
    const limit = Math.min(100, Math.max(1, options.limit || 20));
    const skip = (page - 1) * limit;

    const where: Prisma.InvestmentWhereInput = {};

    if (options.partnerProfileId) {
      where.partnerProfileId = options.partnerProfileId;
    }

    if (options.status) {
      where.status = options.status;
    }

    const [investments, total] = await Promise.all([
      prisma.investment.findMany({
        where,
        include: {
          items: true,
          batch: {
            include: {
              payouts: {
                orderBy: { payoutIndex: 'asc' },
              },
            },
          },
          paymentTransactions: true,
          deliveryAddress: true,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.investment.count({ where }),
    ]);

    return {
      investments,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  }

  /**
   * Retrieves a single investment by ID with ownership enforcement.
   */
  static async getInvestmentById(id: string, partnerProfileId: string, isAdmin = false) {
    const investment = await prisma.investment.findUnique({
      where: { id },
      include: {
        items: true,
        batch: {
          include: {
            payouts: {
              orderBy: { payoutIndex: 'asc' },
            },
          },
        },
        paymentTransactions: true,
        deliveryAddress: true,
        partnerProfile: {
          select: { id: true, fullName: true, preferredCurrency: true },
        },
      },
    });

    if (!investment) {
      throw AppError.notFound(`Investment ${id} not found`);
    }

    if (!isAdmin && investment.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to access this investment');
    }

    return investment;
  }

  /**
   * TEST-ONLY SETTLEMENT FIXTURE
   * Strictly disabled in production. Used exclusively by integration test suites to simulate
   * verified payment settlement and trigger Option B investment batch activation and ledger posting.
   */
  static async testOnlySimulatePaymentSettlement(investmentId: string) {
    if (process.env.NODE_ENV !== 'test') {
      throw new Error('Test settlement fixture is strictly prohibited outside test environment');
    }

    return prisma.$transaction(async (tx) => {
      const investment = await tx.investment.findUnique({
        where: { id: investmentId },
        include: { partnerProfile: true },
      });

      if (!investment) {
        throw new Error(`Investment ${investmentId} not found`);
      }

      // Update payment transactions to SUCCESSFUL
      await tx.paymentTransaction.updateMany({
        where: { investmentId },
        data: { status: TransactionStatus.SUCCESSFUL },
      });

      // Update investment to ACTIVE
      await tx.investment.update({
        where: { id: investmentId },
        data: { status: InvestmentStatus.ACTIVE },
      });

      // Ensure platform escrow and partner locked capital accounts
      const escrowAccountId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_ESCROW);
      const lockedCapitalAccountId = await LedgerService.ensurePartnerAccount(
        investment.partnerProfileId,
        AccountType.LOCKED_CAPITAL
      );

      // Post balanced funding transaction: DEBIT Escrow, CREDIT Locked Capital
      await LedgerService.postTransaction(
        {
          referenceNumber: `LEDGER-FUND-${investment.id}`,
          description: `Capital funding for investment ${investment.id}`,
          sourceEntity: 'Investment',
          sourceEntityId: investment.id,
          entries: [
            {
              accountId: escrowAccountId,
              entryType: EntryType.DEBIT,
              amount: investment.totalAmountInCurrency,
              currency: investment.currency,
              amountEUR: investment.totalAmountEUR,
            },
            {
              accountId: lockedCapitalAccountId,
              entryType: EntryType.CREDIT,
              amount: investment.totalAmountEUR,
              currency: Currency.EUR,
              amountEUR: investment.totalAmountEUR,
            },
          ],
        },
        tx
      );

      // If Option B, create InvestmentBatch and 12 scheduled payouts
      if (investment.resalePlan === ResalePlan.SELLFOR) {
        const today = new Date();
        const firstPayout = new Date(today);
        firstPayout.setDate(firstPayout.getDate() + 30);

        const unlockDate = new Date(today);
        unlockDate.setFullYear(unlockDate.getFullYear() + 1);

        const batch = await tx.investmentBatch.create({
          data: {
            investmentId: investment.id,
            partnerProfileId: investment.partnerProfileId,
            capitalEUR: investment.totalAmountEUR,
            monthlyReturnRate: new Prisma.Decimal('0.0700'),
            discountMultiplier: new Prisma.Decimal('0.86'),
            lockDurationMonths: 12,
            startDate: today,
            firstPayoutDate: firstPayout,
            capitalUnlockDate: unlockDate,
            status: BatchStatus.ACTIVE,
          },
        });

        // 12 monthly payouts of 7%
        const monthlyAmountEUR = investment.totalAmountEUR
          .mul(new Prisma.Decimal('0.0700'))
          .toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

        const payoutsData = [];
        for (let i = 1; i <= 12; i++) {
          const dueDate = new Date(today);
          dueDate.setDate(dueDate.getDate() + 30 * i);

          payoutsData.push({
            batchId: batch.id,
            partnerProfileId: investment.partnerProfileId,
            payoutIndex: i,
            dueDate,
            amountEUR: monthlyAmountEUR,
            status: PayoutStatus.SCHEDULED,
          });
        }

        await tx.payout.createMany({
          data: payoutsData,
        });
      }

      return investment;
    });
  }
}
