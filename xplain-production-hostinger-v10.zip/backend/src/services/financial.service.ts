import { Prisma, AccountType, BatchStatus, PayoutStatus } from '@prisma/client';
import { prisma } from '../config/database.js';
import { LedgerService } from './ledger.service.js';
import { convertCurrency, resolveExchangeRate } from '../utils/currency.js';

export interface FinancialSummaryDTO {
  availableReturnsEUR: string;
  lockedCapitalEUR: string;
  unlockedCapitalEUR: string;
  totalInvestedEUR: string;
  totalPaidOutEUR: string;
  availableReturnsInCurrency: string;
  lockedCapitalInCurrency: string;
  unlockedCapitalInCurrency: string;
  portfolioValueInCurrency: string;
  preferredCurrency: string;
  activeBatchesCount: number;
  completedBatchesCount: number;
}

export class FinancialService {
  /**
   * Aggregates the authoritative financial summary for a partner profile directly from PostgreSQL ledger.
   */
  static async getPartnerFinancialSummary(partnerProfileId: string): Promise<FinancialSummaryDTO> {
    const partner = await prisma.partnerProfile.findUnique({
      where: { id: partnerProfileId },
      include: {
        investmentBatches: {
          include: {
            payouts: true,
          },
        },
      },
    });

    if (!partner) {
      return {
        availableReturnsEUR: '0.00',
        lockedCapitalEUR: '0.00',
        unlockedCapitalEUR: '0.00',
        totalInvestedEUR: '0.00',
        totalPaidOutEUR: '0.00',
        availableReturnsInCurrency: '0.00',
        lockedCapitalInCurrency: '0.00',
        unlockedCapitalInCurrency: '0.00',
        portfolioValueInCurrency: '0.00',
        preferredCurrency: 'EUR',
        activeBatchesCount: 0,
        completedBatchesCount: 0,
      };
    }

    // 1. Fetch or initialize account IDs
    const availableReturnsAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.AVAILABLE_RETURNS
    );
    const lockedCapitalAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.LOCKED_CAPITAL
    );
    const unlockedCapitalAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.UNLOCKED_CAPITAL
    );

    // 2. Fetch real ledger balances
    const [availableReturnsBal, lockedCapitalBal, unlockedCapitalBal] = await Promise.all([
      LedgerService.getAccountBalance(availableReturnsAccId),
      LedgerService.getAccountBalance(lockedCapitalAccId),
      LedgerService.getAccountBalance(unlockedCapitalAccId),
    ]);

    // 3. Aggregate batches and payouts
    let totalInvested = new Prisma.Decimal('0.00');
    let totalPaidOut = new Prisma.Decimal('0.00');
    let activeBatches = 0;
    let completedBatches = 0;

    for (const batch of partner.investmentBatches) {
      totalInvested = totalInvested.plus(batch.capitalEUR);
      if (batch.status === BatchStatus.ACTIVE) {
        activeBatches++;
      } else if (batch.status === BatchStatus.MATURED || batch.status === BatchStatus.DELIVERED) {
        completedBatches++;
      }

      for (const payout of batch.payouts) {
        if (payout.status === PayoutStatus.PAID) {
          totalPaidOut = totalPaidOut.plus(payout.amountEUR);
        }
      }
    }

    // 4. Multi-currency conversions using latest snapshot
    const rateSnapshot = await resolveExchangeRate('EUR', partner.preferredCurrency);
    const rate = rateSnapshot.rate;

    const availableReturnsInCur = convertCurrency(availableReturnsBal, rate);
    const lockedCapitalInCur = convertCurrency(lockedCapitalBal, rate);
    const unlockedCapitalInCur = convertCurrency(unlockedCapitalBal, rate);
    const portfolioValueInCur = lockedCapitalInCur.plus(unlockedCapitalInCur).plus(availableReturnsInCur);

    return {
      availableReturnsEUR: availableReturnsBal.toFixed(2),
      lockedCapitalEUR: lockedCapitalBal.toFixed(2),
      unlockedCapitalEUR: unlockedCapitalBal.toFixed(2),
      totalInvestedEUR: totalInvested.toFixed(2),
      totalPaidOutEUR: totalPaidOut.toFixed(2),
      availableReturnsInCurrency: availableReturnsInCur.toFixed(2),
      lockedCapitalInCurrency: lockedCapitalInCur.toFixed(2),
      unlockedCapitalInCurrency: unlockedCapitalInCur.toFixed(2),
      portfolioValueInCurrency: portfolioValueInCur.toFixed(2),
      preferredCurrency: partner.preferredCurrency,
      activeBatchesCount: activeBatches,
      completedBatchesCount: completedBatches,
    };
  }
}
