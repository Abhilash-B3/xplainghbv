import { checkDatabaseHealth, type DatabaseHealthResult } from '../config/database.js';
import { checkRedisHealth, type RedisHealthResult } from '../config/redis.js';
import { env } from '../config/env.js';

export interface HealthCheckData {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptimeSeconds: number;
  environment: string;
  version: string;
  services: {
    database: DatabaseHealthResult;
    redis: RedisHealthResult;
  };
}

export async function getSystemHealth(): Promise<{ isHealthy: boolean; data: HealthCheckData }> {
  const [dbHealth, redisHealth] = await Promise.all([
    checkDatabaseHealth(),
    checkRedisHealth(),
  ]);

  const isHealthy = dbHealth.status === 'healthy';
  const isRedisDegraded = redisHealth.status === 'unhealthy';

  const overallStatus: 'healthy' | 'degraded' | 'unhealthy' = !isHealthy
    ? 'unhealthy'
    : isRedisDegraded
    ? 'degraded'
    : 'healthy';

  const data: HealthCheckData = {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.round(process.uptime()),
    environment: env.NODE_ENV,
    version: '1.0.0',
    services: {
      database: dbHealth,
      redis: redisHealth,
    },
  };

  return {
    isHealthy,
    data,
  };
}
