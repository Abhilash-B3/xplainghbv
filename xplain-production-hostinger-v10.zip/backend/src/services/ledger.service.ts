import { Prisma, AccountType, EntryType, Currency } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';

export interface LedgerEntryInput {
  accountId: string;
  entryType: EntryType;
  amount: Prisma.Decimal;
  currency: Currency;
  amountEUR: Prisma.Decimal;
}

export interface PostTransactionParams {
  referenceNumber: string;
  description: string;
  sourceEntity: string;
  sourceEntityId: string;
  entries: LedgerEntryInput[];
  validateBackingBalance?: boolean; // Ensures debit source has sufficient backing
}

export class LedgerService {
  /**
   * Ensures system-level financial accounts exist in PostgreSQL.
   */
  static async ensureSystemAccount(accountType: AccountType): Promise<string> {
    const existing = await prisma.financialAccount.findFirst({
      where: { partnerProfileId: null, accountType },
    });

    if (existing) {
      return existing.id;
    }

    const created = await prisma.financialAccount.create({
      data: {
        partnerProfileId: null,
        accountType,
        currency: Currency.EUR,
      },
    });

    return created.id;
  }

  /**
   * Ensures partner-specific financial accounts exist for a given partner profile.
   */
  static async ensurePartnerAccount(
    partnerProfileId: string,
    accountType: AccountType,
    currency: Currency = Currency.EUR
  ): Promise<string> {
    const existing = await prisma.financialAccount.findUnique({
      where: {
        partnerProfileId_accountType: {
          partnerProfileId,
          accountType,
        },
      },
    });

    if (existing) {
      return existing.id;
    }

    const created = await prisma.financialAccount.create({
      data: {
        partnerProfileId,
        accountType,
        currency,
      },
    });

    return created.id;
  }

  /**
   * Computes the authoritative balance of a financial account directly from ledger entries.
   */
  static async getAccountBalance(
    accountId: string,
    tx?: Prisma.TransactionClient
  ): Promise<Prisma.Decimal> {
    const client = tx || prisma;
    const account = await client.financialAccount.findUnique({
      where: { id: accountId },
    });

    if (!account) {
      throw AppError.notFound(`Financial account ${accountId} not found`);
    }

    const entries = await client.ledgerEntry.findMany({
      where: { accountId },
      select: { entryType: true, amountEUR: true },
    });

    let debits = new Prisma.Decimal('0.0000');
    let credits = new Prisma.Decimal('0.0000');

    for (const entry of entries) {
      if (entry.entryType === EntryType.DEBIT) {
        debits = debits.plus(entry.amountEUR);
      } else {
        credits = credits.plus(entry.amountEUR);
      }
    }

    // Determine normal balance based on account type
    if (account.accountType === AccountType.PLATFORM_ESCROW) {
      // Asset / Escrow: Normal Debit balance
      return debits.minus(credits).toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP);
    } else {
      // Liabilities / Equity / Partner Accounts / Revenue: Normal Credit balance
      return credits.minus(debits).toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP);
    }
  }

  /**
   * Posts a double-entry financial transaction atomically.
   * Enforces: SUM(Debits) === SUM(Credits) in canonical EUR.
   */
  static async postTransaction(
    params: PostTransactionParams,
    externalTx?: Prisma.TransactionClient
  ) {
    const { referenceNumber, description, sourceEntity, sourceEntityId, entries, validateBackingBalance } = params;

    if (!entries || entries.length < 2) {
      throw AppError.badRequest('A double-entry transaction must contain at least two entries');
    }

    // 1. Calculate and verify double-entry invariant: debits === credits
    let totalDebitsEUR = new Prisma.Decimal('0.0000');
    let totalCreditsEUR = new Prisma.Decimal('0.0000');

    for (const entry of entries) {
      const amtEUR = entry.amountEUR.toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP);
      if (amtEUR.lessThanOrEqualTo(0)) {
        throw AppError.badRequest(`Ledger entry amount must be strictly positive: ${amtEUR.toString()}`);
      }

      if (entry.entryType === EntryType.DEBIT) {
        totalDebitsEUR = totalDebitsEUR.plus(amtEUR);
      } else if (entry.entryType === EntryType.CREDIT) {
        totalCreditsEUR = totalCreditsEUR.plus(amtEUR);
      }
    }

    const diff = totalDebitsEUR.minus(totalCreditsEUR).abs();
    if (diff.greaterThan(new Prisma.Decimal('0.0001'))) {
      logger.error('Ledger imbalance detected', {
        referenceNumber,
        totalDebitsEUR: totalDebitsEUR.toString(),
        totalCreditsEUR: totalCreditsEUR.toString(),
        diff: diff.toString(),
      });
      throw AppError.badRequest(
        `Ledger transaction does not balance. Debits: ${totalDebitsEUR.toString()} EUR, Credits: ${totalCreditsEUR.toString()} EUR`
      );
    }

    const executeWork = async (tx: Prisma.TransactionClient) => {
      // 2. Check for duplicate reference number (Idempotency)
      const existingTx = await tx.ledgerTransaction.findUnique({
        where: { referenceNumber },
        include: { entries: true },
      });

      if (existingTx) {
        logger.warn('Duplicate ledger transaction skipped (idempotent)', { referenceNumber });
        return existingTx;
      }

      // 3. If validation is requested, ensure debit accounts have sufficient funds
      if (validateBackingBalance) {
        for (const entry of entries) {
          if (entry.entryType === EntryType.DEBIT) {
            const currentBalance = await this.getAccountBalance(entry.accountId, tx);
            const debitAmount = entry.amountEUR.toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP);
            if (currentBalance.lessThan(debitAmount)) {
              throw AppError.badRequest(
                `Insufficient balance in account ${entry.accountId} for debit of ${debitAmount.toString()} EUR. Current balance: ${currentBalance.toString()} EUR`
              );
            }
          }
        }
      }

      // 4. Create LedgerTransaction
      const transaction = await tx.ledgerTransaction.create({
        data: {
          referenceNumber,
          description,
          sourceEntity,
          sourceEntityId,
        },
      });

      // 5. Create LedgerEntries
      await tx.ledgerEntry.createMany({
        data: entries.map((e) => ({
          transactionId: transaction.id,
          accountId: e.accountId,
          entryType: e.entryType,
          amount: e.amount.toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP),
          currency: e.currency,
          amountEUR: e.amountEUR.toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP),
        })),
      });

      logger.info('Double-entry ledger transaction posted', {
        referenceNumber,
        transactionId: transaction.id,
        amountEUR: totalDebitsEUR.toString(),
        entriesCount: entries.length,
      });

      return transaction;
    };

    if (externalTx) {
      return executeWork(externalTx);
    }

    return prisma.$transaction(async (tx) => executeWork(tx));
  }
}
