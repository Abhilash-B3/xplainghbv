import {
  UserRole,
  AccountStatus,
  InvestmentStatus,
  WithdrawalStatus,
  Prisma,
} from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { AuditService } from './audit.service.js';

export interface UserListFilter {
  search?: string;
  role?: UserRole;
  status?: AccountStatus;
  limit?: number;
  offset?: number;
}

export interface InvestmentListFilter {
  status?: InvestmentStatus;
  search?: string;
  limit?: number;
  offset?: number;
}

export interface WithdrawalListFilter {
  status?: WithdrawalStatus;
  limit?: number;
  offset?: number;
}

export class AdminService {
  /**
   * Retrieves paginated users list with search and filtering.
   */
  static async getUsers(filter: UserListFilter) {
    const { search, role, status, limit = 20, offset = 0 } = filter;
    const where: Prisma.UserWhereInput = {};

    if (role) where.role = role;
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { partnerProfile: { fullName: { contains: search, mode: 'insensitive' } } },
        { partnerProfile: { referralCode: { contains: search, mode: 'insensitive' } } },
      ];
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        select: {
          id: true,
          email: true,
          phone: true,
          role: true,
          status: true,
          isEmailVerified: true,
          createdAt: true,
          partnerProfile: {
            select: {
              id: true,
              fullName: true,
              preferredCurrency: true,
              resalePlan: true,
              referralCode: true,
              kycStatus: true,
            },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    return { users, total, limit, offset };
  }

  /**
   * Retrieves detailed user profile with investments, batches, and financial accounts.
   */
  static async getUserDetails(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        partnerProfile: {
          include: {
            addresses: true,
            bankAccounts: true,
            moMoAccounts: true,
            financialAccounts: true,
            investmentBatches: {
              include: { payouts: true },
            },
            investments: {
              orderBy: { createdAt: 'desc' },
              include: { paymentTransactions: true },
            },
            withdrawals: {
              orderBy: { createdAt: 'desc' },
            },
            referees: true,
            commissionsEarned: true,
          },
        },
      },
    });

    if (!user) {
      throw AppError.notFound(`User ${userId} not found`);
    }

    return user;
  }

  /**
   * Updates user account status (e.g. SUSPENDED, ACTIVE).
   */
  static async updateUserStatus(userId: string, newStatus: AccountStatus, adminUserId: string) {
    const targetUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!targetUser) {
      throw AppError.notFound(`User ${userId} not found`);
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { status: newStatus },
      select: { id: true, email: true, role: true, status: true },
    });

    await AuditService.log({
      userId: adminUserId,
      action: 'USER_STATUS_UPDATED',
      entityType: 'User',
      entityId: userId,
      previousState: { status: targetUser.status },
      newState: { status: newStatus },
    });

    logger.info('User status updated by admin', { userId, newStatus, adminUserId });
    return updated;
  }

  /**
   * Updates user role (Superadmin only).
   */
  static async updateUserRole(userId: string, newRole: UserRole, adminUserId: string) {
    const targetUser = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!targetUser) {
      throw AppError.notFound(`User ${userId} not found`);
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { role: newRole },
      select: { id: true, email: true, role: true, status: true },
    });

    await AuditService.log({
      userId: adminUserId,
      action: 'USER_ROLE_UPDATED',
      entityType: 'User',
      entityId: userId,
      previousState: { role: targetUser.role },
      newState: { role: newRole },
    });

    logger.info('User role updated by superadmin', { userId, newRole, adminUserId });
    return updated;
  }

  /**
   * Retrieves all investments across all users.
   */
  static async getInvestments(filter: InvestmentListFilter) {
    const { status, search, limit = 20, offset = 0 } = filter;
    const where: Prisma.InvestmentWhereInput = {};

    if (status) where.status = status;
    if (search) {
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(search.trim());
      where.OR = [
        ...(isUuid ? [{ id: search.trim() }] : []),
        { partnerProfile: { fullName: { contains: search, mode: 'insensitive' as const } } },
        { partnerProfile: { user: { email: { contains: search, mode: 'insensitive' as const } } } },
      ];
    }

    const [investments, total] = await Promise.all([
      prisma.investment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          partnerProfile: {
            select: {
              fullName: true,
              user: { select: { email: true } },
            },
          },
          items: true,
          batch: true,
          paymentTransactions: true,
        },
      }),
      prisma.investment.count({ where }),
    ]);

    return { investments, total, limit, offset };
  }

  /**
   * Retrieves all withdrawals across all users with destination details.
   */
  static async getWithdrawals(filter: WithdrawalListFilter) {
    const { status, limit = 20, offset = 0 } = filter;
    const where: Prisma.WithdrawalWhereInput = {};

    if (status) where.status = status;

    const [withdrawals, total] = await Promise.all([
      prisma.withdrawal.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          partnerProfile: {
            select: {
              fullName: true,
              user: { select: { email: true } },
            },
          },
          bankAccount: {
            select: { bankName: true, accountNumberMasked: true, sortCodeOrSwift: true },
          },
          moMoAccount: {
            select: { provider: true, phoneNumberMasked: true },
          },
          approvedByUser: {
            select: { email: true },
          },
        },
      }),
      prisma.withdrawal.count({ where }),
    ]);

    return { withdrawals, total, limit, offset };
  }

  /**
   * Retrieves all referrals and commissions.
   */
  static async getReferrals(limit = 20, offset = 0) {
    const [referrals, total] = await Promise.all([
      prisma.referral.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          referrer: {
            select: { fullName: true, referralCode: true, user: { select: { email: true } } },
          },
          referee: {
            select: { fullName: true, user: { select: { email: true } } },
          },
          commissions: true,
        },
      }),
      prisma.referral.count(),
    ]);

    return { referrals, total, limit, offset };
  }

  /**
   * Explores double-entry ledger transactions and entries.
   */
  static async getLedgerTransactions(limit = 30, offset = 0) {
    const [transactions, total] = await Promise.all([
      prisma.ledgerTransaction.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          entries: {
            include: {
              account: {
                select: { accountType: true, partnerProfileId: true },
              },
            },
          },
        },
      }),
      prisma.ledgerTransaction.count(),
    ]);

    return { transactions, total, limit, offset };
  }

  /**
   * Explores audit logs.
   */
  static async getAuditLogs(limit = 50, offset = 0) {
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
        include: {
          user: {
            select: { email: true, role: true },
          },
        },
      }),
      prisma.auditLog.count(),
    ]);

    return { logs, total, limit, offset };
  }
}
