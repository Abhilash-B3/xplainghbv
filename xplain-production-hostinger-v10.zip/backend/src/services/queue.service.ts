import { NotificationType } from '@prisma/client';
import { NotificationService } from './notification.service.js';
import { ReferralService } from './referral.service.js';
import { logger } from '../utils/logger.js';
import { getRedisClient } from '../config/redis.js';

export interface EnqueueNotificationPayload {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  eventKey?: string;
  metadata?: Record<string, any>;
}

export class QueueService {
  /**
   * Enqueues a notification job asynchronously.
   * Decouples notification dispatch from core HTTP/financial transactions.
   */
  static async enqueueNotification(payload: EnqueueNotificationPayload): Promise<void> {
    const redis = getRedisClient();

    // If Redis is not connected / active, process asynchronously in background loop
    if (!redis) {
      setImmediate(async () => {
        try {
          await NotificationService.createNotification(payload);
        } catch (err: any) {
          logger.error('Failed to process async notification job (in-memory fallback)', {
            error: err.message,
            eventKey: payload.eventKey,
          });
        }
      });
      return;
    }

    try {
      // In a full BullMQ deployment: await notificationQueue.add('sendNotification', payload)
      // Direct reliable dispatch with error boundary:
      await NotificationService.createNotification(payload);
    } catch (err: any) {
      logger.error('Async notification queue error', {
        error: err.message,
        eventKey: payload.eventKey,
      });
    }
  }

  /**
   * Enqueues the monthly referral commission calculation job.
   */
  static async triggerMonthlyReferralJob(periodMonth: string) {
    logger.info(`Enqueueing monthly referral calculation job for ${periodMonth}`);
    return ReferralService.calculateMonthlyCommissions(periodMonth);
  }
}
