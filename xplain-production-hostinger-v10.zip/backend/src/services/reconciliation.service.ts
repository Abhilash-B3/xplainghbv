import { Prisma, EntryType, AccountType, BatchStatus, WithdrawalStatus } from '@prisma/client';
import { prisma } from '../config/database.js';
import { logger } from '../utils/logger.js';
import { LedgerService } from './ledger.service.js';

export interface ReconciliationReport {
  timestamp: string;
  isBalanced: boolean;
  totalDebitsEUR: string;
  totalCreditsEUR: string;
  ledgerImbalanceEUR: string;
  platformEscrowBalanceEUR: string;
  lockedCapitalBalanceEUR: string;
  totalActiveBatchesCapitalEUR: string;
  capitalDiscrepancyEUR: string;
  withdrawalReservedBalanceEUR: string;
  pendingWithdrawalsSumEUR: string;
  withdrawalReservationDiscrepancyEUR: string;
  discrepanciesCount: number;
  discrepancies: string[];
}

export class ReconciliationService {
  /**
   * Performs an automated financial reconciliation audit across the double-entry ledger and entities.
   */
  static async runReconciliation(): Promise<ReconciliationReport> {
    logger.info('Running financial ledger reconciliation audit...');

    // 1. Double-Entry Balance Check across all LedgerEntry records
    const allEntries = await prisma.ledgerEntry.findMany({
      select: { entryType: true, amountEUR: true },
    });

    let totalDebits = new Prisma.Decimal('0.0000');
    let totalCredits = new Prisma.Decimal('0.0000');

    for (const e of allEntries) {
      if (e.entryType === EntryType.DEBIT) {
        totalDebits = totalDebits.plus(e.amountEUR);
      } else {
        totalCredits = totalCredits.plus(e.amountEUR);
      }
    }

    const ledgerDiff = totalDebits.minus(totalCredits).abs();
    const isBalanced = ledgerDiff.lessThan(new Prisma.Decimal('0.0001'));

    const discrepancies: string[] = [];

    if (!isBalanced) {
      discrepancies.push(
        `Global Ledger Imbalance: Debits (${totalDebits.toFixed(4)} EUR) != Credits (${totalCredits.toFixed(4)} EUR). Difference: ${ledgerDiff.toFixed(4)} EUR`
      );
    }

    // 2. Platform Escrow Balance Check
    const escrowAccId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_ESCROW);
    const platformEscrowBalance = await LedgerService.getAccountBalance(escrowAccId);

    // 3. Locked Capital Check (Ledger vs Active Batches)
    const activeBatches = await prisma.investmentBatch.findMany({
      where: { status: BatchStatus.ACTIVE },
      select: { capitalEUR: true },
    });

    let totalActiveBatchesCapital = new Prisma.Decimal('0.00');
    for (const b of activeBatches) {
      totalActiveBatchesCapital = totalActiveBatchesCapital.plus(b.capitalEUR);
    }

    // Sum all partner LOCKED_CAPITAL ledger accounts
    const lockedCapitalAccounts = await prisma.financialAccount.findMany({
      where: { accountType: AccountType.LOCKED_CAPITAL },
      select: { id: true },
    });

    let totalLockedCapitalLedger = new Prisma.Decimal('0.0000');
    for (const acc of lockedCapitalAccounts) {
      const bal = await LedgerService.getAccountBalance(acc.id);
      totalLockedCapitalLedger = totalLockedCapitalLedger.plus(bal);
    }

    const capitalDiff = totalLockedCapitalLedger.minus(totalActiveBatchesCapital).abs();
    if (capitalDiff.greaterThan(new Prisma.Decimal('0.01'))) {
      discrepancies.push(
        `Capital Reconciliation Discrepancy: Ledger Locked Capital (${totalLockedCapitalLedger.toFixed(2)} EUR) differs from Active Batches Capital (${totalActiveBatchesCapital.toFixed(2)} EUR) by ${capitalDiff.toFixed(2)} EUR`
      );
    }

    // 4. Withdrawal Reservations Check (Ledger vs Pending Withdrawals)
    const pendingWithdrawals = await prisma.withdrawal.findMany({
      where: {
        status: {
          in: [WithdrawalStatus.PENDING, WithdrawalStatus.APPROVED, WithdrawalStatus.PROCESSING],
        },
      },
      select: { amountEUR: true },
    });

    let pendingWithdrawalsSum = new Prisma.Decimal('0.00');
    for (const w of pendingWithdrawals) {
      pendingWithdrawalsSum = pendingWithdrawalsSum.plus(w.amountEUR);
    }

    const reservedAccounts = await prisma.financialAccount.findMany({
      where: { accountType: AccountType.WITHDRAWAL_RESERVED },
      select: { id: true },
    });

    let totalReservedLedger = new Prisma.Decimal('0.0000');
    for (const acc of reservedAccounts) {
      const bal = await LedgerService.getAccountBalance(acc.id);
      totalReservedLedger = totalReservedLedger.plus(bal);
    }

    const reservationDiff = totalReservedLedger.minus(pendingWithdrawalsSum).abs();
    if (reservationDiff.greaterThan(new Prisma.Decimal('0.01'))) {
      discrepancies.push(
        `Withdrawal Reservation Discrepancy: Ledger Reserved (${totalReservedLedger.toFixed(2)} EUR) differs from Pending/Processing Withdrawals (${pendingWithdrawalsSum.toFixed(2)} EUR) by ${reservationDiff.toFixed(2)} EUR`
      );
    }

    const report: ReconciliationReport = {
      timestamp: new Date().toISOString(),
      isBalanced: discrepancies.length === 0,
      totalDebitsEUR: totalDebits.toFixed(4),
      totalCreditsEUR: totalCredits.toFixed(4),
      ledgerImbalanceEUR: ledgerDiff.toFixed(4),
      platformEscrowBalanceEUR: platformEscrowBalance.toFixed(2),
      lockedCapitalBalanceEUR: totalLockedCapitalLedger.toFixed(2),
      totalActiveBatchesCapitalEUR: totalActiveBatchesCapital.toFixed(2),
      capitalDiscrepancyEUR: capitalDiff.toFixed(2),
      withdrawalReservedBalanceEUR: totalReservedLedger.toFixed(2),
      pendingWithdrawalsSumEUR: pendingWithdrawalsSum.toFixed(2),
      withdrawalReservationDiscrepancyEUR: reservationDiff.toFixed(2),
      discrepanciesCount: discrepancies.length,
      discrepancies,
    };

    logger.info('Reconciliation audit completed', {
      isBalanced: report.isBalanced,
      discrepanciesCount: discrepancies.length,
    });

    return report;
  }
}
