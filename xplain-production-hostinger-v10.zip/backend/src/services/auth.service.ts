import { prisma } from '../config/database.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { generateSecureToken, hashToken } from '../utils/token.js';
import { AppError } from '../utils/appError.js';
import { AuditService } from './audit.service.js';
import { EmailService } from './email.service.js';
import { SESSION_MAX_AGE_MS } from '../utils/cookie.js';
import type { Currency, ResalePlan, UserRole, AccountStatus, KYCStatus } from '@prisma/client';

export interface RegisterInput {
  email: string;
  password: string;
  phone: string;
  fullName: string;
  preferredCurrency?: Currency;
  resalePlan?: ResalePlan;
  referralCode?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface LoginInput {
  email: string;
  password: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface SafeUser {
  id: string;
  email: string;
  phone: string;
  role: UserRole;
  status: AccountStatus;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  twoFactorEnabled: boolean;
  createdAt: Date;
  partnerProfile?: {
    id: string;
    fullName: string;
    preferredCurrency: Currency;
    referralCode: string;
    kycStatus: KYCStatus;
    resalePlan: ResalePlan | null;
  } | null;
}

export interface AuthSessionResult {
  user: SafeUser;
  sessionToken: string;
}

import crypto from 'crypto';

function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'XP-';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(crypto.randomInt(0, chars.length));
  }
  return code;
}

export class AuthService {
  /**
   * Registers a new User, creates their PartnerProfile, financial ledger accounts,
   * verification token, and audit record inside a database transaction.
   */
  static async register(input: RegisterInput): Promise<AuthSessionResult> {
    const normalizedEmail = input.email.trim().toLowerCase();
    const normalizedPhone = input.phone.trim();

    // 1. Check for existing email or phone
    const existing = await prisma.user.findFirst({
      where: {
        OR: [{ email: normalizedEmail }, { phone: normalizedPhone }],
      },
    });

    if (existing) {
      if (existing.email === normalizedEmail) {
        throw AppError.conflict('An account with this email address already exists');
      }
      throw AppError.conflict('An account with this phone number already exists');
    }

    // 2. Hash password with Argon2id
    const passwordHash = await hashPassword(input.password);

    // 3. Generate referral code
    let referralCode = generateReferralCode();
    while (await prisma.partnerProfile.findUnique({ where: { referralCode } })) {
      referralCode = generateReferralCode();
    }

    // 4. Check referrer if referral code provided
    let referrerProfileId: string | null = null;
    if (input.referralCode) {
      const referrer = await prisma.partnerProfile.findUnique({
        where: { referralCode: input.referralCode.trim().toUpperCase() },
      });
      if (referrer) {
        referrerProfileId = referrer.id;
      }
    }

    // 5. Generate secure session token and email verification token
    const rawSessionToken = generateSecureToken(32);
    const sessionTokenHash = hashToken(rawSessionToken);
    const sessionExpiresAt = new Date(Date.now() + SESSION_MAX_AGE_MS);

    const rawVerificationToken = generateSecureToken(32);
    const verificationTokenHash = hashToken(rawVerificationToken);
    const verificationExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    // 6. Execute atomic creation in PostgreSQL
    const createdData = await prisma.$transaction(async (tx) => {
      // Create user
      const user = await tx.user.create({
        data: {
          email: normalizedEmail,
          phone: normalizedPhone,
          passwordHash,
          role: 'INVESTOR',
          status: 'ACTIVE',
          isEmailVerified: false,
        },
      });

      // Create partner profile
      const partnerProfile = await tx.partnerProfile.create({
        data: {
          userId: user.id,
          fullName: input.fullName.trim(),
          preferredCurrency: input.preferredCurrency ?? 'EUR',
          resalePlan: input.resalePlan ?? null,
          referralCode,
          kycStatus: 'NOT_SUBMITTED',
        },
      });

      // Link referral if valid
      if (referrerProfileId && referrerProfileId !== partnerProfile.id) {
        await tx.referral.create({
          data: {
            referrerProfileId,
            refereeProfileId: partnerProfile.id,
            status: 'REGISTERED',
          },
        });
      }

      // Initialize standard financial ledger accounts
      await tx.financialAccount.createMany({
        data: [
          {
            partnerProfileId: partnerProfile.id,
            accountType: 'AVAILABLE_RETURNS',
            currency: partnerProfile.preferredCurrency,
          },
          {
            partnerProfileId: partnerProfile.id,
            accountType: 'LOCKED_CAPITAL',
            currency: partnerProfile.preferredCurrency,
          },
          {
            partnerProfileId: partnerProfile.id,
            accountType: 'UNLOCKED_CAPITAL',
            currency: partnerProfile.preferredCurrency,
          },
          {
            partnerProfileId: partnerProfile.id,
            accountType: 'REFERRAL_BONUS_PAYABLE',
            currency: partnerProfile.preferredCurrency,
          },
        ],
      });

      // Create session
      await tx.session.create({
        data: {
          userId: user.id,
          tokenHash: sessionTokenHash,
          expiresAt: sessionExpiresAt,
          ipAddress: input.ipAddress ?? null,
          userAgent: input.userAgent ?? null,
        },
      });

      // Create verification token
      await tx.emailVerificationToken.create({
        data: {
          userId: user.id,
          tokenHash: verificationTokenHash,
          expiresAt: verificationExpiresAt,
        },
      });

      // Record audit log
      await AuditService.log(
        {
          userId: user.id,
          action: 'USER_REGISTERED',
          entityType: 'User',
          entityId: user.id,
          newState: { email: user.email, role: user.role, status: user.status },
          ipAddress: input.ipAddress,
          userAgent: input.userAgent,
        },
        tx
      );

      return { user, partnerProfile };
    });

    // 7. Dispatch verification email (non-blocking)
    EmailService.sendVerificationEmail(
      createdData.user.email,
      rawVerificationToken,
      createdData.partnerProfile.fullName
    ).catch(() => {});

    return {
      sessionToken: rawSessionToken,
      user: {
        id: createdData.user.id,
        email: createdData.user.email,
        phone: createdData.user.phone,
        role: createdData.user.role,
        status: createdData.user.status,
        isEmailVerified: createdData.user.isEmailVerified,
        isPhoneVerified: createdData.user.isPhoneVerified,
        twoFactorEnabled: createdData.user.twoFactorEnabled,
        createdAt: createdData.user.createdAt,
        partnerProfile: {
          id: createdData.partnerProfile.id,
          fullName: createdData.partnerProfile.fullName,
          preferredCurrency: createdData.partnerProfile.preferredCurrency,
          referralCode: createdData.partnerProfile.referralCode,
          kycStatus: createdData.partnerProfile.kycStatus,
          resalePlan: createdData.partnerProfile.resalePlan,
        },
      },
    };
  }

  /**
   * Authenticates user against PostgreSQL and creates a server session.
   */
  static async login(input: LoginInput): Promise<AuthSessionResult> {
    const normalizedEmail = input.email.trim().toLowerCase();

    // 1. Find user by email
    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      include: { partnerProfile: true },
    });

    if (!user) {
      await AuditService.log({
        action: 'LOGIN_FAILED',
        entityType: 'User',
        entityId: 'UNKNOWN',
        newState: { email: normalizedEmail, reason: 'USER_NOT_FOUND' },
        ipAddress: input.ipAddress,
        userAgent: input.userAgent,
      });
      throw AppError.unauthorized('Invalid email or password');
    }

    // 2. Verify password
    const isPasswordValid = await verifyPassword(input.password, user.passwordHash);
    if (!isPasswordValid) {
      await AuditService.log({
        userId: user.id,
        action: 'LOGIN_FAILED',
        entityType: 'User',
        entityId: user.id,
        newState: { email: normalizedEmail, reason: 'INVALID_PASSWORD' },
        ipAddress: input.ipAddress,
        userAgent: input.userAgent,
      });
      throw AppError.unauthorized('Invalid email or password');
    }

    // 3. Check account status
    if (user.status !== 'ACTIVE') {
      throw AppError.forbidden('Your account has been suspended or deactivated');
    }

    // 4. Create new authenticated session
    const rawSessionToken = generateSecureToken(32);
    const tokenHash = hashToken(rawSessionToken);
    const expiresAt = new Date(Date.now() + SESSION_MAX_AGE_MS);

    await prisma.session.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt,
        ipAddress: input.ipAddress ?? null,
        userAgent: input.userAgent ?? null,
      },
    });

    // 5. Log success audit
    await AuditService.log({
      userId: user.id,
      action: 'LOGIN_SUCCESS',
      entityType: 'Session',
      entityId: user.id,
      ipAddress: input.ipAddress,
      userAgent: input.userAgent,
    });

    return {
      sessionToken: rawSessionToken,
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        isEmailVerified: user.isEmailVerified,
        isPhoneVerified: user.isPhoneVerified,
        twoFactorEnabled: user.twoFactorEnabled,
        createdAt: user.createdAt,
        partnerProfile: user.partnerProfile
          ? {
              id: user.partnerProfile.id,
              fullName: user.partnerProfile.fullName,
              preferredCurrency: user.partnerProfile.preferredCurrency,
              referralCode: user.partnerProfile.referralCode,
              kycStatus: user.partnerProfile.kycStatus,
              resalePlan: user.partnerProfile.resalePlan,
            }
          : null,
      },
    };
  }

  /**
   * Validates a raw session token against PostgreSQL.
   */
  static async validateSession(rawToken: string): Promise<SafeUser | null> {
    if (!rawToken || typeof rawToken !== 'string') {
      return null;
    }

    const tokenHash = hashToken(rawToken);

    const session = await prisma.session.findUnique({
      where: { tokenHash },
      include: {
        user: {
          include: { partnerProfile: true },
        },
      },
    });

    if (!session) {
      return null;
    }

    // Check revocation and expiration
    if (session.revokedAt !== null || session.expiresAt < new Date()) {
      return null;
    }

    // Check user active status
    if (session.user.status !== 'ACTIVE') {
      return null;
    }

    return {
      id: session.user.id,
      email: session.user.email,
      phone: session.user.phone,
      role: session.user.role,
      status: session.user.status,
      isEmailVerified: session.user.isEmailVerified,
      isPhoneVerified: session.user.isPhoneVerified,
      twoFactorEnabled: session.user.twoFactorEnabled,
      createdAt: session.user.createdAt,
      partnerProfile: session.user.partnerProfile
        ? {
            id: session.user.partnerProfile.id,
            fullName: session.user.partnerProfile.fullName,
            preferredCurrency: session.user.partnerProfile.preferredCurrency,
            referralCode: session.user.partnerProfile.referralCode,
            kycStatus: session.user.partnerProfile.kycStatus,
            resalePlan: session.user.partnerProfile.resalePlan,
          }
        : null,
    };
  }

  /**
   * Revokes the active session in PostgreSQL.
   */
  static async logout(rawToken: string, userId?: string): Promise<void> {
    if (!rawToken) return;

    const tokenHash = hashToken(rawToken);

    await prisma.session.updateMany({
      where: { tokenHash, revokedAt: null },
      data: { revokedAt: new Date() },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'LOGOUT',
        entityType: 'Session',
        entityId: userId,
      });
    }
  }

  /**
   * Changes an authenticated user's password.
   */
  static async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string,
    currentToken?: string
  ): Promise<void> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw AppError.notFound('User not found');
    }

    const isMatch = await verifyPassword(currentPassword, user.passwordHash);
    if (!isMatch) {
      throw AppError.badRequest('Current password is incorrect');
    }

    const newHash = await hashPassword(newPassword);

    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: { passwordHash: newHash },
      });

      // Revoke other sessions for security (keep current if specified)
      if (currentToken) {
        const currentHash = hashToken(currentToken);
        await tx.session.updateMany({
          where: { userId, tokenHash: { not: currentHash }, revokedAt: null },
          data: { revokedAt: new Date() },
        });
      } else {
        await tx.session.updateMany({
          where: { userId, revokedAt: null },
          data: { revokedAt: new Date() },
        });
      }

      await AuditService.log(
        {
          userId,
          action: 'PASSWORD_CHANGED',
          entityType: 'User',
          entityId: userId,
        },
        tx
      );
    });
  }

  /**
   * Initiates password reset request without disclosing email existence.
   */
  static async forgotPassword(email: string): Promise<void> {
    const normalizedEmail = email.trim().toLowerCase();

    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      include: { partnerProfile: true },
    });

    if (!user) {
      // Silent success for enumeration protection
      return;
    }

    const rawToken = generateSecureToken(32);
    const tokenHash = hashToken(rawToken);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt,
      },
    });

    await AuditService.log({
      userId: user.id,
      action: 'PASSWORD_RESET_REQUESTED',
      entityType: 'PasswordResetToken',
      entityId: user.id,
    });

    EmailService.sendPasswordResetEmail(
      user.email,
      rawToken,
      user.partnerProfile?.fullName ?? 'Investor'
    ).catch(() => {});
  }

  /**
   * Resets password using a validated single-use token.
   */
  static async resetPassword(rawToken: string, newPassword: string): Promise<void> {
    const tokenHash = hashToken(rawToken);

    const resetToken = await prisma.passwordResetToken.findUnique({
      where: { tokenHash },
    });

    if (!resetToken || resetToken.usedAt !== null || resetToken.expiresAt < new Date()) {
      throw AppError.badRequest('Invalid, expired, or already used password reset token');
    }

    const newHash = await hashPassword(newPassword);

    await prisma.$transaction(async (tx) => {
      // Update password
      await tx.user.update({
        where: { id: resetToken.userId },
        data: { passwordHash: newHash },
      });

      // Mark token used
      await tx.passwordResetToken.update({
        where: { id: resetToken.id },
        data: { usedAt: new Date() },
      });

      // Revoke all existing sessions
      await tx.session.updateMany({
        where: { userId: resetToken.userId, revokedAt: null },
        data: { revokedAt: new Date() },
      });

      await AuditService.log(
        {
          userId: resetToken.userId,
          action: 'PASSWORD_RESET_COMPLETED',
          entityType: 'User',
          entityId: resetToken.userId,
        },
        tx
      );
    });
  }

  /**
   * Verifies email using a single-use token.
   */
  static async verifyEmail(rawToken: string): Promise<void> {
    const tokenHash = hashToken(rawToken);

    const verificationToken = await prisma.emailVerificationToken.findUnique({
      where: { tokenHash },
    });

    if (
      !verificationToken ||
      verificationToken.usedAt !== null ||
      verificationToken.expiresAt < new Date()
    ) {
      throw AppError.badRequest('Invalid, expired, or already used email verification token');
    }

    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: verificationToken.userId },
        data: { isEmailVerified: true },
      });

      await tx.emailVerificationToken.update({
        where: { id: verificationToken.id },
        data: { usedAt: new Date() },
      });

      await AuditService.log(
        {
          userId: verificationToken.userId,
          action: 'EMAIL_VERIFIED',
          entityType: 'User',
          entityId: verificationToken.userId,
        },
        tx
      );
    });
  }
}
