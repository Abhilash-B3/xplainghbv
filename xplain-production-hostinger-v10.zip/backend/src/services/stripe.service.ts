import crypto from 'crypto';
import Stripe from 'stripe';
import {
  Prisma,
  PaymentProvider,
  TransactionType,
  TransactionStatus,
  InvestmentStatus,
  ResalePlan,
  AccountType,
  EntryType,
  Currency,
  BatchStatus,
  PayoutStatus,
} from '@prisma/client';
import { prisma } from '../config/database.js';
import { env } from '../config/env.js';
import {
  stripeClient,
  validateStripeCurrency,
  toStripeAmount,
} from '../config/stripe.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { LedgerService } from './ledger.service.js';
import { AuditService } from './audit.service.js';

export interface CreatePaymentIntentInput {
  investmentId: string;
  partnerProfileId: string;
  userId?: string;
  idempotencyKey?: string;
  ipAddress?: string;
  userAgent?: string;
}

export class StripeService {
  /**
   * Creates or retrieves a Stripe PaymentIntent for a pending Investment.
   * Enforces ownership, loads server-authoritative frozen amount, and configures card-only payments.
   */
  static async createOrRetrievePaymentIntent(input: CreatePaymentIntentInput) {
    const { investmentId, partnerProfileId, userId, idempotencyKey, ipAddress, userAgent } = input;

    // 1. Load authoritative Investment from PostgreSQL
    const investment = await prisma.investment.findUnique({
      where: { id: investmentId },
      include: {
        paymentTransactions: true,
        items: true,
      },
    });

    if (!investment) {
      throw AppError.notFound(`Investment ${investmentId} not found`);
    }

    // 2. Enforce Ownership
    if (investment.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to initiate payment for this investment');
    }

    // 3. Prevent duplicate payment on already active/cancelled investments
    if (investment.status === InvestmentStatus.ACTIVE) {
      throw AppError.conflict('This investment has already been successfully funded and activated');
    }
    if (investment.status === InvestmentStatus.CANCELLED) {
      throw AppError.badRequest('This investment has been cancelled and cannot be paid');
    }

    // 4. Validate Currency Capability against configured Stripe environment
    validateStripeCurrency(investment.currency);

    // 5. Calculate authoritative Stripe amount in smallest currency unit
    const stripeAmount = toStripeAmount(investment.totalAmountInCurrency, investment.currency);

    // 6. Find or create PaymentTransaction record
    let paymentTx = investment.paymentTransactions.find(
      (tx) => tx.status === TransactionStatus.PENDING || tx.status === TransactionStatus.INITIALIZED
    );

    if (!paymentTx) {
      const refNumber = `TX-INV-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
      paymentTx = await prisma.paymentTransaction.create({
        data: {
          referenceNumber: refNumber,
          investmentId: investment.id,
          partnerProfileId: investment.partnerProfileId,
          provider: PaymentProvider.STRIPE,
          type: TransactionType.DEPOSIT,
          amount: investment.totalAmountInCurrency,
          currency: investment.currency,
          canonicalAmountEUR: investment.totalAmountEUR,
          status: TransactionStatus.PENDING,
          idempotencyKey: idempotencyKey ? `PAY-${idempotencyKey}` : null,
        },
      });
    }

    // 7. Check if existing valid Stripe PaymentIntent exists
    if (paymentTx.stripePaymentIntentId) {
      try {
        const existingIntent = await stripeClient.paymentIntents.retrieve(paymentTx.stripePaymentIntentId);
        
        // If reusable (requires_payment_method, requires_confirmation, requires_action)
        if (
          existingIntent.status === 'requires_payment_method' ||
          existingIntent.status === 'requires_confirmation' ||
          existingIntent.status === 'requires_action'
        ) {
          logger.info('Reusing existing active Stripe PaymentIntent', {
            paymentIntentId: existingIntent.id,
            investmentId,
            status: existingIntent.status,
          });

          return {
            clientSecret: existingIntent.client_secret,
            paymentTransactionId: paymentTx.id,
            publishableKey: env.STRIPE_PUBLISHABLE_KEY,
            amount: investment.totalAmountInCurrency.toString(),
            currency: investment.currency,
            status: existingIntent.status,
          };
        }
      } catch (err: any) {
        logger.warn('Failed to retrieve existing PaymentIntent from Stripe, will create new one', {
          stripePaymentIntentId: paymentTx.stripePaymentIntentId,
          error: err.message,
        });
      }
    }

    // 8. Create new Stripe PaymentIntent with Card payments only
    const idempotency = idempotencyKey || `pi_${paymentTx.id}_${Date.now()}`;
    const paymentIntent = await stripeClient.paymentIntents.create(
      {
        amount: stripeAmount,
        currency: investment.currency.toLowerCase(),
        payment_method_types: ['card'], // Card only (Visa, Mastercard, etc.)
        description: `Xplain GH BV Investment ${investment.id}`,
        metadata: {
          paymentTransactionId: paymentTx.id,
          investmentId: investment.id,
          partnerProfileId: investment.partnerProfileId,
          userId: userId || '',
          currency: investment.currency,
          totalAmount: investment.totalAmountInCurrency.toString(),
          canonicalEUR: investment.totalAmountEUR.toString(),
        },
      },
      {
        idempotencyKey: idempotency,
      }
    );

    // 9. Update PaymentTransaction with Stripe details
    await prisma.paymentTransaction.update({
      where: { id: paymentTx.id },
      data: {
        provider: PaymentProvider.STRIPE,
        providerTransactionId: paymentIntent.id,
        stripePaymentIntentId: paymentIntent.id,
        stripePaymentStatus: paymentIntent.status,
        status: TransactionStatus.PENDING,
      },
    });

    // 10. Audit Log
    if (userId) {
      await AuditService.log({
        userId,
        action: 'PAYMENT_INTENT_CREATED',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          stripePaymentIntentId: paymentIntent.id,
          amount: investment.totalAmountInCurrency.toString(),
          currency: investment.currency,
        },
        ipAddress,
        userAgent,
      });
    }

    logger.info('Stripe PaymentIntent created', {
      paymentIntentId: paymentIntent.id,
      paymentTransactionId: paymentTx.id,
      investmentId: investment.id,
      amount: investment.totalAmountInCurrency.toString(),
      currency: investment.currency,
    });

    return {
      clientSecret: paymentIntent.client_secret,
      paymentTransactionId: paymentTx.id,
      publishableKey: env.STRIPE_PUBLISHABLE_KEY,
      amount: investment.totalAmountInCurrency.toString(),
      currency: investment.currency,
      status: paymentIntent.status,
    };
  }

  /**
   * Handles incoming Stripe webhooks with cryptographic signature verification and database-level idempotency.
   */
  static async handleWebhookEvent(rawBody: Buffer | string, signature: string) {
    if (!signature) {
      throw AppError.badRequest('Missing Stripe-Signature header');
    }

    // 1. Verify Cryptographic Signature
    let event: Stripe.Event;
    try {
      event = stripeClient.webhooks.constructEvent(
        rawBody,
        signature,
        env.STRIPE_WEBHOOK_SECRET
      );
    } catch (err: any) {
      logger.error('Stripe webhook signature verification failed', {
        error: err.message,
      });
      throw AppError.badRequest(`Webhook signature verification failed: ${err.message}`);
    }

    logger.info('Stripe webhook event received', {
      eventId: event.id,
      eventType: event.type,
    });

    // 2. Database Deduplication / Idempotency Check
    const existingEvent = await prisma.stripePaymentEvent.findUnique({
      where: { eventId: event.id },
    });

    if (existingEvent) {
      logger.warn('Duplicate Stripe webhook event received (idempotent)', {
        eventId: event.id,
        eventType: event.type,
        status: existingEvent.status,
      });
      return { received: true, duplicate: true, eventId: event.id };
    }

    // 3. Process Events
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await this.settleSuccessfulPayment(paymentIntent, event.id);
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await this.handlePaymentFailure(paymentIntent, event.id);
        break;
      }

      case 'payment_intent.processing': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await this.handlePaymentProcessing(paymentIntent, event.id);
        break;
      }

      case 'payment_intent.canceled': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await this.handlePaymentCanceled(paymentIntent, event.id);
        break;
      }

      default: {
        // Record non-actionable events to maintain complete event log with minimal payload
        await prisma.stripePaymentEvent.create({
          data: {
            eventId: event.id,
            eventType: event.type,
            status: 'IGNORED',
          },
        });
        break;
      }
    }

    return { received: true, eventId: event.id, eventType: event.type };
  }

  /**
   * Authoritatively settles a successful card payment.
   * Atomically activates Investment, creates Option B batches/payouts, and posts balanced double-entry ledger records.
   */
  static async settleSuccessfulPayment(paymentIntent: Stripe.PaymentIntent, eventId: string) {
    // 1. Locate internal PaymentTransaction record
    const paymentTx = await prisma.paymentTransaction.findFirst({
      where: {
        OR: [
          { stripePaymentIntentId: paymentIntent.id },
          { id: paymentIntent.metadata?.paymentTransactionId },
        ],
      },
      include: {
        investment: true,
      },
    });

    if (!paymentTx || !paymentTx.investment) {
      logger.error('Received successful PaymentIntent with no matching internal transaction', {
        paymentIntentId: paymentIntent.id,
        metadata: paymentIntent.metadata,
      });
      await prisma.stripePaymentEvent.create({
        data: {
          eventId,
          eventType: 'payment_intent.succeeded',
          paymentIntentId: paymentIntent.id,
          status: 'UNMATCHED_TRANSACTION',
          errorMessage: 'No matching internal PaymentTransaction or Investment found',
        },
      });
      throw AppError.notFound(`Payment transaction for PaymentIntent ${paymentIntent.id} not found`);
    }

    const { investment } = paymentTx;

    // 2. Check if already settled
    if (
      paymentTx.status === TransactionStatus.SUCCESSFUL &&
      investment.status === InvestmentStatus.ACTIVE
    ) {
      logger.info('Payment already settled (idempotent)', {
        paymentTransactionId: paymentTx.id,
        investmentId: investment.id,
        eventId,
      });
      await prisma.stripePaymentEvent.create({
        data: {
          eventId,
          eventType: 'payment_intent.succeeded',
          paymentIntentId: paymentIntent.id,
          status: 'PROCESSED',
        },
      });
      return;
    }

    // 3. Strict Currency Validation
    const expectedCurrency = investment.currency;
    if (paymentIntent.currency.toUpperCase() !== expectedCurrency) {
      logger.error('CRITICAL: Payment currency mismatch detected in webhook settlement', {
        expected: expectedCurrency,
        received: paymentIntent.currency.toUpperCase(),
        paymentIntentId: paymentIntent.id,
        investmentId: investment.id,
      });

      await prisma.stripePaymentEvent.create({
        data: {
          eventId,
          eventType: 'payment_intent.succeeded',
          paymentIntentId: paymentIntent.id,
          status: 'CURRENCY_MISMATCH_REJECTED',
          errorMessage: `Currency mismatch: expected ${expectedCurrency}, received ${paymentIntent.currency.toUpperCase()}`,
        },
      });

      await AuditService.log({
        action: 'SETTLEMENT_REJECTED_CURRENCY_MISMATCH',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          expectedCurrency,
          receivedCurrency: paymentIntent.currency.toUpperCase(),
          paymentIntentId: paymentIntent.id,
        },
      });

      throw AppError.badRequest('Settlement rejected due to currency mismatch');
    }

    // 4. Strict Amount Validation
    const expectedStripeAmount = toStripeAmount(investment.totalAmountInCurrency, expectedCurrency);
    if (paymentIntent.amount !== expectedStripeAmount) {
      logger.error('CRITICAL: Payment amount mismatch detected in webhook settlement', {
        expectedStripeAmount,
        receivedAmount: paymentIntent.amount,
        paymentIntentId: paymentIntent.id,
        investmentId: investment.id,
      });

      await prisma.stripePaymentEvent.create({
        data: {
          eventId,
          eventType: 'payment_intent.succeeded',
          paymentIntentId: paymentIntent.id,
          status: 'AMOUNT_MISMATCH_REJECTED',
          errorMessage: `Amount mismatch: expected ${expectedStripeAmount}, received ${paymentIntent.amount}`,
        },
      });

      await AuditService.log({
        action: 'SETTLEMENT_REJECTED_AMOUNT_MISMATCH',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          expectedStripeAmount,
          receivedAmount: paymentIntent.amount,
          paymentIntentId: paymentIntent.id,
        },
      });

      throw AppError.badRequest('Settlement rejected due to amount mismatch');
    }

    // 5. Execute Atomic PostgreSQL Financial Settlement Transaction
    await prisma.$transaction(async (tx) => {
      // 5a. Update PaymentTransaction
      await tx.paymentTransaction.update({
        where: { id: paymentTx.id },
        data: {
          status: TransactionStatus.SUCCESSFUL,
          paidAt: new Date(),
          stripePaymentStatus: 'succeeded',
          stripeLatestEventId: eventId,
        },
      });

      // 5b. Update Investment to ACTIVE
      await tx.investment.update({
        where: { id: investment.id },
        data: {
          status: InvestmentStatus.ACTIVE,
        },
      });

      // 5c. Ensure Ledger Accounts
      const escrowAccountId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_ESCROW);

      if (investment.resalePlan === ResalePlan.SELLFOR) {
        // Option B: Post capital into Locked Capital account
        const lockedCapitalAccountId = await LedgerService.ensurePartnerAccount(
          investment.partnerProfileId,
          AccountType.LOCKED_CAPITAL
        );

        // Double-entry posting: DEBIT Escrow (Asset in EUR), CREDIT Locked Capital (EUR)
        await LedgerService.postTransaction(
          {
            referenceNumber: `LEDGER-FUND-${investment.id}`,
            description: `Stripe card funding for Option B investment ${investment.id}`,
            sourceEntity: 'Investment',
            sourceEntityId: investment.id,
            entries: [
              {
                accountId: escrowAccountId,
                entryType: EntryType.DEBIT,
                amount: investment.totalAmountInCurrency,
                currency: investment.currency,
                amountEUR: investment.totalAmountEUR,
              },
              {
                accountId: lockedCapitalAccountId,
                entryType: EntryType.CREDIT,
                amount: investment.totalAmountEUR,
                currency: Currency.EUR,
                amountEUR: investment.totalAmountEUR,
              },
            ],
          },
          tx
        );

        // Create InvestmentBatch and 12 scheduled payouts
        const today = new Date();
        const firstPayout = new Date(today);
        firstPayout.setDate(firstPayout.getDate() + 30);

        const unlockDate = new Date(today);
        unlockDate.setFullYear(unlockDate.getFullYear() + 1);

        const batch = await tx.investmentBatch.create({
          data: {
            investmentId: investment.id,
            partnerProfileId: investment.partnerProfileId,
            capitalEUR: investment.totalAmountEUR,
            monthlyReturnRate: new Prisma.Decimal('0.0700'),
            discountMultiplier: new Prisma.Decimal('0.86'),
            lockDurationMonths: 12,
            startDate: today,
            firstPayoutDate: firstPayout,
            capitalUnlockDate: unlockDate,
            status: BatchStatus.ACTIVE,
          },
        });

        // 12 monthly payouts of 7%
        const monthlyAmountEUR = investment.totalAmountEUR
          .mul(new Prisma.Decimal('0.0700'))
          .toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

        const payoutsData = [];
        for (let i = 1; i <= 12; i++) {
          const dueDate = new Date(today);
          dueDate.setDate(dueDate.getDate() + 30 * i);

          payoutsData.push({
            batchId: batch.id,
            partnerProfileId: investment.partnerProfileId,
            payoutIndex: i,
            dueDate,
            amountEUR: monthlyAmountEUR,
            status: PayoutStatus.SCHEDULED,
          });
        }

        await tx.payout.createMany({
          data: payoutsData,
        });
      } else {
        // Option A: Direct wholesale retail purchase -> Platform Revenue
        const revenueAccountId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_REVENUE);

        await LedgerService.postTransaction(
          {
            referenceNumber: `LEDGER-REVENUE-${investment.id}`,
            description: `Stripe card wholesale purchase revenue for Option A investment ${investment.id}`,
            sourceEntity: 'Investment',
            sourceEntityId: investment.id,
            entries: [
              {
                accountId: escrowAccountId,
                entryType: EntryType.DEBIT,
                amount: investment.totalAmountInCurrency,
                currency: investment.currency,
                amountEUR: investment.totalAmountEUR,
              },
              {
                accountId: revenueAccountId,
                entryType: EntryType.CREDIT,
                amount: investment.totalAmountEUR,
                currency: Currency.EUR,
                amountEUR: investment.totalAmountEUR,
              },
            ],
          },
          tx
        );
      }

      // 5d. Record Event Deduplication Record
      await tx.stripePaymentEvent.create({
        data: {
          eventId,
          eventType: 'payment_intent.succeeded',
          paymentIntentId: paymentIntent.id,
          status: 'PROCESSED',
        },
      });

      // 5e. Audit Logs
      await AuditService.log({
        action: 'PAYMENT_SETTLED_STRIPE',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          stripePaymentIntentId: paymentIntent.id,
          status: 'SUCCESSFUL',
          amount: investment.totalAmountInCurrency.toString(),
          currency: investment.currency,
        },
      });

      await AuditService.log({
        action: 'INVESTMENT_ACTIVATED',
        entityType: 'Investment',
        entityId: investment.id,
        newState: {
          status: 'ACTIVE',
          resalePlan: investment.resalePlan,
          totalAmountEUR: investment.totalAmountEUR.toString(),
        },
      });
    });

    logger.info('Stripe payment settled and investment activated successfully', {
      paymentTransactionId: paymentTx.id,
      investmentId: investment.id,
      eventId,
      amountEUR: investment.totalAmountEUR.toString(),
    });
  }

  /**
   * Handles payment failure from Stripe webhook.
   */
  static async handlePaymentFailure(paymentIntent: Stripe.PaymentIntent, eventId: string) {
    const paymentTx = await prisma.paymentTransaction.findFirst({
      where: {
        OR: [
          { stripePaymentIntentId: paymentIntent.id },
          { id: paymentIntent.metadata?.paymentTransactionId },
        ],
      },
    });

    if (paymentTx) {
      await prisma.paymentTransaction.update({
        where: { id: paymentTx.id },
        data: {
          status: TransactionStatus.FAILED,
          stripePaymentStatus: 'failed',
          stripeLatestEventId: eventId,
          failureCode: paymentIntent.last_payment_error?.code || 'payment_failed',
          failureMessage: paymentIntent.last_payment_error?.message || 'Payment could not be completed',
        },
      });

      await AuditService.log({
        action: 'PAYMENT_FAILED_STRIPE',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          stripePaymentIntentId: paymentIntent.id,
          failureCode: paymentIntent.last_payment_error?.code,
          failureMessage: paymentIntent.last_payment_error?.message,
        },
      });
    }

    await prisma.stripePaymentEvent.create({
      data: {
        eventId,
        eventType: 'payment_intent.payment_failed',
        paymentIntentId: paymentIntent.id,
        status: 'FAILED',
        errorMessage: paymentIntent.last_payment_error?.message,
      },
    });
  }

  /**
   * Handles processing state from Stripe webhook.
   */
  static async handlePaymentProcessing(paymentIntent: Stripe.PaymentIntent, eventId: string) {
    const paymentTx = await prisma.paymentTransaction.findFirst({
      where: {
        OR: [
          { stripePaymentIntentId: paymentIntent.id },
          { id: paymentIntent.metadata?.paymentTransactionId },
        ],
      },
    });

    if (paymentTx) {
      await prisma.paymentTransaction.update({
        where: { id: paymentTx.id },
        data: {
          stripePaymentStatus: 'processing',
          stripeLatestEventId: eventId,
        },
      });
    }

    await prisma.stripePaymentEvent.create({
      data: {
        eventId,
        eventType: 'payment_intent.processing',
        paymentIntentId: paymentIntent.id,
        status: 'PROCESSING',
      },
    });
  }

  /**
   * Handles canceled state from Stripe webhook.
   */
  static async handlePaymentCanceled(paymentIntent: Stripe.PaymentIntent, eventId: string) {
    const paymentTx = await prisma.paymentTransaction.findFirst({
      where: {
        OR: [
          { stripePaymentIntentId: paymentIntent.id },
          { id: paymentIntent.metadata?.paymentTransactionId },
        ],
      },
    });

    if (paymentTx) {
      await prisma.paymentTransaction.update({
        where: { id: paymentTx.id },
        data: {
          status: TransactionStatus.CANCELLED,
          stripePaymentStatus: 'canceled',
          stripeLatestEventId: eventId,
        },
      });

      await AuditService.log({
        action: 'PAYMENT_CANCELLED_STRIPE',
        entityType: 'PaymentTransaction',
        entityId: paymentTx.id,
        newState: {
          stripePaymentIntentId: paymentIntent.id,
        },
      });
    }

    await prisma.stripePaymentEvent.create({
      data: {
        eventId,
        eventType: 'payment_intent.canceled',
        paymentIntentId: paymentIntent.id,
        status: 'CANCELED',
      },
    });
  }

  /**
   * Retrieves payment status with strict ownership and IDOR protection.
   */
  static async getPaymentStatus(paymentTransactionId: string, partnerProfileId: string, isAdmin = false) {
    const paymentTx = await prisma.paymentTransaction.findUnique({
      where: { id: paymentTransactionId },
      include: {
        investment: {
          select: {
            id: true,
            status: true,
            resalePlan: true,
            totalAmountEUR: true,
          },
        },
      },
    });

    if (!paymentTx) {
      throw AppError.notFound(`Payment transaction ${paymentTransactionId} not found`);
    }

    if (!isAdmin && paymentTx.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to access this payment transaction');
    }

    // Enterprise Webhook Fallback: If still pending locally, check Stripe API directly
    if (paymentTx.status === TransactionStatus.PENDING && paymentTx.stripePaymentIntentId) {
      try {
        const stripeIntent = await stripeClient.paymentIntents.retrieve(paymentTx.stripePaymentIntentId);
        if (stripeIntent.status === 'succeeded') {
          await this.settleSuccessfulPayment(stripeIntent, `sync_poll_${stripeIntent.id}`);
          
          const updatedTx = await prisma.paymentTransaction.findUnique({
            where: { id: paymentTransactionId },
            include: {
              investment: {
                select: {
                  id: true,
                  status: true,
                  resalePlan: true,
                  totalAmountEUR: true,
                },
              },
            },
          });

          if (updatedTx) {
            return {
              id: updatedTx.id,
              referenceNumber: updatedTx.referenceNumber,
              status: updatedTx.status,
              stripePaymentStatus: updatedTx.stripePaymentStatus,
              amount: updatedTx.amount.toString(),
              currency: updatedTx.currency,
              canonicalAmountEUR: updatedTx.canonicalAmountEUR.toString(),
              paidAt: updatedTx.paidAt,
              failureCode: updatedTx.failureCode,
              failureMessage: updatedTx.failureMessage,
              investment: updatedTx.investment,
              createdAt: updatedTx.createdAt,
            };
          }
        }
      } catch (err: any) {
        logger.warn('Synchronous Stripe payment intent verification fallback failed', {
          error: err.message,
          paymentTransactionId,
        });
      }
    }

    return {
      id: paymentTx.id,
      referenceNumber: paymentTx.referenceNumber,
      status: paymentTx.status,
      stripePaymentStatus: paymentTx.stripePaymentStatus,
      amount: paymentTx.amount.toString(),
      currency: paymentTx.currency,
      canonicalAmountEUR: paymentTx.canonicalAmountEUR.toString(),
      paidAt: paymentTx.paidAt,
      failureCode: paymentTx.failureCode,
      failureMessage: paymentTx.failureMessage,
      investment: paymentTx.investment,
      createdAt: paymentTx.createdAt,
    };
  }
}
