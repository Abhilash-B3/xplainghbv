import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { AuditService } from './audit.service.js';
import type { Currency, PaymentMethod, ResalePlan } from '@prisma/client';

export interface UpdateProfileInput {
  fullName?: string;
  preferredCurrency?: Currency;
  defaultPaymentMethod?: PaymentMethod;
  resalePlan?: ResalePlan;
  address?: {
    fullName: string;
    line1: string;
    line2?: string;
    city: string;
    postcode: string;
    country: string;
    phone?: string;
    isDefault?: boolean;
  };
}

export class UserService {
  /**
   * Retrieves full profile information for the authenticated user from PostgreSQL.
   */
  static async getProfile(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        partnerProfile: {
          include: {
            addresses: {
              orderBy: { isDefault: 'desc' },
            },
          },
        },
      },
    });

    if (!user) {
      throw AppError.notFound('User not found');
    }

    return {
      id: user.id,
      email: user.email,
      phone: user.phone,
      role: user.role,
      status: user.status,
      isEmailVerified: user.isEmailVerified,
      isPhoneVerified: user.isPhoneVerified,
      twoFactorEnabled: user.twoFactorEnabled,
      createdAt: user.createdAt,
      partnerProfile: user.partnerProfile
        ? {
            id: user.partnerProfile.id,
            fullName: user.partnerProfile.fullName,
            preferredCurrency: user.partnerProfile.preferredCurrency,
            defaultPaymentMethod: user.partnerProfile.defaultPaymentMethod,
            resalePlan: user.partnerProfile.resalePlan,
            referralCode: user.partnerProfile.referralCode,
            kycStatus: user.partnerProfile.kycStatus,
            addresses: user.partnerProfile.addresses,
          }
        : null,
    };
  }

  /**
   * Updates whitelisted profile information in PostgreSQL.
   */
  static async updateProfile(userId: string, input: UpdateProfileInput) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { partnerProfile: true },
    });

    if (!user || !user.partnerProfile) {
      throw AppError.notFound('Partner profile not found');
    }

    const previousProfileState = {
      fullName: user.partnerProfile.fullName,
      preferredCurrency: user.partnerProfile.preferredCurrency,
      defaultPaymentMethod: user.partnerProfile.defaultPaymentMethod,
      resalePlan: user.partnerProfile.resalePlan,
    };

    return await prisma.$transaction(async (tx) => {
      // 1. Update partner profile fields
      const updatedProfile = await tx.partnerProfile.update({
        where: { id: user.partnerProfile!.id },
        data: {
          fullName: input.fullName !== undefined ? input.fullName.trim() : undefined,
          preferredCurrency: input.preferredCurrency,
          defaultPaymentMethod: input.defaultPaymentMethod,
          resalePlan: input.resalePlan,
        },
      });

      // 2. Handle address update/creation if provided
      if (input.address) {
        const addr = input.address;
        if (addr.isDefault) {
          // Set all existing addresses to non-default
          await tx.address.updateMany({
            where: { partnerProfileId: updatedProfile.id },
            data: { isDefault: false },
          });
        }

        await tx.address.create({
          data: {
            partnerProfileId: updatedProfile.id,
            fullName: addr.fullName.trim(),
            line1: addr.line1.trim(),
            line2: addr.line2 ? addr.line2.trim() : null,
            city: addr.city.trim(),
            postcode: addr.postcode.trim(),
            country: addr.country.trim(),
            phone: addr.phone ? addr.phone.trim() : null,
            isDefault: addr.isDefault ?? true,
          },
        });
      }

      // 3. Write audit log
      await AuditService.log(
        {
          userId: user.id,
          action: 'PROFILE_UPDATED',
          entityType: 'PartnerProfile',
          entityId: updatedProfile.id,
          previousState: previousProfileState,
          newState: {
            fullName: updatedProfile.fullName,
            preferredCurrency: updatedProfile.preferredCurrency,
            defaultPaymentMethod: updatedProfile.defaultPaymentMethod,
            resalePlan: updatedProfile.resalePlan,
          },
        },
        tx
      );

      return {
        id: user.id,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        partnerProfile: {
          id: updatedProfile.id,
          fullName: updatedProfile.fullName,
          preferredCurrency: updatedProfile.preferredCurrency,
          defaultPaymentMethod: updatedProfile.defaultPaymentMethod,
          resalePlan: updatedProfile.resalePlan,
          referralCode: updatedProfile.referralCode,
          kycStatus: updatedProfile.kycStatus,
        },
      };
    });
  }
}
