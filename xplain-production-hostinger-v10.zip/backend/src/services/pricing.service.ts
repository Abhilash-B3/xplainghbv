import { Prisma, ResalePlan, Currency } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import {
  OPTION_B_DISCOUNT_MULTIPLIER,
  OPTION_B_MONTHLY_RETURN_RATE,
  OPTION_B_LOCK_DURATION_MONTHS,
  resolveExchangeRate,
  convertCurrency,
  validateMinimumInvestment,
} from '../utils/currency.js';

export interface QuoteItemInput {
  productId: string;
  quantity: number;
}

export interface CalculatedQuoteItem {
  productId: string;
  productRef: string;
  productName: string;
  unitPriceEUR: Prisma.Decimal;
  discountMultiplier: Prisma.Decimal;
  quantity: number;
  lineTotalEUR: Prisma.Decimal;
}

export interface InvestmentQuote {
  quoteId?: string;
  resalePlan: ResalePlan;
  currency: Currency;
  exchangeRateToEUR: Prisma.Decimal; // 1 EUR in target currency, or 1 target currency in EUR
  exchangeRateSnapshotId: string | null;
  rateSource: string;
  discountMultiplier: Prisma.Decimal;
  subtotalEUR: Prisma.Decimal;
  discountAmountEUR: Prisma.Decimal;
  totalAmountEUR: Prisma.Decimal;
  subtotalInCurrency: Prisma.Decimal;
  discountAmountInCurrency: Prisma.Decimal;
  totalAmountInCurrency: Prisma.Decimal;
  monthlyReturnRate: Prisma.Decimal;
  estimatedMonthlyReturnEUR: Prisma.Decimal;
  estimatedMonthlyReturnInCurrency: Prisma.Decimal;
  lockDurationMonths: number;
  items: CalculatedQuoteItem[];
  expiresAt: Date;
}

export class PricingService {
  /**
   * Generates an authoritative server-side quote for an investment selection.
   */
  static async calculateQuote(params: {
    items: QuoteItemInput[];
    resalePlan: ResalePlan;
    currency: Currency;
  }): Promise<InvestmentQuote> {
    const { items: rawItems, resalePlan, currency } = params;

    if (!rawItems || rawItems.length === 0) {
      throw AppError.badRequest('Quote calculation requires at least one product item');
    }

    // 1. Fetch product records from PostgreSQL
    const productIds = rawItems.map((i) => i.productId);
    const products = await prisma.product.findMany({
      where: {
        id: { in: productIds },
        isActive: true,
      },
    });

    if (products.length !== productIds.length) {
      throw AppError.badRequest('One or more selected products are invalid or inactive');
    }

    const productMap = new Map(products.map((p) => [p.id, p]));

    // 2. Determine plan rules
    const isOptionB = resalePlan === ResalePlan.SELLFOR;
    const discountMultiplier = isOptionB ? OPTION_B_DISCOUNT_MULTIPLIER : new Prisma.Decimal('1.00');
    const monthlyReturnRate = isOptionB ? OPTION_B_MONTHLY_RETURN_RATE : new Prisma.Decimal('0.0000');
    const lockDurationMonths = isOptionB ? OPTION_B_LOCK_DURATION_MONTHS : 0;

    // 3. Calculate line totals and subtotal in canonical EUR
    let subtotalEUR = new Prisma.Decimal('0.00');
    let totalAmountEUR = new Prisma.Decimal('0.00');
    const calculatedItems: CalculatedQuoteItem[] = [];

    for (const item of rawItems) {
      if (item.quantity <= 0 || !Number.isInteger(item.quantity)) {
        throw AppError.badRequest(`Invalid quantity for product ${item.productId}: must be a positive integer`);
      }

      const product = productMap.get(item.productId)!;

      if (product.stockQuantity < item.quantity) {
        throw AppError.conflict(
          `Insufficient stock for "${product.name}". Requested: ${item.quantity}, Available: ${product.stockQuantity}`
        );
      }

      const unitPrice = new Prisma.Decimal(product.priceEUR.toString());
      const rawLineTotal = unitPrice.mul(item.quantity);
      const discountedLineTotal = rawLineTotal.mul(discountMultiplier).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

      subtotalEUR = subtotalEUR.plus(rawLineTotal);
      totalAmountEUR = totalAmountEUR.plus(discountedLineTotal);

      calculatedItems.push({
        productId: product.id,
        productRef: product.ref,
        productName: product.name,
        unitPriceEUR: unitPrice,
        discountMultiplier,
        quantity: item.quantity,
        lineTotalEUR: discountedLineTotal,
      });
    }

    const discountAmountEUR = subtotalEUR.minus(totalAmountEUR).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

    // 4. Resolve exchange rate snapshot from EUR to target currency
    const rateSnapshot = await resolveExchangeRate(Currency.EUR, currency);
    const eurToTargetRate = rateSnapshot.rate;

    const subtotalInCurrency = convertCurrency(subtotalEUR, eurToTargetRate);
    const discountAmountInCurrency = convertCurrency(discountAmountEUR, eurToTargetRate);
    const totalAmountInCurrency = convertCurrency(totalAmountEUR, eurToTargetRate);

    // 5. Enforce minimum investment rule (€1.00 equivalent)
    const minCheck = await validateMinimumInvestment(totalAmountInCurrency, currency);
    if (!minCheck.meetsMinimum) {
      throw AppError.unprocessable(
        `Total investment of ${totalAmountInCurrency.toString()} ${currency} is below the minimum required threshold of ${minCheck.minimumInCurrency.toString()} ${currency} (equivalent to €${minCheck.minEUR.toString()})`
      );
    }

    // 6. Calculate estimated monthly return
    const estimatedMonthlyReturnEUR = isOptionB
      ? totalAmountEUR.mul(monthlyReturnRate).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP)
      : new Prisma.Decimal('0.00');

    const estimatedMonthlyReturnInCurrency = isOptionB
      ? convertCurrency(estimatedMonthlyReturnEUR, eurToTargetRate)
      : new Prisma.Decimal('0.00');

    // 7. Expiration (15 minutes from creation)
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

    return {
      resalePlan,
      currency,
      exchangeRateToEUR: eurToTargetRate,
      exchangeRateSnapshotId: rateSnapshot.snapshotId,
      rateSource: rateSnapshot.source,
      discountMultiplier,
      subtotalEUR,
      discountAmountEUR,
      totalAmountEUR,
      subtotalInCurrency,
      discountAmountInCurrency,
      totalAmountInCurrency,
      monthlyReturnRate,
      estimatedMonthlyReturnEUR,
      estimatedMonthlyReturnInCurrency,
      lockDurationMonths,
      items: calculatedItems,
      expiresAt,
    };
  }
}
