import { Prisma, PayoutStatus, AccountType, EntryType, Currency } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { LedgerService } from './ledger.service.js';
import { AuditService } from './audit.service.js';

export class PayoutService {
  /**
   * Processes a scheduled payout idempotently.
   * Transfers monthly returns from PLATFORM_ESCROW to partner AVAILABLE_RETURNS via double-entry ledger.
   */
  static async processPayout(payoutId: string, performedByUserId?: string) {
    return prisma.$transaction(async (tx) => {
      // 1. Fetch payout and lock row
      const payout = await tx.payout.findUnique({
        where: { id: payoutId },
        include: {
          batch: true,
          partnerProfile: true,
        },
      });

      if (!payout) {
        throw AppError.notFound(`Payout ${payoutId} not found`);
      }

      if (payout.status === PayoutStatus.PAID) {
        logger.info('Payout is already paid (idempotent)', { payoutId, paidAt: payout.paidAt });
        return payout;
      }

      if (payout.status !== PayoutStatus.SCHEDULED && payout.status !== PayoutStatus.PROCESSING) {
        throw AppError.badRequest(`Payout cannot be processed from status ${payout.status}`);
      }

      // 2. Ensure accounts exist
      const escrowAccountId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_ESCROW);
      const availableReturnsAccountId = await LedgerService.ensurePartnerAccount(
        payout.partnerProfileId,
        AccountType.AVAILABLE_RETURNS
      );

      // 3. Verify funding backing in PLATFORM_ESCROW
      const escrowBalance = await LedgerService.getAccountBalance(escrowAccountId, tx);
      const payoutAmountEUR = new Prisma.Decimal(payout.amountEUR.toString());

      if (escrowBalance.lessThan(payoutAmountEUR)) {
        logger.error('Insufficient funds in PLATFORM_ESCROW for payout', {
          payoutId,
          requiredEUR: payoutAmountEUR.toString(),
          availableEUR: escrowBalance.toString(),
        });
        throw AppError.badRequest(
          `Insufficient funding in PLATFORM_ESCROW to disburse payout of ${payoutAmountEUR.toString()} EUR. Available balance: ${escrowBalance.toString()} EUR`
        );
      }

      // 4. Post double-entry ledger transaction: DEBIT Escrow, CREDIT Partner Available Returns
      const txRef = `PAYOUT-${payout.batchId}-${payout.payoutIndex}`;
      await LedgerService.postTransaction(
        {
          referenceNumber: txRef,
          description: `Monthly return payout #${payout.payoutIndex} for batch ${payout.batchId}`,
          sourceEntity: 'Payout',
          sourceEntityId: payout.id,
          entries: [
            {
              accountId: escrowAccountId,
              entryType: EntryType.DEBIT,
              amount: payoutAmountEUR,
              currency: Currency.EUR,
              amountEUR: payoutAmountEUR,
            },
            {
              accountId: availableReturnsAccountId,
              entryType: EntryType.CREDIT,
              amount: payoutAmountEUR,
              currency: Currency.EUR,
              amountEUR: payoutAmountEUR,
            },
          ],
        },
        tx
      );

      // 5. Update payout status
      const updatedPayout = await tx.payout.update({
        where: { id: payoutId },
        data: {
          status: PayoutStatus.PAID,
          paidAt: new Date(),
        },
      });

      // 6. Audit
      if (performedByUserId) {
        await AuditService.log({
          userId: performedByUserId,
          action: 'PAYOUT_PROCESSED',
          entityType: 'Payout',
          entityId: payout.id,
          newState: {
            payoutId: payout.id,
            amountEUR: payoutAmountEUR.toString(),
            partnerProfileId: payout.partnerProfileId,
          },
        });
      }

      logger.info('Payout processed successfully', {
        payoutId: payout.id,
        batchId: payout.batchId,
        payoutIndex: payout.payoutIndex,
        amountEUR: payoutAmountEUR.toString(),
      });

      return updatedPayout;
    });
  }

  /**
   * Identifies and returns all payouts due up to the specified date.
   */
  static async getDuePayouts(asOfDate: Date = new Date()) {
    return prisma.payout.findMany({
      where: {
        status: PayoutStatus.SCHEDULED,
        dueDate: { lte: asOfDate },
      },
      include: {
        batch: true,
        partnerProfile: true,
      },
      orderBy: { dueDate: 'asc' },
    });
  }
}
