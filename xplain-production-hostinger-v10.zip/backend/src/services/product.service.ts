import { Prisma } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';


export interface ProductQueryOptions {
  categorySlug?: string;
  search?: string;
  page?: number;
  limit?: number;
  sort?: 'price_asc' | 'price_desc' | 'name_asc' | 'newest';
  includeInactive?: boolean;
}

export interface CreateProductInput {
  categoryId: string;
  ref: string;
  name: string;
  description?: string;
  priceEUR: number | string;
  imageUrl: string;
  stockQuantity?: number;
}

export interface UpdateProductInput {
  categoryId?: string;
  name?: string;
  description?: string;
  priceEUR?: number | string;
  imageUrl?: string;
  stockQuantity?: number;
  isActive?: boolean;
}

export class ProductService {
  /**
   * Retrieves products with server-side filtering, search, pagination, and sorting.
   */
  static async getProducts(options: ProductQueryOptions = {}) {
    const page = Math.max(1, options.page || 1);
    const limit = Math.min(100, Math.max(1, options.limit || 50));
    const skip = (page - 1) * limit;

    const where: Prisma.ProductWhereInput = {};

    // Inactive filter
    if (!options.includeInactive) {
      where.isActive = true;
    }

    // Category filter
    if (options.categorySlug && options.categorySlug !== 'all') {
      where.category = {
        slug: options.categorySlug.toLowerCase(),
      };
    }

    // Server-side parameterized search
    if (options.search && options.search.trim().length > 0) {
      const q = options.search.trim();
      where.OR = [
        { name: { contains: q, mode: 'insensitive' } },
        { ref: { contains: q, mode: 'insensitive' } },
        { description: { contains: q, mode: 'insensitive' } },
        { category: { name: { contains: q, mode: 'insensitive' } } },
      ];
    }

    // Sorting
    let orderBy: Prisma.ProductOrderByWithRelationInput = { createdAt: 'desc' };
    if (options.sort === 'price_asc') {
      orderBy = { priceEUR: 'asc' };
    } else if (options.sort === 'price_desc') {
      orderBy = { priceEUR: 'desc' };
    } else if (options.sort === 'name_asc') {
      orderBy = { name: 'asc' };
    }

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        include: {
          category: {
            select: { id: true, name: true, slug: true },
          },
        },
        orderBy,
        skip,
        take: limit,
      }),
      prisma.product.count({ where }),
    ]);

    return {
      products,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
    };
  }

  /**
   * Retrieves a single product by UUID or SKU reference.
   */
  static async getProductByIdOrRef(idOrRef: string) {
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idOrRef);

    const product = await prisma.product.findFirst({
      where: isUuid
        ? { id: idOrRef }
        : { ref: { equals: idOrRef, mode: 'insensitive' } },
      include: {
        category: {
          select: { id: true, name: true, slug: true },
        },
      },
    });

    if (!product) {
      throw AppError.notFound(`Product "${idOrRef}" not found`);
    }

    return product;
  }

  /**
   * Retrieves all active product categories.
   */
  static async getCategories() {
    return prisma.productCategory.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
      select: {
        id: true,
        name: true,
        slug: true,
        displayOrder: true,
        _count: {
          select: { products: { where: { isActive: true } } },
        },
      },
    });
  }

  /**
   * Retrieves showcase appliances for the landing page.
   */
  static async getShowcaseAppliances() {
    return prisma.showcaseAppliance.findMany({
      where: { isActive: true },
      orderBy: { displayOrder: 'asc' },
    });
  }

  /**
   * Admin: Creates a new catalog product.
   */
  static async createProduct(input: CreateProductInput) {
    const existing = await prisma.product.findUnique({
      where: { ref: input.ref },
    });

    if (existing) {
      throw AppError.conflict(`Product reference "${input.ref}" already exists`);
    }

    const category = await prisma.productCategory.findUnique({
      where: { id: input.categoryId },
    });

    if (!category) {
      throw AppError.badRequest(`Category ID ${input.categoryId} does not exist`);
    }

    return prisma.product.create({
      data: {
        categoryId: input.categoryId,
        ref: input.ref,
        name: input.name,
        description: input.description,
        priceEUR: new Prisma.Decimal(input.priceEUR.toString()),
        imageUrl: input.imageUrl,
        stockQuantity: input.stockQuantity ?? 100,
        isActive: true,
      },
      include: { category: true },
    });
  }

  /**
   * Admin: Updates an existing product.
   */
  static async updateProduct(id: string, input: UpdateProductInput) {
    await this.getProductByIdOrRef(id);

    return prisma.product.update({
      where: { id },
      data: {
        categoryId: input.categoryId,
        name: input.name,
        description: input.description,
        priceEUR: input.priceEUR !== undefined ? new Prisma.Decimal(input.priceEUR.toString()) : undefined,
        imageUrl: input.imageUrl,
        stockQuantity: input.stockQuantity,
        isActive: input.isActive,
      },
      include: { category: true },
    });
  }

  /**
   * Admin: Soft-archives a product (sets isActive = false).
   */
  static async archiveProduct(id: string) {
    await this.getProductByIdOrRef(id);

    return prisma.product.update({
      where: { id },
      data: { isActive: false },
    });
  }
}
