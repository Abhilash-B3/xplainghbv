import tls from 'node:tls';
import crypto from 'node:crypto';
import { env } from '../config/env.js';
import { logger } from '../utils/logger.js';

export interface EmailSendResult {
  sent: boolean;
  messageId?: string;
  provider: string;
}

interface SmtpResponse {
  code: number;
  message: string;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function normalizeUrl(base: string): string {
  return base.replace(/\/$/, '');
}

function getEmailConfig(): { host: string; port: number; user: string; password: string; from: string } | null {
  const user = env.EMAIL_SMTP_USER?.trim();
  const password = env.EMAIL_SMTP_PASSWORD;

  if (!user || !password) {
    return null;
  }

  return {
    host: env.EMAIL_SMTP_HOST,
    port: env.EMAIL_SMTP_PORT,
    user,
    password,
    from: env.EMAIL_FROM?.trim() || user,
  };
}

class SmtpClient {
  private socket: tls.TLSSocket | null = null;
  private buffered = '';
  private pendingChunks: Array<(value: SmtpResponse) => void> = [];
  private pendingErrors: Array<(error: Error) => void> = [];
  private closed = false;

  constructor(private readonly host: string, private readonly port: number) {}

  async connect(): Promise<void> {
    this.socket = tls.connect({
      host: this.host,
      port: this.port,
      servername: this.host,
      minVersion: 'TLSv1.2',
    });

    this.socket.setEncoding('utf8');

    this.socket.on('data', (chunk: string) => {
      this.buffered += chunk;
      this.flushResponses();
    });

    this.socket.on('error', (error) => {
      this.rejectPending(error instanceof Error ? error : new Error(String(error)));
    });

    this.socket.on('close', () => {
      this.closed = true;
      this.rejectPending(new Error('SMTP connection closed unexpectedly'));
    });

    await new Promise<void>((resolve, reject) => {
      const onSecureConnect = () => {
        cleanup();
        resolve();
      };
      const onError = (error: Error) => {
        cleanup();
        reject(error);
      };
      const cleanup = () => {
        this.socket?.off('secureConnect', onSecureConnect);
        this.socket?.off('error', onError);
      };

      this.socket?.once('secureConnect', onSecureConnect);
      this.socket?.once('error', onError);
    });

    const greeting = await this.readResponse();
    if (greeting.code !== 220) {
      throw new Error(`SMTP greeting rejected with code ${greeting.code}`);
    }
  }

  async command(command: string): Promise<SmtpResponse> {
    if (!this.socket || this.closed) {
      throw new Error('SMTP connection is not available');
    }

    this.socket.write(`${command}\r\n`);
    return this.readResponse();
  }

  async sendData(data: string): Promise<SmtpResponse> {
    if (!this.socket || this.closed) {
      throw new Error('SMTP connection is not available');
    }

    this.socket.write(`${data}\r\n.\r\n`);
    return this.readResponse();
  }

  close(): void {
    if (!this.socket) return;
    try {
      this.socket.end();
    } catch {
      this.socket.destroy();
    }
    this.socket = null;
    this.closed = true;
  }

  private readResponse(): Promise<SmtpResponse> {
    return new Promise((resolve, reject) => {
      this.pendingChunks.push(resolve);
      this.pendingErrors.push(reject);
      this.flushResponses();
    });
  }

  private flushResponses(): void {
    while (this.pendingChunks.length > 0) {
      const lines = this.buffered.split('\r\n');
      if (lines.length < 2) return;

      let endIndex = -1;
      let code = 0;
      for (let i = 0; i < lines.length - 1; i += 1) {
        const match = /^(\d{3})([ -])(.*)$/.exec(lines[i] ?? '');
        if (!match) continue;
        code = Number(match[1]);
        if (match[2] === ' ') {
          endIndex = i;
          break;
        }
      }

      if (endIndex < 0) return;

      const message = lines.slice(0, endIndex + 1).map((line) => line.slice(4)).join('\n');
      this.buffered = lines.slice(endIndex + 1).join('\r\n');
      const resolve = this.pendingChunks.shift();
      this.pendingErrors.shift();
      resolve?.({ code, message });
    }
  }

  private rejectPending(error: Error): void {
    while (this.pendingErrors.length > 0) {
      const reject = this.pendingErrors.shift();
      this.pendingChunks.shift();
      reject?.(error);
    }
  }
}

function assertSmtpCode(response: SmtpResponse, expected: number | number[], operation: string): void {
  const allowed = Array.isArray(expected) ? expected : [expected];
  if (!allowed.includes(response.code)) {
    throw new Error(`${operation} failed with SMTP code ${response.code}`);
  }
}

async function sendSmtpEmail(params: {
  to: string;
  subject: string;
  text: string;
  html: string;
}): Promise<string> {
  const config = getEmailConfig();
  if (!config) {
    throw new Error('Production SMTP email configuration is incomplete');
  }

  const client = new SmtpClient(config.host, config.port);
  const messageId = `<${Date.now()}.${crypto.randomBytes(8).toString('hex')}@xplainghbv.com>`;

  const boundary = `xplain_${crypto.randomBytes(12).toString('hex')}`;
  const safeFrom = config.from.replace(/[\r\n]/g, '');
  const safeTo = params.to.replace(/[\r\n]/g, '');
  const safeSubject = params.subject.replace(/[\r\n]/g, '');
  const bodyText = params.text.replace(/\r?\n/g, '\r\n');
  const bodyHtml = params.html.replace(/\r?\n/g, '\r\n');

  const data = [
    `From: Xplain GH BV <${safeFrom}>`,
    `To: <${safeTo}>`,
    `Subject: ${safeSubject}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: ${messageId}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
    '',
    bodyText,
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
    '',
    bodyHtml,
    '',
    `--${boundary}--`,
  ].join('\r\n');

  try {
    await client.connect();

    let response = await client.command(`EHLO xplainghbv.com`);
    assertSmtpCode(response, 250, 'EHLO');

    response = await client.command('AUTH LOGIN');
    assertSmtpCode(response, 334, 'SMTP authentication');

    response = await client.command(Buffer.from(config.user, 'utf8').toString('base64'));
    assertSmtpCode(response, 334, 'SMTP username authentication');

    response = await client.command(Buffer.from(config.password, 'utf8').toString('base64'));
    assertSmtpCode(response, 235, 'SMTP password authentication');

    response = await client.command(`MAIL FROM:<${safeFrom}>`);
    assertSmtpCode(response, 250, 'MAIL FROM');

    response = await client.command(`RCPT TO:<${safeTo}>`);
    assertSmtpCode(response, [250, 251], 'RCPT TO');

    response = await client.command('DATA');
    assertSmtpCode(response, 354, 'DATA');

    const stuffedData = data
      .split('\r\n')
      .map((line) => (line.startsWith('.') ? `.${line}` : line))
      .join('\r\n');
    response = await client.sendData(stuffedData);
    assertSmtpCode(response, 250, 'Email delivery');

    await client.command('QUIT').catch(() => undefined);
    return messageId;
  } finally {
    client.close();
  }
}

async function dispatchEmail(params: {
  toEmail: string;
  subject: string;
  text: string;
  html: string;
  purpose: string;
}): Promise<EmailSendResult> {
  const config = getEmailConfig();

  if (!config) {
    logger.warn(`[EmailService] ${params.purpose} email is not configured; SMTP credentials are missing`);
    return {
      sent: false,
      provider: 'SMTP_NOT_CONFIGURED',
    };
  }

  try {
    const messageId = await sendSmtpEmail({
      to: params.toEmail,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });

    logger.info(`[EmailService] ${params.purpose} email sent`, {
      toEmail: params.toEmail,
      provider: 'Hostinger SMTP',
      messageId,
    });

    return {
      sent: true,
      messageId,
      provider: 'HOSTINGER_SMTP',
    };
  } catch (error) {
    logger.error(`[EmailService] Failed to send ${params.purpose} email`, error instanceof Error ? error : undefined);
    return {
      sent: false,
      provider: 'HOSTINGER_SMTP_ERROR',
    };
  }
}

export class EmailService {
  /** Sends an email verification link. */
  static async sendVerificationEmail(
    toEmail: string,
    rawToken: string,
    fullName: string
  ): Promise<EmailSendResult> {
    const verificationUrl = `${normalizeUrl(env.FRONTEND_URL)}/verify-email?token=${encodeURIComponent(rawToken)}`;
    const safeName = escapeHtml(fullName.trim() || 'there');

    return dispatchEmail({
      toEmail,
      subject: 'Verify your Xplain GH BV account',
      purpose: 'verification',
      text: `Hello ${fullName.trim() || 'there'},\n\nPlease verify your Xplain GH BV account by opening this link:\n${verificationUrl}\n\nThis verification link expires in 24 hours.\n\nXplain GH BV`,
      html: `<!doctype html><html><body style="margin:0;background:#f4f5f7;font-family:Arial,sans-serif;color:#182033"><div style="max-width:600px;margin:32px auto;background:#ffffff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden"><div style="padding:24px;background:#0b1220;color:#ffffff"><strong style="font-size:20px">Xplain GH BV</strong></div><div style="padding:32px"><h1 style="margin:0 0 16px;font-size:24px">Verify your email</h1><p>Hello ${safeName},</p><p>Thank you for registering with Xplain GH BV. Click the button below to verify your email address.</p><p style="margin:28px 0"><a href="${verificationUrl}" style="display:inline-block;padding:13px 22px;background:#d4af37;color:#111827;text-decoration:none;border-radius:8px;font-weight:700">Verify Email</a></p><p style="font-size:13px;color:#667085">This verification link expires in 24 hours.</p><p style="font-size:13px;color:#667085;word-break:break-all">If the button does not work, copy this URL:<br>${verificationUrl}</p></div></div></body></html>`,
    });
  }

  /** Sends a password reset link. */
  static async sendPasswordResetEmail(
    toEmail: string,
    rawToken: string,
    fullName: string
  ): Promise<EmailSendResult> {
    const resetUrl = `${normalizeUrl(env.FRONTEND_URL)}/reset-password?token=${encodeURIComponent(rawToken)}`;
    const safeName = escapeHtml(fullName.trim() || 'there');

    return dispatchEmail({
      toEmail,
      subject: 'Reset your Xplain GH BV password',
      purpose: 'password reset',
      text: `Hello ${fullName.trim() || 'there'},\n\nWe received a request to reset your Xplain GH BV password. Open this link to continue:\n${resetUrl}\n\nIf you did not request this, you can safely ignore this email.\n\nXplain GH BV`,
      html: `<!doctype html><html><body style="margin:0;background:#f4f5f7;font-family:Arial,sans-serif;color:#182033"><div style="max-width:600px;margin:32px auto;background:#ffffff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden"><div style="padding:24px;background:#0b1220;color:#ffffff"><strong style="font-size:20px">Xplain GH BV</strong></div><div style="padding:32px"><h1 style="margin:0 0 16px;font-size:24px">Reset your password</h1><p>Hello ${safeName},</p><p>We received a request to reset your Xplain GH BV password. Click the button below to continue.</p><p style="margin:28px 0"><a href="${resetUrl}" style="display:inline-block;padding:13px 22px;background:#d4af37;color:#111827;text-decoration:none;border-radius:8px;font-weight:700">Reset Password</a></p><p style="font-size:13px;color:#667085">If you did not request this, you can safely ignore this email.</p><p style="font-size:13px;color:#667085;word-break:break-all">If the button does not work, copy this URL:<br>${resetUrl}</p></div></div></body></html>`,
    });
  }
}
