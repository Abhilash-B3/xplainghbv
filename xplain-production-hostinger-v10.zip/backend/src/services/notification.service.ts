import { NotificationType } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';

export interface CreateNotificationInput {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  eventKey?: string; // e.g. "withdrawal-comp-12345" for idempotency
  metadata?: Record<string, any>;
}

export class NotificationService {
  /**
   * Creates an in-app notification idempotently using an optional eventKey.
   */
  static async createNotification(input: CreateNotificationInput) {
    const { userId, type, title, message, eventKey, metadata } = input;

    if (eventKey) {
      const existing = await prisma.notification.findUnique({
        where: { eventKey },
      });
      if (existing) {
        logger.info('Notification event already exists (idempotent)', { eventKey, notificationId: existing.id });
        return existing;
      }
    }

    try {
      const notification = await prisma.notification.create({
        data: {
          userId,
          type,
          title,
          message,
          eventKey: eventKey || null,
          metadata: metadata || undefined,
        },
      });

      logger.info('In-app notification created', {
        notificationId: notification.id,
        userId,
        type,
      });

      return notification;
    } catch (err: any) {
      if (err.code === 'P2002' && eventKey) {
        // Unique constraint race condition
        return prisma.notification.findUnique({ where: { eventKey } });
      }
      throw err;
    }
  }

  /**
   * Retrieves notifications for a user with pagination and optional unread filter.
   */
  static async getUserNotifications(userId: string, unreadOnly = false, limit = 20, offset = 0) {
    const where: any = { userId };
    if (unreadOnly) {
      where.readAt = null;
    }

    const [notifications, totalCount, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.notification.count({ where: { userId } }),
      prisma.notification.count({ where: { userId, readAt: null } }),
    ]);

    return {
      notifications,
      totalCount,
      unreadCount,
    };
  }

  /**
   * Gets unread count for navbar badge.
   */
  static async getUnreadCount(userId: string): Promise<number> {
    return prisma.notification.count({
      where: { userId, readAt: null },
    });
  }

  /**
   * Marks a specific notification as read with ownership check.
   */
  static async markAsRead(notificationId: string, userId: string) {
    const notification = await prisma.notification.findUnique({
      where: { id: notificationId },
    });

    if (!notification) {
      throw AppError.notFound(`Notification ${notificationId} not found`);
    }

    if (notification.userId !== userId) {
      throw AppError.forbidden('You do not have permission to modify this notification');
    }

    return prisma.notification.update({
      where: { id: notificationId },
      data: { readAt: new Date() },
    });
  }

  /**
   * Marks all unread notifications for a user as read.
   */
  static async markAllAsRead(userId: string) {
    const result = await prisma.notification.updateMany({
      where: {
        userId,
        readAt: null,
      },
      data: {
        readAt: new Date(),
      },
    });

    return { updatedCount: result.count };
  }

  /**
   * Retrieves user notification preferences.
   */
  static async getPreferences(userId: string) {
    let prefs = await prisma.notificationPreference.findUnique({
      where: { userId },
    });

    if (!prefs) {
      prefs = await prisma.notificationPreference.create({
        data: {
          userId,
          emailInvestments: true,
          emailPayouts: true,
          emailWithdrawals: true,
          emailReferrals: true,
          emailMarketing: false,
          inAppSecurity: true,
        },
      });
    }

    return prefs;
  }

  /**
   * Updates non-critical user notification preferences.
   */
  static async updatePreferences(
    userId: string,
    updates: Partial<{
      emailInvestments: boolean;
      emailPayouts: boolean;
      emailWithdrawals: boolean;
      emailReferrals: boolean;
      emailMarketing: boolean;
    }>
  ) {
    // Ensure existing record
    await this.getPreferences(userId);

    return prisma.notificationPreference.update({
      where: { userId },
      data: updates,
    });
  }
}
