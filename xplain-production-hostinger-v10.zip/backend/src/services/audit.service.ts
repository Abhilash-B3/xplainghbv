import type { Prisma } from '@prisma/client';
import { prisma } from '../config/database.js';
import type { PrismaTransactionClient } from '../utils/transaction.js';
import { logger } from '../utils/logger.js';

export interface CreateAuditLogParams {
  userId?: string | null;
  action: string;
  entityType: string;
  entityId: string;
  previousState?: Prisma.InputJsonValue | null;
  newState?: Prisma.InputJsonValue | null;
  ipAddress?: string | null;
  userAgent?: string | null;
}

export class AuditService {
  /**
   * Records a security, financial, or state-change event into PostgreSQL.
   */
  static async log(
    params: CreateAuditLogParams,
    tx?: PrismaTransactionClient
  ): Promise<void> {
    const client = tx ?? prisma;

    try {
      await client.auditLog.create({
        data: {
          userId: params.userId ?? null,
          action: params.action,
          entityType: params.entityType,
          entityId: params.entityId,
          previousState: params.previousState ?? undefined,
          newState: params.newState ?? undefined,
          ipAddress: params.ipAddress ?? null,
          userAgent: params.userAgent ?? null,
        },
      });
    } catch (error) {
      // Audit log failures should not crash the main transaction unless critical,
      // but must be logged to stderr.
      logger.error('Failed to create audit log entry', {
        error: error instanceof Error ? error.message : String(error),
        auditParams: {
          userId: params.userId,
          action: params.action,
          entityType: params.entityType,
          entityId: params.entityId,
        },
      });
    }
  }
}
