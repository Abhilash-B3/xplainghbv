import {
  Prisma,
  ReferralStatus,
  CommissionStatus,
  AccountType,
  EntryType,
  Currency,
  BatchStatus,
} from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { LedgerService } from './ledger.service.js';
import { AuditService } from './audit.service.js';
import { convertCurrency, resolveExchangeRate } from '../utils/currency.js';

export interface AttributeReferralInput {
  refereeProfileId: string;
  referralCode: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
}

export class ReferralService {
  /**
   * Attributes a new partner to a referrer using their unique referral code.
   * Enforces server-side validation and anti-self-referral checks.
   */
  static async attributeReferral(input: AttributeReferralInput) {
    const { refereeProfileId, referralCode, userId, ipAddress, userAgent } = input;

    if (!referralCode || referralCode.trim().length < 3) {
      throw AppError.badRequest('A valid referral code is required');
    }

    const cleanCode = referralCode.trim().toUpperCase();

    // 1. Locate referrer profile by referral code
    const referrer = await prisma.partnerProfile.findUnique({
      where: { referralCode: cleanCode },
    });

    if (!referrer) {
      throw AppError.notFound(`Referral code '${cleanCode}' is invalid or does not exist`);
    }

    // 2. Anti-Self-Referral Check
    if (referrer.id === refereeProfileId) {
      throw AppError.badRequest('You cannot use your own referral code (self-referral prohibited)');
    }

    // 3. Check if referee already has an existing referral attribution
    const existing = await prisma.referral.findUnique({
      where: { refereeProfileId },
    });

    if (existing) {
      logger.info('Referee already has an assigned referrer (idempotent)', {
        refereeProfileId,
        referrerProfileId: existing.referrerProfileId,
      });
      return existing;
    }

    // 4. Create Referral Relationship
    const referral = await prisma.referral.create({
      data: {
        referrerProfileId: referrer.id,
        refereeProfileId,
        status: ReferralStatus.REGISTERED,
        attributionDate: new Date(),
      },
      include: {
        referrer: {
          select: { fullName: true, referralCode: true },
        },
      },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'REFERRAL_ATTRIBUTED',
        entityType: 'Referral',
        entityId: referral.id,
        newState: {
          referrerProfileId: referrer.id,
          refereeProfileId,
          referralCode: cleanCode,
        },
        ipAddress,
        userAgent,
      });
    }

    logger.info('Referral attributed successfully', {
      referralId: referral.id,
      referrerProfileId: referrer.id,
      refereeProfileId,
      referralCode: cleanCode,
    });

    return referral;
  }

  /**
   * Activates referral status when referee successfully funds and activates an investment.
   */
  static async onRefereeInvestmentActivated(refereeProfileId: string) {
    const referral = await prisma.referral.findUnique({
      where: { refereeProfileId },
    });

    if (referral && referral.status === ReferralStatus.REGISTERED) {
      await prisma.referral.update({
        where: { id: referral.id },
        data: { status: ReferralStatus.ACTIVE },
      });

      logger.info('Referral transitioned to ACTIVE status', {
        referralId: referral.id,
        refereeProfileId,
      });
    }
  }

  /**
   * Calculates and posts monthly referral commissions for a specific period (format: "YYYY-MM").
   * Business Rule: 3% per month on active Option B capital in canonical EUR.
   * Double-Entry Posting: DEBIT PLATFORM_REVENUE (Marketing Expense) -> CREDIT AVAILABLE_RETURNS (Referrer).
   */
  static async calculateMonthlyCommissions(periodMonth: string) {
    // 1. Validate period format (e.g. "2026-09")
    if (!/^\d{4}-(?:0[1-9]|1[0-2])$/.test(periodMonth)) {
      throw AppError.badRequest(`Invalid period format: ${periodMonth}. Must be YYYY-MM.`);
    }

    logger.info(`Starting monthly referral commission calculation for ${periodMonth}`);

    // 2. Locate all active referrals
    const activeReferrals = await prisma.referral.findMany({
      where: {
        status: ReferralStatus.ACTIVE,
      },
      include: {
        referrer: true,
        referee: {
          include: {
            investmentBatches: {
              where: {
                status: BatchStatus.ACTIVE,
              },
            },
          },
        },
      },
    });

    const results: Array<{
      referralId: string;
      referrerProfileId: string;
      refereeProfileId: string;
      capitalEUR: string;
      commissionEUR: string;
      skipped?: boolean;
    }> = [];

    const COMMISSION_RATE = new Prisma.Decimal('0.0300'); // 3%

    for (const ref of activeReferrals) {
      // Calculate total qualifying active Option B capital in canonical EUR
      let totalQualifyingCapitalEUR = new Prisma.Decimal('0.00');

      for (const batch of ref.referee.investmentBatches) {
        totalQualifyingCapitalEUR = totalQualifyingCapitalEUR.plus(batch.capitalEUR);
      }

      if (totalQualifyingCapitalEUR.lessThanOrEqualTo(0)) {
        continue;
      }

      // Check if commission already calculated for this referral in this period
      const existingCommission = await prisma.referralCommission.findUnique({
        where: {
          referralId_periodMonth: {
            referralId: ref.id,
            periodMonth,
          },
        },
      });

      if (existingCommission) {
        logger.info(`Commission for referral ${ref.id} in period ${periodMonth} already processed (idempotent)`);
        results.push({
          referralId: ref.id,
          referrerProfileId: ref.referrerProfileId,
          refereeProfileId: ref.refereeProfileId,
          capitalEUR: totalQualifyingCapitalEUR.toFixed(2),
          commissionEUR: existingCommission.commissionAmountEUR.toFixed(2),
          skipped: true,
        });
        continue;
      }

      const commissionAmountEUR = totalQualifyingCapitalEUR
        .mul(COMMISSION_RATE)
        .toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

      if (commissionAmountEUR.lessThanOrEqualTo(0)) {
        continue;
      }

      // Atomic Execution per referral commission
      await prisma.$transaction(async (tx) => {
        // 1. Create ReferralCommission Record
        const commission = await tx.referralCommission.create({
          data: {
            referralId: ref.id,
            referrerProfileId: ref.referrerProfileId,
            refereeProfileId: ref.refereeProfileId,
            periodMonth,
            refereeCapitalEUR: totalQualifyingCapitalEUR,
            commissionRate: COMMISSION_RATE,
            commissionAmountEUR,
            status: CommissionStatus.PAID,
            paidAt: new Date(),
          },
        });

        // 2. Double-entry Ledger Posting:
        // DEBIT PLATFORM_REVENUE (Platform marketing expense)
        // CREDIT AVAILABLE_RETURNS (Referrer's withdrawable returns)
        const revenueAccId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_REVENUE);
        const referrerAvailableAccId = await LedgerService.ensurePartnerAccount(
          ref.referrerProfileId,
          AccountType.AVAILABLE_RETURNS
        );

        await LedgerService.postTransaction(
          {
            referenceNumber: `COMMISSION-${ref.id}-${periodMonth}`,
            description: `3% monthly referral commission for period ${periodMonth} from referee ${ref.refereeProfileId}`,
            sourceEntity: 'ReferralCommission',
            sourceEntityId: commission.id,
            entries: [
              {
                accountId: revenueAccId,
                entryType: EntryType.DEBIT,
                amount: commissionAmountEUR,
                currency: Currency.EUR,
                amountEUR: commissionAmountEUR,
              },
              {
                accountId: referrerAvailableAccId,
                entryType: EntryType.CREDIT,
                amount: commissionAmountEUR,
                currency: Currency.EUR,
                amountEUR: commissionAmountEUR,
              },
            ],
          },
          tx
        );

        // 3. Audit Log
        await AuditService.log({
          action: 'REFERRAL_COMMISSION_CREDITED',
          entityType: 'ReferralCommission',
          entityId: commission.id,
          newState: {
            periodMonth,
            commissionAmountEUR: commissionAmountEUR.toString(),
            referrerProfileId: ref.referrerProfileId,
            refereeCapitalEUR: totalQualifyingCapitalEUR.toString(),
          },
        });

        results.push({
          referralId: ref.id,
          referrerProfileId: ref.referrerProfileId,
          refereeProfileId: ref.refereeProfileId,
          capitalEUR: totalQualifyingCapitalEUR.toFixed(2),
          commissionEUR: commissionAmountEUR.toFixed(2),
        });
      });
    }

    logger.info(`Completed monthly referral commission calculation for ${periodMonth}`, {
      processedCount: results.length,
    });

    return { periodMonth, count: results.length, results };
  }

  /**
   * Retrieves authoritative referral summary and statistics for a partner profile.
   */
  static async getReferralSummary(partnerProfileId: string, viewCurrency?: Currency) {
    const partner = await prisma.partnerProfile.findUnique({
      where: { id: partnerProfileId },
      include: {
        referees: {
          include: {
            referee: {
              select: {
                fullName: true,
                preferredCurrency: true,
                createdAt: true,
                investmentBatches: {
                  where: { status: BatchStatus.ACTIVE },
                  select: { capitalEUR: true },
                },
              },
            },
          },
        },
        commissionsEarned: {
          orderBy: { createdAt: 'desc' },
          include: {
            referee: {
              select: { fullName: true },
            },
          },
        },
      },
    });

    if (!partner) {
      throw AppError.notFound(`Partner profile ${partnerProfileId} not found`);
    }

    const targetCurrency = viewCurrency || partner.preferredCurrency;
    const rateSnapshot = await resolveExchangeRate('EUR', targetCurrency);
    const rate = rateSnapshot.rate;

    let totalActiveReferees = 0;
    let totalPendingReferees = 0;
    let activeStockValueEUR = new Prisma.Decimal('0.00');

    const refereeList = partner.referees.map((r) => {
      let refereeCapitalEUR = new Prisma.Decimal('0.00');
      for (const batch of r.referee.investmentBatches) {
        refereeCapitalEUR = refereeCapitalEUR.plus(batch.capitalEUR);
      }

      const isActive = refereeCapitalEUR.greaterThan(0);
      if (isActive) {
        totalActiveReferees++;
        activeStockValueEUR = activeStockValueEUR.plus(refereeCapitalEUR);
      } else {
        totalPendingReferees++;
      }

      const capitalInView = convertCurrency(refereeCapitalEUR, rate);
      const monthlyBonusInView = convertCurrency(
        refereeCapitalEUR.mul(new Prisma.Decimal('0.0300')),
        rate
      );

      return {
        referralId: r.id,
        refereeName: r.referee.fullName,
        capitalInView: capitalInView.toFixed(2),
        capitalEUR: refereeCapitalEUR.toFixed(2),
        monthlyBonusInView: monthlyBonusInView.toFixed(2),
        status: isActive ? 'Active' : 'Pending',
        attributionDate: r.attributionDate,
      };
    });

    let totalCommissionsEarnedEUR = new Prisma.Decimal('0.00');
    const commissionHistory = partner.commissionsEarned.map((c) => {
      totalCommissionsEarnedEUR = totalCommissionsEarnedEUR.plus(c.commissionAmountEUR);
      const amountInView = convertCurrency(c.commissionAmountEUR, rate);

      return {
        id: c.id,
        periodMonth: c.periodMonth,
        refereeName: c.referee.fullName,
        refereeCapitalEUR: c.refereeCapitalEUR.toFixed(2),
        commissionEUR: c.commissionAmountEUR.toFixed(2),
        amountInView: amountInView.toFixed(2),
        status: c.status,
        paidAt: c.paidAt,
      };
    });

    const monthlyEstimatedBonusEUR = activeStockValueEUR.mul(new Prisma.Decimal('0.0300'));
    const monthlyEstimatedBonusInView = convertCurrency(monthlyEstimatedBonusEUR, rate);
    const totalCommissionsInView = convertCurrency(totalCommissionsEarnedEUR, rate);

    return {
      referralCode: partner.referralCode,
      referralLink: `https://xplainghbv.com/ref/${partner.referralCode}`,
      viewCurrency: targetCurrency,
      totalReferrals: partner.referees.length,
      activeReferrals: totalActiveReferees,
      pendingReferrals: totalPendingReferees,
      monthlyEstimatedBonusEUR: monthlyEstimatedBonusEUR.toFixed(2),
      monthlyEstimatedBonusInView: monthlyEstimatedBonusInView.toFixed(2),
      totalCommissionsEarnedEUR: totalCommissionsEarnedEUR.toFixed(2),
      totalCommissionsEarnedInView: totalCommissionsInView.toFixed(2),
      referees: refereeList,
      commissions: commissionHistory,
    };
  }
}
