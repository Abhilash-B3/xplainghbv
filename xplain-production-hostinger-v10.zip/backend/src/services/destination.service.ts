import { Currency, PaymentProvider } from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { AuditService } from './audit.service.js';

export interface CreateBankAccountInput {
  partnerProfileId: string;
  bankName: string;
  accountNumber: string;
  sortCodeOrSwift: string;
  accountHolderName: string;
  currency?: Currency;
  country?: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface CreateMoMoAccountInput {
  partnerProfileId: string;
  provider: PaymentProvider;
  phoneNumber: string;
  accountHolderName: string;
  country?: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
}

export class DestinationService {
  /**
   * Masks sensitive account or phone numbers.
   * Example: "1234567890" -> "•••• 7890"
   */
  static maskNumber(val: string): string {
    const cleaned = val.trim();
    if (cleaned.length <= 4) return '•••• ' + cleaned;
    const last4 = cleaned.slice(-4);
    return `•••• ${last4}`;
  }

  // ─── Bank Accounts ──────────────────────────────────────────────────

  /**
   * Adds a new bank account destination for a partner profile.
   */
  static async addBankAccount(input: CreateBankAccountInput) {
    const {
      partnerProfileId,
      bankName,
      accountNumber,
      sortCodeOrSwift,
      accountHolderName,
      currency = Currency.EUR,
      country = 'GH',
      userId,
      ipAddress,
      userAgent,
    } = input;

    const masked = this.maskNumber(accountNumber);

    const bankAccount = await prisma.bankAccount.create({
      data: {
        partnerProfileId,
        bankName,
        accountNumberMasked: masked,
        accountNumberEncrypted: accountNumber, // In production, stored with KMS / AES-256-GCM
        sortCodeOrSwift,
        accountHolderName,
        currency,
        country,
        isVerified: true, // Internal destination verified for payouts
      },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'BANK_ACCOUNT_ADDED',
        entityType: 'BankAccount',
        entityId: bankAccount.id,
        newState: {
          bankName,
          accountNumberMasked: masked,
          currency,
        },
        ipAddress,
        userAgent,
      });
    }

    logger.info('Bank account destination added', {
      bankAccountId: bankAccount.id,
      partnerProfileId,
      currency,
    });

    return {
      id: bankAccount.id,
      bankName: bankAccount.bankName,
      accountNumberMasked: bankAccount.accountNumberMasked,
      sortCodeOrSwift: bankAccount.sortCodeOrSwift,
      accountHolderName: bankAccount.accountHolderName,
      currency: bankAccount.currency,
      country: bankAccount.country,
      isVerified: bankAccount.isVerified,
      createdAt: bankAccount.createdAt,
    };
  }

  /**
   * Lists all bank accounts belonging to the authenticated partner profile (Strict IDOR).
   */
  static async listBankAccounts(partnerProfileId: string) {
    const accounts = await prisma.bankAccount.findMany({
      where: { partnerProfileId },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        bankName: true,
        accountNumberMasked: true,
        sortCodeOrSwift: true,
        accountHolderName: true,
        currency: true,
        country: true,
        isVerified: true,
        createdAt: true,
      },
    });

    return accounts;
  }

  /**
   * Deletes a bank account destination with ownership check.
   */
  static async deleteBankAccount(id: string, partnerProfileId: string, userId?: string) {
    const existing = await prisma.bankAccount.findUnique({
      where: { id },
    });

    if (!existing) {
      throw AppError.notFound(`Bank account ${id} not found`);
    }

    if (existing.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to delete this bank account');
    }

    await prisma.bankAccount.delete({
      where: { id },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'BANK_ACCOUNT_DELETED',
        entityType: 'BankAccount',
        entityId: id,
      });
    }

    return { success: true, message: 'Bank account destination removed' };
  }

  // ─── MoMo Accounts (Withdrawal Destination Only) ────────────────────

  /**
   * Adds a mobile money withdrawal destination.
   * Note: MoMo is strictly for withdrawal payouts, never for investment funding.
   */
  static async addMoMoAccount(input: CreateMoMoAccountInput) {
    const {
      partnerProfileId,
      provider,
      phoneNumber,
      accountHolderName,
      country = 'GH',
      userId,
      ipAddress,
      userAgent,
    } = input;

    const masked = this.maskNumber(phoneNumber);

    const momoAccount = await prisma.moMoAccount.create({
      data: {
        partnerProfileId,
        provider,
        phoneNumberMasked: masked,
        phoneNumberEncrypted: phoneNumber,
        accountHolderName,
        country,
        isVerified: true,
      },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'MOMO_ACCOUNT_ADDED',
        entityType: 'MoMoAccount',
        entityId: momoAccount.id,
        newState: {
          provider,
          phoneNumberMasked: masked,
        },
        ipAddress,
        userAgent,
      });
    }

    logger.info('MoMo payout destination added', {
      moMoAccountId: momoAccount.id,
      partnerProfileId,
      provider,
    });

    return {
      id: momoAccount.id,
      provider: momoAccount.provider,
      phoneNumberMasked: momoAccount.phoneNumberMasked,
      accountHolderName: momoAccount.accountHolderName,
      country: momoAccount.country,
      isVerified: momoAccount.isVerified,
      createdAt: momoAccount.createdAt,
    };
  }

  /**
   * Lists all MoMo accounts for a partner profile (Strict IDOR).
   */
  static async listMoMoAccounts(partnerProfileId: string) {
    return prisma.moMoAccount.findMany({
      where: { partnerProfileId },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        provider: true,
        phoneNumberMasked: true,
        accountHolderName: true,
        country: true,
        isVerified: true,
        createdAt: true,
      },
    });
  }

  /**
   * Deletes a MoMo destination with ownership check.
   */
  static async deleteMoMoAccount(id: string, partnerProfileId: string, userId?: string) {
    const existing = await prisma.moMoAccount.findUnique({
      where: { id },
    });

    if (!existing) {
      throw AppError.notFound(`MoMo account ${id} not found`);
    }

    if (existing.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to delete this MoMo account');
    }

    await prisma.moMoAccount.delete({
      where: { id },
    });

    if (userId) {
      await AuditService.log({
        userId,
        action: 'MOMO_ACCOUNT_DELETED',
        entityType: 'MoMoAccount',
        entityId: id,
      });
    }

    return { success: true, message: 'MoMo payout destination removed' };
  }
}
