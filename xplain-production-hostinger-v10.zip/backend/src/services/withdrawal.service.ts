import {
  Prisma,
  WithdrawalStatus,
  WithdrawalType,
  DestinationType,
  AccountType,
  EntryType,
  Currency,
} from '@prisma/client';
import { prisma } from '../config/database.js';
import { AppError } from '../utils/appError.js';
import { logger } from '../utils/logger.js';
import { LedgerService } from './ledger.service.js';
import { AuditService } from './audit.service.js';
import { convertCurrency, resolveExchangeRate } from '../utils/currency.js';

export interface RequestWithdrawalInput {
  partnerProfileId: string;
  withdrawalType?: WithdrawalType; // Default: RETURNS
  amount: number | string | Prisma.Decimal;
  currency: Currency;
  destinationType: DestinationType;
  bankAccountId?: string;
  moMoAccountId?: string;
  idempotencyKey?: string;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface CompleteWithdrawalInput {
  withdrawalId: string;
  adminUserId: string;
  settlementReference: string; // e.g. "BANK-TRF-2026-981723" or payout provider tx id
  settlementProof?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
}

export class WithdrawalService {
  /**
   * Computes the authoritative withdrawable balance directly from PostgreSQL double-entry ledger.
   * Total Withdrawable = AVAILABLE_RETURNS balance + UNLOCKED_CAPITAL balance.
   * Note: Any active reserved withdrawal has ALREADY been debited from AVAILABLE_RETURNS to WITHDRAWAL_RESERVED,
   * so no duplicate subtraction occurs.
   */
  static async getAuthoritativeBalance(
    partnerProfileId: string,
    tx?: Prisma.TransactionClient
  ): Promise<{
    availableReturnsEUR: Prisma.Decimal;
    unlockedCapitalEUR: Prisma.Decimal;
    totalWithdrawableEUR: Prisma.Decimal;
    reservedWithdrawalsEUR: Prisma.Decimal;
  }> {
    const client = tx || prisma;

    const availableReturnsAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.AVAILABLE_RETURNS
    );
    const unlockedCapitalAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.UNLOCKED_CAPITAL
    );
    const reservedAccId = await LedgerService.ensurePartnerAccount(
      partnerProfileId,
      AccountType.WITHDRAWAL_RESERVED
    );

    const [availableReturnsEUR, unlockedCapitalEUR, reservedWithdrawalsEUR] = await Promise.all([
      LedgerService.getAccountBalance(availableReturnsAccId, client),
      LedgerService.getAccountBalance(unlockedCapitalAccId, client),
      LedgerService.getAccountBalance(reservedAccId, client),
    ]);

    const totalWithdrawableEUR = availableReturnsEUR
      .plus(unlockedCapitalEUR)
      .toDecimalPlaces(4, Prisma.Decimal.ROUND_HALF_UP);

    return {
      availableReturnsEUR,
      unlockedCapitalEUR,
      totalWithdrawableEUR,
      reservedWithdrawalsEUR,
    };
  }

  /**
   * Requests a new withdrawal with atomic double-entry ledger reservation and concurrency protection.
   */
  static async requestWithdrawal(input: RequestWithdrawalInput) {
    const {
      partnerProfileId,
      withdrawalType = WithdrawalType.RETURNS,
      amount,
      currency,
      destinationType,
      bankAccountId,
      moMoAccountId,
      idempotencyKey,
      userId,
      ipAddress,
      userAgent,
    } = input;

    // 1. Amount validation
    const decimalAmount = new Prisma.Decimal(amount.toString());
    if (decimalAmount.lessThanOrEqualTo(0) || !decimalAmount.isFinite()) {
      throw AppError.badRequest('Withdrawal amount must be a positive number');
    }

    // Minimum withdrawal threshold: 20 EUR or equivalent
    const rateSnapshot = await resolveExchangeRate(currency, 'EUR');
    const amountEUR = convertCurrency(decimalAmount, rateSnapshot.rate).toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);

    if (amountEUR.lessThan(new Prisma.Decimal('20.00'))) {
      throw AppError.badRequest('Minimum withdrawal amount is 20.00 EUR (or currency equivalent)');
    }

    // 2. Validate destination ownership (Strict IDOR)
    if (destinationType === DestinationType.BANK) {
      if (!bankAccountId) {
        throw AppError.badRequest('Bank account ID is required for bank transfer withdrawal');
      }
      const bankAccount = await prisma.bankAccount.findUnique({
        where: { id: bankAccountId },
      });
      if (!bankAccount || bankAccount.partnerProfileId !== partnerProfileId) {
        throw AppError.forbidden('Invalid bank account destination or destination does not belong to you');
      }
    } else if (destinationType === DestinationType.MOMO) {
      if (!moMoAccountId) {
        throw AppError.badRequest('MoMo account ID is required for mobile money withdrawal');
      }
      const momoAccount = await prisma.moMoAccount.findUnique({
        where: { id: moMoAccountId },
      });
      if (!momoAccount || momoAccount.partnerProfileId !== partnerProfileId) {
        throw AppError.forbidden('Invalid MoMo account destination or destination does not belong to you');
      }
    }

    // 3. Check for Idempotency Key collision
    if (idempotencyKey) {
      const existing = await prisma.withdrawal.findUnique({
        where: { idempotencyKey },
      });
      if (existing) {
        logger.info('Returning existing withdrawal request (idempotent)', {
          withdrawalId: existing.id,
          idempotencyKey,
        });
        return existing;
      }
    }

    // 4. Atomic PostgreSQL Transaction: Check balance, reserve funds, create withdrawal
    return prisma.$transaction(async (tx) => {
      // 4a. Check authoritative ledger balance under lock
      const balance = await this.getAuthoritativeBalance(partnerProfileId, tx);

      const targetAccountType =
        withdrawalType === WithdrawalType.CAPITAL
          ? AccountType.UNLOCKED_CAPITAL
          : AccountType.AVAILABLE_RETURNS;

      const availableSource =
        withdrawalType === WithdrawalType.CAPITAL
          ? balance.unlockedCapitalEUR
          : balance.availableReturnsEUR;

      if (availableSource.lessThan(amountEUR)) {
        logger.warn('Insufficient withdrawable balance for withdrawal request', {
          partnerProfileId,
          requestedEUR: amountEUR.toString(),
          availableEUR: availableSource.toString(),
          withdrawalType,
        });
        throw AppError.badRequest(
          `Insufficient available ${withdrawalType.toLowerCase()} balance. Available: ${availableSource.toFixed(2)} EUR, Requested: ${amountEUR.toFixed(2)} EUR`
        );
      }

      // 4b. Create Withdrawal Record (status: PENDING)
      const withdrawal = await tx.withdrawal.create({
        data: {
          partnerProfileId,
          withdrawalType,
          amount: decimalAmount,
          currency,
          amountEUR,
          destinationType,
          bankAccountId: destinationType === DestinationType.BANK ? bankAccountId : null,
          moMoAccountId: destinationType === DestinationType.MOMO ? moMoAccountId : null,
          status: WithdrawalStatus.PENDING,
          idempotencyKey: idempotencyKey || null,
        },
        include: {
          bankAccount: {
            select: { bankName: true, accountNumberMasked: true },
          },
          moMoAccount: {
            select: { provider: true, phoneNumberMasked: true },
          },
        },
      });

      // 4c. Post Double-Entry Ledger Reservation:
      // DEBIT AVAILABLE_RETURNS (or UNLOCKED_CAPITAL), CREDIT WITHDRAWAL_RESERVED
      const sourceAccId = await LedgerService.ensurePartnerAccount(partnerProfileId, targetAccountType);
      const reservedAccId = await LedgerService.ensurePartnerAccount(
        partnerProfileId,
        AccountType.WITHDRAWAL_RESERVED
      );

      await LedgerService.postTransaction(
        {
          referenceNumber: `WITHDRAW-RESERVE-${withdrawal.id}`,
          description: `Withdrawal reservation for request ${withdrawal.id}`,
          sourceEntity: 'Withdrawal',
          sourceEntityId: withdrawal.id,
          entries: [
            {
              accountId: sourceAccId,
              entryType: EntryType.DEBIT,
              amount: amountEUR,
              currency: Currency.EUR,
              amountEUR,
            },
            {
              accountId: reservedAccId,
              entryType: EntryType.CREDIT,
              amount: amountEUR,
              currency: Currency.EUR,
              amountEUR,
            },
          ],
        },
        tx
      );

      // 4d. Audit Log
      if (userId) {
        await AuditService.log({
          userId,
          action: 'WITHDRAWAL_REQUESTED',
          entityType: 'Withdrawal',
          entityId: withdrawal.id,
          newState: {
            amount: decimalAmount.toString(),
            currency,
            amountEUR: amountEUR.toString(),
            destinationType,
            status: WithdrawalStatus.PENDING,
          },
          ipAddress,
          userAgent,
        });
      }

      logger.info('Withdrawal requested and funds reserved in ledger', {
        withdrawalId: withdrawal.id,
        partnerProfileId,
        amountEUR: amountEUR.toString(),
      });

      return withdrawal;
    });
  }

  /**
   * Cancels a pending withdrawal and releases reserved funds back to AVAILABLE_RETURNS.
   */
  static async cancelWithdrawal(withdrawalId: string, partnerProfileId: string, userId?: string) {
    return prisma.$transaction(async (tx) => {
      const withdrawal = await tx.withdrawal.findUnique({
        where: { id: withdrawalId },
      });

      if (!withdrawal) {
        throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
      }

      if (withdrawal.partnerProfileId !== partnerProfileId) {
        throw AppError.forbidden('You do not have permission to cancel this withdrawal');
      }

      if (withdrawal.status !== WithdrawalStatus.PENDING) {
        throw AppError.badRequest(`Withdrawal cannot be cancelled from status ${withdrawal.status}`);
      }

      // 1. Release Double-Entry Ledger Reservation:
      // DEBIT WITHDRAWAL_RESERVED, CREDIT AVAILABLE_RETURNS
      const targetAccountType =
        withdrawal.withdrawalType === WithdrawalType.CAPITAL
          ? AccountType.UNLOCKED_CAPITAL
          : AccountType.AVAILABLE_RETURNS;

      const sourceAccId = await LedgerService.ensurePartnerAccount(
        partnerProfileId,
        targetAccountType
      );
      const reservedAccId = await LedgerService.ensurePartnerAccount(
        partnerProfileId,
        AccountType.WITHDRAWAL_RESERVED
      );

      await LedgerService.postTransaction(
        {
          referenceNumber: `WITHDRAW-CANCEL-${withdrawal.id}`,
          description: `Withdrawal cancellation release for request ${withdrawal.id}`,
          sourceEntity: 'Withdrawal',
          sourceEntityId: withdrawal.id,
          entries: [
            {
              accountId: reservedAccId,
              entryType: EntryType.DEBIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
            {
              accountId: sourceAccId,
              entryType: EntryType.CREDIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
          ],
        },
        tx
      );

      // 2. Update status
      const updated = await tx.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: WithdrawalStatus.CANCELLED,
        },
      });

      // 3. Audit
      if (userId) {
        await AuditService.log({
          userId,
          action: 'WITHDRAWAL_CANCELLED',
          entityType: 'Withdrawal',
          entityId: withdrawal.id,
          newState: { status: WithdrawalStatus.CANCELLED },
        });
      }

      logger.info('Withdrawal cancelled and reserved funds released', { withdrawalId });
      return updated;
    });
  }

  /**
   * Approves a pending withdrawal (Admin operational review).
   */
  static async approveWithdrawal(withdrawalId: string, adminUserId: string) {
    return prisma.$transaction(async (tx) => {
      const withdrawal = await tx.withdrawal.findUnique({
        where: { id: withdrawalId },
      });

      if (!withdrawal) {
        throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
      }

      if (withdrawal.status !== WithdrawalStatus.PENDING) {
        throw AppError.badRequest(`Withdrawal cannot be approved from status ${withdrawal.status}`);
      }

      const updated = await tx.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: WithdrawalStatus.APPROVED,
          approvedByUserId: adminUserId,
        },
      });

      await AuditService.log({
        userId: adminUserId,
        action: 'WITHDRAWAL_APPROVED',
        entityType: 'Withdrawal',
        entityId: withdrawal.id,
        newState: { status: WithdrawalStatus.APPROVED, approvedByUserId: adminUserId },
      });

      logger.info('Withdrawal approved by admin', { withdrawalId, adminUserId });
      return updated;
    });
  }

  /**
   * Marks withdrawal as processing (Dispatched to banking payout / queue).
   */
  static async processWithdrawal(withdrawalId: string, adminUserId?: string) {
    const withdrawal = await prisma.withdrawal.findUnique({
      where: { id: withdrawalId },
    });

    if (!withdrawal) {
      throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
    }

    if (
      withdrawal.status !== WithdrawalStatus.PENDING &&
      withdrawal.status !== WithdrawalStatus.APPROVED
    ) {
      throw AppError.badRequest(`Withdrawal cannot transition to PROCESSING from ${withdrawal.status}`);
    }

    const updated = await prisma.withdrawal.update({
      where: { id: withdrawalId },
      data: {
        status: WithdrawalStatus.PROCESSING,
      },
    });

    if (adminUserId) {
      await AuditService.log({
        userId: adminUserId,
        action: 'WITHDRAWAL_PROCESSING',
        entityType: 'Withdrawal',
        entityId: withdrawal.id,
        newState: { status: WithdrawalStatus.PROCESSING },
      });
    }

    return updated;
  }

  /**
   * Settles and completes a withdrawal with genuine settlement evidence and double-entry ledger settlement.
   * Ledger Movement: DEBIT WITHDRAWAL_RESERVED (clears liability), CREDIT PLATFORM_ESCROW (records cash outflow).
   */
  static async completeWithdrawal(input: CompleteWithdrawalInput) {
    const { withdrawalId, adminUserId, settlementReference, settlementProof, ipAddress, userAgent } = input;

    if (!settlementReference || settlementReference.trim().length < 4) {
      throw AppError.badRequest(
        'Genuine settlement reference or provider transaction ID is required to complete withdrawal'
      );
    }

    return prisma.$transaction(async (tx) => {
      const withdrawal = await tx.withdrawal.findUnique({
        where: { id: withdrawalId },
      });

      if (!withdrawal) {
        throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
      }

      if (withdrawal.status === WithdrawalStatus.COMPLETED) {
        logger.info('Withdrawal is already completed (idempotent)', { withdrawalId });
        return withdrawal;
      }

      if (
        withdrawal.status !== WithdrawalStatus.APPROVED &&
        withdrawal.status !== WithdrawalStatus.PROCESSING &&
        withdrawal.status !== WithdrawalStatus.PENDING
      ) {
        throw AppError.badRequest(`Withdrawal cannot be completed from status ${withdrawal.status}`);
      }

      // 1. Post Terminal Double-Entry Settlement:
      // DEBIT WITHDRAWAL_RESERVED (removes partner reserved liability)
      // CREDIT PLATFORM_ESCROW (reduces platform cash asset by actual outflow)
      const reservedAccId = await LedgerService.ensurePartnerAccount(
        withdrawal.partnerProfileId,
        AccountType.WITHDRAWAL_RESERVED
      );
      const escrowAccId = await LedgerService.ensureSystemAccount(AccountType.PLATFORM_ESCROW);

      await LedgerService.postTransaction(
        {
          referenceNumber: `WITHDRAW-SETTLE-${withdrawal.id}`,
          description: `Withdrawal payout settlement for ${withdrawal.id} via ref ${settlementReference}`,
          sourceEntity: 'Withdrawal',
          sourceEntityId: withdrawal.id,
          entries: [
            {
              accountId: reservedAccId,
              entryType: EntryType.DEBIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
            {
              accountId: escrowAccId,
              entryType: EntryType.CREDIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
          ],
        },
        tx
      );

      // 2. Update Withdrawal Record
      const updated = await tx.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: WithdrawalStatus.COMPLETED,
          settlementReference,
          settlementProof: settlementProof || { settledBy: adminUserId, settledAt: new Date().toISOString() },
          processedAt: new Date(),
        },
      });

      // 3. Audit Log
      await AuditService.log({
        userId: adminUserId,
        action: 'WITHDRAWAL_COMPLETED',
        entityType: 'Withdrawal',
        entityId: withdrawal.id,
        newState: {
          status: WithdrawalStatus.COMPLETED,
          settlementReference,
          processedAt: updated.processedAt,
        },
        ipAddress,
        userAgent,
      });

      logger.info('Withdrawal successfully completed and settled in ledger', {
        withdrawalId,
        settlementReference,
        amountEUR: withdrawal.amountEUR.toString(),
      });

      return updated;
    });
  }

  /**
   * Rejects a withdrawal and releases reserved funds back to AVAILABLE_RETURNS.
   */
  static async rejectWithdrawal(withdrawalId: string, adminUserId: string, reason: string) {
    if (!reason || reason.trim().length < 3) {
      throw AppError.badRequest('A valid rejection reason is required');
    }

    return prisma.$transaction(async (tx) => {
      const withdrawal = await tx.withdrawal.findUnique({
        where: { id: withdrawalId },
      });

      if (!withdrawal) {
        throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
      }

      if (
        withdrawal.status !== WithdrawalStatus.PENDING &&
        withdrawal.status !== WithdrawalStatus.APPROVED &&
        withdrawal.status !== WithdrawalStatus.PROCESSING
      ) {
        throw AppError.badRequest(`Withdrawal cannot be rejected from status ${withdrawal.status}`);
      }

      // 1. Release Double-Entry Ledger Reservation:
      // DEBIT WITHDRAWAL_RESERVED, CREDIT AVAILABLE_RETURNS
      const targetAccountType =
        withdrawal.withdrawalType === WithdrawalType.CAPITAL
          ? AccountType.UNLOCKED_CAPITAL
          : AccountType.AVAILABLE_RETURNS;

      const sourceAccId = await LedgerService.ensurePartnerAccount(
        withdrawal.partnerProfileId,
        targetAccountType
      );
      const reservedAccId = await LedgerService.ensurePartnerAccount(
        withdrawal.partnerProfileId,
        AccountType.WITHDRAWAL_RESERVED
      );

      await LedgerService.postTransaction(
        {
          referenceNumber: `WITHDRAW-REJECT-${withdrawal.id}`,
          description: `Withdrawal rejection release for request ${withdrawal.id}. Reason: ${reason}`,
          sourceEntity: 'Withdrawal',
          sourceEntityId: withdrawal.id,
          entries: [
            {
              accountId: reservedAccId,
              entryType: EntryType.DEBIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
            {
              accountId: sourceAccId,
              entryType: EntryType.CREDIT,
              amount: withdrawal.amountEUR,
              currency: Currency.EUR,
              amountEUR: withdrawal.amountEUR,
            },
          ],
        },
        tx
      );

      // 2. Update record
      const updated = await tx.withdrawal.update({
        where: { id: withdrawalId },
        data: {
          status: WithdrawalStatus.REJECTED,
          rejectionReason: reason,
        },
      });

      // 3. Audit
      await AuditService.log({
        userId: adminUserId,
        action: 'WITHDRAWAL_REJECTED',
        entityType: 'Withdrawal',
        entityId: withdrawal.id,
        newState: { status: WithdrawalStatus.REJECTED, rejectionReason: reason },
      });

      logger.info('Withdrawal rejected and reserved funds released', { withdrawalId, reason });
      return updated;
    });
  }

  /**
   * Retrieves withdrawal history for a partner profile.
   */
  static async getPartnerWithdrawals(partnerProfileId: string) {
    return prisma.withdrawal.findMany({
      where: { partnerProfileId },
      orderBy: { createdAt: 'desc' },
      include: {
        bankAccount: {
          select: { bankName: true, accountNumberMasked: true },
        },
        moMoAccount: {
          select: { provider: true, phoneNumberMasked: true },
        },
      },
    });
  }

  /**
   * Retrieves single withdrawal details with strict ownership (IDOR).
   */
  static async getWithdrawalById(withdrawalId: string, partnerProfileId: string, isAdmin = false) {
    const withdrawal = await prisma.withdrawal.findUnique({
      where: { id: withdrawalId },
      include: {
        bankAccount: {
          select: { bankName: true, accountNumberMasked: true },
        },
        moMoAccount: {
          select: { provider: true, phoneNumberMasked: true },
        },
        partnerProfile: {
          select: { fullName: true, preferredCurrency: true },
        },
      },
    });

    if (!withdrawal) {
      throw AppError.notFound(`Withdrawal ${withdrawalId} not found`);
    }

    if (!isAdmin && withdrawal.partnerProfileId !== partnerProfileId) {
      throw AppError.forbidden('You do not have permission to view this withdrawal');
    }

    return withdrawal;
  }
}
