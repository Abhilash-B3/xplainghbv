import type { Request, Response, NextFunction } from 'express';
import { Prisma } from '@prisma/client';
import { ZodError } from 'zod';
import { AppError } from '../utils/appError.js';
import { sendError } from '../utils/apiResponse.js';
import { logger } from '../utils/logger.js';
import { env } from '../config/env.js';
import type { RequestWithId } from '../types/index.js';

export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _next: NextFunction
): void {
  const reqWithId = req as RequestWithId;

  // 1. AppError (Operational typed application errors)
  if (err instanceof AppError) {
    if (err.statusCode >= 500) {
      logger.error(`AppError [${err.code}]: ${err.message}`, {
        requestId: reqWithId.id,
        code: err.code,
        details: err.details,
        path: req.originalUrl,
      });
    }
    sendError(res, err.code, err.message, err.statusCode, err.details, reqWithId);
    return;
  }

  // 2. Zod Validation Error
  if (err instanceof ZodError) {
    const details = err.issues.map((issue) => ({
      field: issue.path.join('.'),
      message: issue.message,
      code: issue.code,
    }));
    sendError(res, 'VALIDATION_ERROR', 'Request validation failed', 400, details, reqWithId);
    return;
  }

  // 3. Prisma Known Request Errors
  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      const target = Array.isArray(err.meta?.target) ? err.meta.target.join(', ') : 'field';
      sendError(
        res,
        'CONFLICT',
        `A record with this ${target} already exists`,
        409,
        { target: err.meta?.target },
        reqWithId
      );
      return;
    }

    if (err.code === 'P2025') {
      sendError(res, 'NOT_FOUND', 'Requested record not found', 404, undefined, reqWithId);
      return;
    }

    logger.error(`Prisma Known Error [${err.code}]: ${err.message}`, {
      requestId: reqWithId.id,
      code: err.code,
      meta: err.meta,
    });

    const isConnRefused = err.message.includes('ECONNREFUSED') || err.message.includes('Can\'t reach database server');
    const userMessage = isConnRefused
      ? 'Database connection unavailable. Please ensure PostgreSQL is running.'
      : env.NODE_ENV === 'production'
        ? 'A database error occurred'
        : err.message;

    sendError(
      res,
      'DATABASE_ERROR',
      userMessage,
      503,
      undefined,
      reqWithId
    );
    return;
  }

  // 4. Prisma Initialization Error (Connection failure, unreachable host)
  if (err instanceof Prisma.PrismaClientInitializationError) {
    logger.error(`Prisma Initialization Error: ${err.message}`, {
      requestId: reqWithId.id,
      errorCode: err.errorCode,
    });
    sendError(
      res,
      'DATABASE_ERROR',
      'Database connection unavailable. Please ensure PostgreSQL is running.',
      503,
      undefined,
      reqWithId
    );
    return;
  }

  // 5. Prisma Validation Error
  if (err instanceof Prisma.PrismaClientValidationError) {
    logger.error('Prisma Validation Error', {
      requestId: reqWithId.id,
      message: err.message,
    });
    sendError(
      res,
      'DATABASE_ERROR',
      env.NODE_ENV === 'production' ? 'Database query validation failed' : err.message,
      500,
      undefined,
      reqWithId
    );
    return;
  }

  // 5. Express Body Parser Malformed JSON
  if (err instanceof SyntaxError && 'status' in err && (err as { status: number }).status === 400 && 'body' in err) {
    sendError(res, 'BAD_REQUEST', 'Malformed JSON in request body', 400, undefined, reqWithId);
    return;
  }

  // 6. Generic / Unhandled Internal Error
  const errorObj = err instanceof Error ? err : new Error(String(err));
  logger.error(`Unhandled Exception: ${errorObj.message}`, {
    requestId: reqWithId.id,
    stack: errorObj.stack,
    path: req.originalUrl,
  });

  sendError(
    res,
    'INTERNAL_ERROR',
    env.NODE_ENV === 'production' ? 'Internal server error' : errorObj.message,
    500,
    undefined,
    reqWithId
  );
}
