import type { Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';
import type { RequestWithId } from '../types/index.js';

export function requestIdMiddleware(
  req: RequestWithId,
  res: Response,
  next: NextFunction
): void {
  const incomingId = req.headers['x-request-id'];
  const requestId =
    typeof incomingId === 'string' && incomingId.trim().length > 0 && incomingId.length <= 64
      ? incomingId.trim()
      : randomUUID();

  req.id = requestId;
  req.startTime = performance.now();
  res.setHeader('X-Request-Id', requestId);
  next();
}
