import type { Response, NextFunction } from 'express';
import type { RequestWithId } from '../types/index.js';
import { logger } from '../utils/logger.js';

export function requestLoggingMiddleware(
  req: RequestWithId,
  res: Response,
  next: NextFunction
): void {
  const start = req.startTime ?? performance.now();

  res.on('finish', () => {
    const duration = Math.round(performance.now() - start);
    const statusCode = res.statusCode;

    const logContext = {
      requestId: req.id,
      method: req.method,
      path: req.originalUrl || req.url,
      statusCode,
      durationMs: duration,
      ip: req.ip,
      userAgent: req.get('user-agent'),
    };

    if (statusCode >= 500) {
      logger.error(`HTTP ${req.method} ${req.originalUrl || req.url} ${statusCode} (${duration}ms)`, logContext);
    } else if (statusCode >= 400) {
      logger.warn(`HTTP ${req.method} ${req.originalUrl || req.url} ${statusCode} (${duration}ms)`, logContext);
    } else {
      logger.info(`HTTP ${req.method} ${req.originalUrl || req.url} ${statusCode} (${duration}ms)`, logContext);
    }
  });

  next();
}
