import rateLimit from 'express-rate-limit';
import type { Request, Response } from 'express';
import { sendError } from '../utils/apiResponse.js';
import { env } from '../config/env.js';
import type { RequestWithId } from '../types/index.js';

export const globalRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: env.NODE_ENV === 'test' ? 10000 : 300, // Limit each IP to 300 requests per window
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    sendError(
      res,
      'RATE_LIMITED',
      'Too many requests from this IP, please try again after 15 minutes',
      429,
      undefined,
      req as RequestWithId
    );
  },
});

export const strictAuthRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: env.NODE_ENV === 'test' ? 10000 : 10, // Limit auth attempts
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    sendError(
      res,
      'RATE_LIMITED',
      'Too many authentication attempts, please try again after 15 minutes',
      429,
      undefined,
      req as RequestWithId
    );
  },
});
