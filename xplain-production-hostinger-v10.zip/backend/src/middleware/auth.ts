import type { Request, Response, NextFunction } from 'express';
import { AuthService, type SafeUser } from '../services/auth.service.js';
import { AppError } from '../utils/appError.js';
import { SESSION_COOKIE_NAME } from '../utils/cookie.js';
import type { UserRole } from '@prisma/client';

export interface AuthenticatedRequest extends Request {
  user?: SafeUser;
  sessionToken?: string;
}

/**
 * Middleware that verifies the caller has an active, valid session in PostgreSQL.
 * Reads token from HttpOnly cookie (default) or Authorization Bearer header (fallback).
 */
export async function requireAuth(
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction
): Promise<void> {
  try {
    let token: string | undefined;

    // 1. Try session cookie first
    if (req.cookies && typeof req.cookies[SESSION_COOKIE_NAME] === 'string') {
      token = req.cookies[SESSION_COOKIE_NAME];
    }

    // 2. Try Authorization Bearer header fallback
    if (!token && req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.substring(7).trim();
    }

    if (!token) {
      next(AppError.unauthorized('Authentication required. Please log in.'));
      return;
    }

    const safeUser = await AuthService.validateSession(token);
    if (!safeUser) {
      next(AppError.unauthorized('Session has expired or is invalid. Please log in again.'));
      return;
    }

    req.user = safeUser;
    req.sessionToken = token;
    next();
  } catch (error) {
    next(error);
  }
}

/**
 * RBAC middleware enforcing minimum role requirements on protected routes.
 */
export function requireRole(...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(AppError.unauthorized('Authentication required'));
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      next(
        AppError.forbidden(
          `Forbidden: Role '${req.user.role}' is not authorized to access this resource`
        )
      );
      return;
    }

    next();
  };
}
