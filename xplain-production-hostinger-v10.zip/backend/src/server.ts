import { app } from './app.js';
import { env } from './config/env.js';
import { connectDatabase, disconnectDatabase } from './config/database.js';
import { disconnectRedis } from './config/redis.js';
import { logger } from './utils/logger.js';
import type { Server } from 'http';

let server: Server | null = null;

async function startServer(): Promise<void> {
  try {
    logger.info('Starting Xplain GH BV Backend Server...', {
      environment: env.NODE_ENV,
      port: env.PORT,
    });

    // 1. Establish PostgreSQL database connection with retry resilience
    await connectDatabase();

    // 2. Start HTTP Server
    server = app.listen(env.PORT, () => {
      logger.info(`Server is listening on http://localhost:${env.PORT}`, {
        environment: env.NODE_ENV,
        healthEndpoint: `http://localhost:${env.PORT}/api/v1/health`,
      });
    });
  } catch (error) {
    logger.error('Fatal error during backend server startup', error instanceof Error ? error : { error });
    process.exit(1);
  }
}

async function gracefulShutdown(signal: string): Promise<void> {
  logger.info(`Received ${signal}. Initiating graceful shutdown...`);

  if (server) {
    server.close(async () => {
      logger.info('HTTP server closed, no longer accepting new connections.');

      try {
        await disconnectRedis();
        logger.info('Redis connection closed.');
      } catch (err) {
        logger.error('Error closing Redis connection:', { err });
      }

      try {
        await disconnectDatabase();
        logger.info('PostgreSQL database connection closed.');
      } catch (err) {
        logger.error('Error disconnecting database:', { err });
      }

      logger.info('Graceful shutdown completed successfully.');
      process.exit(0);
    });

    // Force shutdown after 10 seconds if hanging
    setTimeout(() => {
      logger.error('Graceful shutdown timed out. Forcing termination.');
      process.exit(1);
    }, 10000).unref();
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  gracefulShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', { reason });
  gracefulShutdown('unhandledRejection');
});

// Start the server if this file is run directly
if (process.env.NODE_ENV !== 'test') {
  startServer();
}

export { startServer, gracefulShutdown };
