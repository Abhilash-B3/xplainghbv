# PHASE 4 — SECURITY & AUTHORIZATION SPECIFICATION

**Project:** Xplain GH BV Investment Platform  
**Target Environment:** Hostinger (Standalone Node.js / Express + PostgreSQL)  
**Security Level:** Production FinTech Baseline  
**Date:** September 2026

---

## 1. Executive Summary

This document defines the complete security architecture for the Xplain GH BV identity and authorization layer implemented in Phase 4. All authentication state is strictly server-authoritative, backed by PostgreSQL, Argon2id cryptography, and secure HttpOnly cookie sessions.

---

## 2. Password Hashing (Argon2id)

- **Algorithm:** Argon2id (OWASP recommended standard for password storage).
- **Parameters:**
  - Memory cost: 64 MB (`65536 KB`)
  - Time cost: 3 iterations
  - Parallelism: 4 threads
  - Output length: 32 bytes
- **Enforcement:** Passwords are never stored in plaintext, never logged, and never returned in API payloads or audit logs.
- **Complexity Policy:** Minimum 8 characters, at least 1 uppercase letter, 1 lowercase letter, and 1 numeric digit.

---

## 3. Session Security & Token Cryptography

- **Entropy:** 32 bytes of cryptographically secure random bytes (`crypto.randomBytes(32)` -> 64 hex characters, 256 bits entropy).
- **Storage Strategy (Hash-at-Rest):** Raw session tokens are never stored directly in PostgreSQL. Instead, the server computes a deterministic SHA-256 hash (`crypto.createHash('sha256').update(rawToken).digest('hex')`) and saves only the hash in the `sessions` table.
- **Transportation:** The raw session token is transmitted to the client exclusively via the `xplain_session` HttpOnly cookie.
- **Expiration:** 7 days (`SESSION_MAX_AGE_MS = 604,800,000 ms`).
- **Revocation:** Explicit server-side revocation on logout (`revokedAt = now()`) and session invalidation upon password reset.

---

## 4. Cookie Configuration & CSRF Strategy

### A. Cookie Parameters
```ts
res.cookie('xplain_session', rawToken, {
  httpOnly: true,                               // Prevents JavaScript access / XSS token exfiltration
  secure: process.env.NODE_ENV === 'production', // Requires HTTPS in production
  sameSite: 'lax',                               // Protects against cross-site request forgery
  path: '/',
  maxAge: 7 * 24 * 60 * 60 * 1000,
  domain: process.env.COOKIE_DOMAIN || undefined,
});
```

### B. CSRF Analysis & Protection
- **Deployment Architecture:** In production on Hostinger, the frontend and API are hosted under the same root domain (e.g. `https://xplainghbv.com` and `https://xplainghbv.com/api/v1` via Nginx reverse proxy, or apex/subdomain `api.xplainghbv.com`).
- **SameSite=Lax Enforcement:** Modern browsers do not attach `SameSite=Lax` cookies to cross-origin POST, PUT, PATCH, or DELETE requests initiated by third-party origins.
- **Strict CORS Origin Check:** The backend CORS middleware explicitly restricts origins to `FRONTEND_URL` and rejects unapproved origins.
- **Custom Header Requirements:** State-changing requests carry `Content-Type: application/json`, which triggers CORS preflight (`OPTIONS`) in cross-origin scenarios.

---

## 5. Role-Based Access Control (RBAC) & IDOR Protection

### A. Server-Authoritative Roles
- `INVESTOR`: Can access and modify only their own profile, investments, and settings.
- `SUPPORT`: Limited support role.
- `ADMIN`: Platform operations according to policy.
- `SUPERADMIN`: Highest-level governance.

### B. IDOR Protection
- Endpoints operate on `/users/me` and `/auth/me`, deriving user ID strictly from the validated session (`req.user.id`).
- Direct entity queries enforce `where: { userId: req.user.id }` or `where: { partnerProfileId: req.user.partnerProfile.id }`.

### C. Mass Assignment Prevention
- `PATCH /api/v1/users/me` uses a strict Zod schema (`updateProfileSchema.strict()`).
- Fields like `role`, `status`, `balance`, `userId`, `isEmailVerified`, and `passwordHash` are rejected with `400 VALIDATION_ERROR` if present in update payloads.

---

## 6. Account Enumeration & Brute Force Protection

- **Forgot Password:** Returns an identical generic success message (`"If an account with that email exists, password reset instructions have been sent."`) regardless of whether the email exists.
- **Failed Logins:** Returns generic `401 UNAUTHORIZED` (`"Invalid email or password"`) for both incorrect passwords and non-existent users.
- **Rate Limiting:** Global rate limit of 300 req/15min, with strict auth rate limit of 10 attempts/15min on `/auth/login`, `/auth/forgot-password`, and `/auth/reset-password`.

---

## 7. Audit Logging

Every security event writes an immutable `AuditLog` record to PostgreSQL via `AuditService.log()`:
- `USER_REGISTERED`
- `LOGIN_SUCCESS`
- `LOGIN_FAILED`
- `LOGOUT`
- `PASSWORD_CHANGED`
- `PASSWORD_RESET_REQUESTED`
- `PASSWORD_RESET_COMPLETED`
- `EMAIL_VERIFIED`
- `PROFILE_UPDATED`
