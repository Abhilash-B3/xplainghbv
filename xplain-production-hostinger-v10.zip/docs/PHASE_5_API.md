# Phase 5: Products, Investments & Financial Ledger API Documentation

**Base URL:** `/api/v1`  
**Authentication:** HttpOnly session cookie (`xplain_session`) via header `Cookie: xplain_session=...`

---

## 1. Product & Catalogue Endpoints

### 1.1. List Products
* **Method:** `GET`
* **Path:** `/api/v1/products`
* **Auth:** Public
* **Query Parameters:**
  - `category` (optional, string): Category slug or name (e.g., `refrigerators`).
  - `search` (optional, string): Search keyword for product name, description, or reference.
  - `page` (optional, integer, default: 1)
  - `limit` (optional, integer, default: 50, max: 100)
  - `sort` (optional, string): `price_asc`, `price_desc`, `name_asc`, `newest`
* **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "products": [
      {
        "id": "uuid",
        "ref": "REF-001",
        "name": "Samsung French Door Refrigerator",
        "description": "500L stainless steel multi-door refrigerator",
        "priceEUR": "1250.00",
        "imageUrl": "https://...",
        "stockQuantity": 85,
        "isActive": true,
        "category": {
          "id": "uuid",
          "name": "Refrigerators",
          "slug": "refrigerators"
        }
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 50,
      "total": 12,
      "totalPages": 1
    }
  }
}
```

### 1.2. Get Product By ID or Ref
* **Method:** `GET`
* **Path:** `/api/v1/products/:idOrRef`
* **Auth:** Public
* **Response (200 OK):** Single product object.

### 1.3. List Categories
* **Method:** `GET`
* **Path:** `/api/v1/categories`
* **Auth:** Public
* **Response (200 OK):** Array of active product categories.

### 1.4. List Showcase Appliances
* **Method:** `GET`
* **Path:** `/api/v1/showcase`
* **Auth:** Public
* **Response (200 OK):** Curated landing page appliance showcase items.

---

## 2. Investment & Quote Endpoints

### 2.1. Request Investment Quote
* **Method:** `POST`
* **Path:** `/api/v1/investments/quote`
* **Auth:** Public / Authenticated
* **Request Body:**
```json
{
  "resalePlan": "SELLFOR", // or "DIRECT"
  "currency": "EUR", // "EUR", "GBP", "GHS"
  "items": [
    { "productId": "uuid", "quantity": 2 }
  ]
}
```
* **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "quoteId": "uuid",
    "resalePlan": "SELLFOR",
    "currency": "EUR",
    "exchangeRateToEUR": "1.00000000",
    "exchangeRateSnapshotId": "uuid",
    "rateSource": "DATABASE_SNAPSHOT",
    "discountMultiplier": "0.86",
    "subtotalEUR": "2500.00",
    "discountAmountEUR": "350.00",
    "totalAmountEUR": "2150.00",
    "totalAmountInCurrency": "2150.00",
    "monthlyReturnRate": "0.0700",
    "estimatedMonthlyReturnInCurrency": "150.50",
    "lockDurationMonths": 12,
    "expiresAt": "2026-09-12T20:15:00.000Z"
  }
}
```

### 2.2. Create Investment Intent
* **Method:** `POST`
* **Path:** `/api/v1/investments`
* **Auth:** Required (`INVESTOR`, `ADMIN`)
* **Headers:** `Idempotency-Key` (recommended, max 64 chars)
* **Request Body:**
```json
{
  "resalePlan": "SELLFOR",
  "currency": "EUR",
  "items": [
    { "productId": "uuid", "quantity": 2 }
  ],
  "deliveryAddressId": "uuid" // Required if resalePlan is DIRECT
}
```
* **Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "investment": {
      "id": "uuid",
      "status": "PAYMENT_PENDING",
      "resalePlan": "SELLFOR",
      "currency": "EUR",
      "totalAmountInCurrency": "2150.00",
      "totalAmountEUR": "2150.00",
      "exchangeRateToEUR": "1.00000000",
      "createdAt": "2026-09-12T19:30:00.000Z"
    },
    "paymentTransaction": {
      "id": "uuid",
      "referenceNumber": "TX-INV-8492048",
      "status": "INITIALIZED",
      "amount": "2150.00",
      "currency": "EUR"
    }
  }
}
```

### 2.3. List User Investments
* **Method:** `GET`
* **Path:** `/api/v1/investments`
* **Auth:** Required
* **Query Parameters:** `page`, `limit`, `status`

### 2.4. Get Investment Detail
* **Method:** `GET`
* **Path:** `/api/v1/investments/:id`
* **Auth:** Required (Owner or Admin)

---

## 3. Financial Summary & Ledger Endpoints

### 3.1. Get Authenticated User Financial Summary
* **Method:** `GET`
* **Path:** `/api/v1/users/me/financial-summary`
* **Auth:** Required
* **Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "availableReturnsEUR": "301.00",
    "lockedCapitalEUR": "2150.00",
    "unlockedCapitalEUR": "0.00",
    "totalInvestedEUR": "2150.00",
    "totalPaidOutEUR": "0.00",
    "activeBatchesCount": 1,
    "completedBatchesCount": 0
  }
}
```

---

## 4. Admin Product CMS Endpoints

* `POST /api/v1/admin/products`: Create new catalog product (`ADMIN`, `SUPERADMIN`).
* `PATCH /api/v1/admin/products/:id`: Update product pricing/stock/details.
* `DELETE /api/v1/admin/products/:id`: Soft-archive product (`isActive = false`).
