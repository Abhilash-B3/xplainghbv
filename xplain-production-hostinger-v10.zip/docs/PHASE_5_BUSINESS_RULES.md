# Phase 5: Business Rules & Financial Policy Specifications

**Platform:** Xplain GH BV Investment Platform  
**Version:** Phase 5 — Real Products, Investments, Financial Ledger, Pricing, Returns & Payout Engine

---

## 1. Investment Resale Options

### 1.1. Option A — Direct Delivery
* **Concept:** Partner purchases European home appliances at listed retail price for physical delivery to an address in Ghana.
* **Pricing Multiplier:** `1.00` (0% discount from base EUR catalog price).
* **Monthly Returns:** `0.00%` (No monthly investment returns accrue).
* **Capital Lock:** None (Physical goods transaction).
* **Mandatory Requirements:** Physical delivery address details (recipient name, street line 1, city, postal code, country, phone number).
* **Fulfillment Lifecycle:** `PAYMENT_PENDING` → `ACTIVE` (Confirmed) → `FULFILLED` (Delivered).

### 1.2. Option B — Sell on Behalf
* **Concept:** Partner purchases wholesale inventory at discounted prices. Xplain GH BV manages sales and logistics in European retail markets, providing partners with regular monthly returns.
* **Wholesale Discount:** `14.00%` discount applied to listed EUR catalogue price (`discountMultiplier = 0.86`).
* **Monthly Return Rate:** `7.00%` per month (`monthlyReturnRate = 0.0700`), calculated strictly on the invested capital in EUR.
* **Capital Lock Duration:** `12 months` (`lockDurationMonths = 12`).
* **Return Accrual Start:** Returns start accrual after verified payment settlement (start date $T_0$).
* **Payout Schedule:** 12 equal monthly installments due at $T_0 + 30\text{ days} \times i$ (where $i = 1, 2, \dots, 12$).
* **Capital Unlock:** At $T_0 + 365\text{ days}$, the original invested capital transitions from `LOCKED_CAPITAL` to `UNLOCKED_CAPITAL`.

---

## 2. Minimum Investment Policy

* **Canonical Threshold:** **GH₵1,050.00** (Ghanaian Cedi).
* **Applicability:** Applies strictly to the total cart value of all investment orders (Option A and Option B).
* **Multi-Currency Parity:** Calculated using the frozen exchange rate snapshot:
  - $\text{Threshold}_{\text{EUR}} = \lceil 1,050 \times \text{Rate}_{\text{GHS}\to\text{EUR}} \rceil \approx \text{€}65.00$
  - $\text{Threshold}_{\text{GBP}} = \lceil 1,050 \times \text{Rate}_{\text{GHS}\to\text{GBP}} \rceil \approx \text{£}55.00$
* **Backend Enforcement:** Any quote or investment creation with `totalAmountInCurrency < minThreshold` is strictly rejected with HTTP `422 UNPROCESSABLE_ENTITY`.

---

## 3. Money Precision & Rounding Policy

* **No JavaScript Floating-Point Arithmetic:** Authoritative calculations use `Prisma.Decimal` and `Decimal.js`.
* **Storage Precision:**
  - Unit / Product Prices: `Decimal(12, 2)` (2 decimal places).
  - Transaction & Investment Totals: `Decimal(14, 2)` (2 decimal places).
  - Ledger Entries: `Decimal(14, 4)` (4 decimal places to prevent micro-rounding drift).
  - Exchange Rates: `Decimal(18, 8)` (8 decimal places for exact conversion reproducibility).
* **Rounding Rule:** Standard Bankers Rounding (`HALF_EVEN` / `HALF_UP` to 2 decimal places for financial presentation, 4 decimal places for ledger entries).

---

## 4. Currency Conversion & Exchange Rate Snapshots

* **Supported Currencies:** `EUR` (Base canonical currency), `GBP`, `GHS`.
* **Rate Freezing Mechanism:**
  1. For every quote/order calculation, the latest verified `ExchangeRateSnapshot` is resolved.
  2. The exact snapshot ID, timestamp, and rate are frozen into the `Investment` and `PaymentTransaction` records.
  3. Historical investments are permanently evaluated using their frozen rate snapshot, ensuring exact reproducibility regardless of future macroeconomic currency shifts.
* **Rate Sources:**
  - `LIVE_PROVIDER`: Real external market feed (configured in production).
  - `DATABASE_SNAPSHOT`: Active platform treasury snapshot stored in PostgreSQL.
  - `DEVELOPMENT_SEED`: Explicitly tagged fallback for isolated offline testing environments.

---

## 5. Stock Reservation & Concurrency Controls

* **Inventory Check:** Products must have `stockQuantity >= requestedQuantity` and `isActive = true`.
* **Pessimistic / Atomic Decrement:** Stock is reserved within a Prisma interactive transaction using atomic database updates.
* **Oversell Protection:** If concurrent requests compete for remaining stock, the database transaction enforces constraints; orders exceeding available stock fail atomically with HTTP `409 CONFLICT`.
