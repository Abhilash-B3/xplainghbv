# PHASE 3 — BACKEND ARCHITECTURE & RUNTIME FOUNDATION

**Project:** Xplain GH BV Investment Platform  
**Target Environment:** Hostinger (Standalone Node.js / Express Server + Managed PostgreSQL + Redis)  
**Specification Level:** Production Backend Architecture Foundation  
**Status:** Completed & Validated  
**Date:** September 2026

---

## 1. Executive Summary

Phase 3 transitions the Xplain GH BV platform permanently away from client-side simulated data and in-memory mock patterns. This document establishes the production-grade **Node.js + Express + TypeScript + Prisma 7 + PostgreSQL + Redis** backend foundation, configured with strict typing, runtime Zod environment validation, real database connectivity, security middleware, structured logging, centralized typed error handling, transaction utilities, and a live health check endpoint (`GET /api/v1/health`).

---

## 2. Technology Stack

| Layer | Technology | Purpose / Configuration |
| :--- | :--- | :--- |
| **Runtime** | Node.js (v20+ LTS recommended) | Standard standalone process execution (Hostinger Node.js Application Manager / PM2) |
| **Framework** | Express 5.x | High-throughput HTTP API engine |
| **Language** | TypeScript 5.6 (Strict Mode) | Full type safety (`noImplicitAny`, `strictNullChecks`, `strictBindCallApply`) |
| **Database ORM** | Prisma 7.10 | Type-safe query engine with `@prisma/adapter-pg` driver adapter |
| **Database Engine**| PostgreSQL 15+ | Authoritative relational data store and double-entry financial ledger |
| **Cache & Queues**| Redis (`ioredis` client) | Connection abstraction ready for BullMQ worker queues (Phase 6+) |
| **Validation** | Zod 4.x | Request payload, query params, and environment variable schema enforcement |
| **Security** | Helmet, CORS, Express-Rate-Limit | Strict origin verification, rate limiting, and HTTP security headers |
| **Testing** | Vitest 2.x + Supertest 7.x | Integration and unit testing against live API routes and middleware |

---

## 3. Directory Layout

The backend foundation is structured in `backend/` as follows:

```
backend/
├── dist/                      # Compiled JavaScript artifacts for production deployment
├── src/
│   ├── config/
│   │   ├── env.ts             # Zod-validated runtime environment variables
│   │   ├── database.ts        # PrismaClient singleton with PrismaPg pool & health ping
│   │   └── redis.ts           # Real Redis connection abstraction (ioredis)
│   ├── controllers/
│   │   └── health.controller.ts # Real database-backed health check controller
│   ├── middleware/
│   │   ├── errorHandler.ts    # Centralized typed error handler (AppError, Zod, Prisma)
│   │   ├── logging.ts         # Structured JSON HTTP request & duration logger
│   │   ├── notFound.ts        # 404 handler for unmatched routes
│   │   ├── rateLimiter.ts     # Global API & strict auth rate limiters
│   │   ├── requestId.ts       # UUIDv4 request ID injector (X-Request-Id header)
│   │   └── validate.ts        # Reusable Zod request body/query/params validator
│   ├── routes/
│   │   ├── index.ts           # Modular /api/v1 root router
│   │   └── health.routes.ts   # /api/v1/health route
│   ├── services/
│   │   ├── health.service.ts  # Database connection ping & latency evaluation
│   │   └── audit.service.ts   # Prisma-backed audit logging service
│   ├── types/
│   │   └── index.ts           # Standard ApiResponse, ApiErrorResponse, and Request types
│   ├── utils/
│   │   ├── apiResponse.ts     # Standardized JSON response envelope helpers
│   │   ├── appError.ts        # Typed application error hierarchy (AppError)
│   │   ├── logger.ts          # Structured logger with automatic credential redaction
│   │   └── transaction.ts     # Prisma transaction isolation helper
│   ├── app.ts                 # Express application initialization & middleware stack
│   └── server.ts              # HTTP listener & graceful shutdown handlers
├── tests/
│   ├── error.test.ts          # Automated centralized error & 404 handler tests
│   ├── health.test.ts         # Automated real database health check tests
│   └── security.test.ts       # Automated security headers, CORS, and Request ID tests
└── tsconfig.json              # Strict TypeScript configuration
```

---

## 4. HTTP Request Lifecycle & Middleware Architecture

Every incoming HTTP request traverses a standardized pipeline:

```
Incoming Request
  │
  ▼
[1] Helmet (X-Content-Type-Options, X-Frame-Options, CSP)
  │
  ▼
[2] CORS (Strict origin verification against FRONTEND_URL whitelist)
  │
  ▼
[3] Body Parsers (express.json limit 1mb, urlencoded limit 1mb)
  │
  ▼
[4] Request ID Middleware (Generates or preserves X-Request-Id)
  │
  ▼
[5] Structured Request Logger (Tracks request arrival, IP, user-agent)
  │
  ▼
[6] Global Rate Limiter (express-rate-limit 300 req / 15 min window)
  │
  ▼
[7] API Version Router (/api/v1)
  │
  ├──► Route-level Zod Validator (middleware/validate.ts)
  │      │
  │      ▼
  ├──► Controller (controllers/*.controller.ts)
  │      │
  │      ▼
  ├──► Service Layer (services/*.service.ts)
  │      │
  │      ▼
  └──► Prisma / PostgreSQL (Database Transaction Boundary)
         │
         ▼
[8] Standardized Response (sendSuccess or sendError with X-Request-Id)
  │
  ▼
[9] Finish Event Logger (Logs duration in ms, HTTP method, URL, status)
```

---

## 5. Database Connection & Lifecycle

1. **Driver Adapter:** In Prisma 7, PostgreSQL connectivity is powered by `@prisma/adapter-pg` wrapping a `pg.Pool` connection pool with configurable maximum connections (`max: 20`), idle timeouts (`30000ms`), and connection timeouts (`3000ms`).
2. **Singleton Management:** `prisma` is exported as a singleton instance to prevent connection exhaustion during hot-reloads in development.
3. **Graceful Disconnect:** During `SIGINT` or `SIGTERM`, the server halts incoming connections, closes the Redis socket, and safely disconnects Prisma and the `pg.Pool`.

---

## 6. Environment Configuration & Validation

All runtime configuration is strictly validated on startup using Zod in `backend/src/config/env.ts`:
- `NODE_ENV`: `'development' | 'production' | 'test'`
- `PORT`: Coerced positive integer (default: `5000`)
- `DATABASE_URL`: Required PostgreSQL connection string
- `FRONTEND_URL`: Whitelisted origin for CORS (default: `http://localhost:3000`)
- `SESSION_SECRET`: Cryptographic secret string (minimum 16 characters)
- `REDIS_URL`: Optional Redis connection string

If any required variable is missing or invalid, the process logs a formatted error and terminates immediately, preventing undefined runtime crashes in production.

---

## 7. Standardized API Responses & Centralized Error Handling

### A. Success Response Contract
```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "timestamp": "2026-09-12T13:00:00.000Z",
    "uptimeSeconds": 1420,
    "environment": "production",
    "version": "1.0.0",
    "services": {
      "database": {
        "status": "healthy",
        "latencyMs": 4
      },
      "redis": {
        "status": "disabled"
      }
    }
  },
  "meta": {}
}
```

### B. Error Response Contract
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Request validation failed",
    "details": [
      {
        "field": "amount",
        "message": "Amount must be positive",
        "code": "too_small"
      }
    ],
    "requestId": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

### C. Error Codes & Mapping
- `BAD_REQUEST` (400) — Malformed syntax or invalid request
- `VALIDATION_ERROR` (400) — Zod schema validation failure
- `UNAUTHORIZED` (401) — Missing or invalid authentication token/session
- `FORBIDDEN` (403) — Insufficient role permissions
- `NOT_FOUND` (404) — Resource or endpoint does not exist
- `CONFLICT` (409) — Unique constraint violation (Prisma P2002)
- `RATE_LIMITED` (429) — Rate limit threshold exceeded
- `DATABASE_ERROR` (500/503) — Database connectivity or query execution failure
- `INTERNAL_ERROR` (500) — Unhandled server exception (stack traces sanitized in production)

---

## 8. Real Health Check Endpoint (`GET /api/v1/health`)

The health check executes a live raw SQL query (`SELECT 1 as alive`) against PostgreSQL and pings Redis if configured:
- **HTTP 200 OK:** Database connection is healthy and responsive.
- **HTTP 503 Service Unavailable:** Database query fails or connection is refused.
- **Header:** Returns `X-Request-Id` for monitoring and log correlation.

---

## 9. Security & Hardening

1. **Helmet Protection:** Disables `x-powered-by`, enables `x-content-type-options: nosniff`, `x-frame-options: SAMEORIGIN`, and strict CSP in production.
2. **CORS Isolation:** Only explicitly whitelisted `FRONTEND_URL` origins are allowed. Unauthorized origins are rejected.
3. **Structured Logger Redaction:** Automatically scrubs passwords, secrets, API keys, tokens, and credit card numbers from logs.
4. **Parameterized SQL:** All database interactions flow through Prisma parameterized queries, completely eliminating raw SQL injection vectors.
5. **Request Tracing:** Unique UUIDv4 request IDs allow tracing errors through logs on Hostinger.

---

## 10. Automated Test Results

Automated backend test suite executed using Vitest + Supertest:
- **Health Endpoint (`backend/tests/health.test.ts`):** 2 tests passed (200 healthy verification + 503 database failure simulation).
- **Error Handling (`backend/tests/error.test.ts`):** 4 tests passed (404 handling, malformed JSON body handling, Zod validation formatting, `AppError` status mapping).
- **Security & Headers (`backend/tests/security.test.ts`):** 5 tests passed (Request ID generation, custom request ID reflection, Helmet headers, CORS reject, CORS allow).

**Total: 11 / 11 tests passed (100% success).**
