# Phase 5: Double-Entry Financial Ledger Architecture

**Platform:** Xplain GH BV Investment Platform  
**Target:** Phase 5 — Real Products, Investments, Financial Ledger, Pricing, Returns & Payout Engine

---

## 1. Core Principles of the Ledger

1. **Strict Double-Entry Invariant:**
   $$\sum \text{Debits} = \sum \text{Credits}$$
   Every `LedgerTransaction` must contain at least one DEBIT entry and at least one CREDIT entry whose monetary sums are exactly equal in canonical currency (`EUR`).
2. **Immutable Entries:** Ledger transactions and entries cannot be updated or deleted (`INSERT ONLY`). Corrections must be posted as offsetting reversal transactions.
3. **Canonical Multi-Currency Accounting:** All entries store both the native currency amount (`amount`) and the canonical EUR equivalent (`amountEUR`) using the transaction's frozen exchange snapshot.
4. **Authoritative Balances:** No static `balance` column exists on user models. User balances are calculated dynamically from sum of ledger entries.
5. **No Unbacked Payouts:** Funds cannot be credited to partner `AVAILABLE_RETURNS` unless backed by real funds in `PLATFORM_ESCROW` or `PLATFORM_REVENUE`.

---

## 2. Chart of Financial Accounts

| Account Type | Scope | Normal Balance | Purpose |
| :--- | :--- | :---: | :--- |
| `PLATFORM_ESCROW` | System (Null Partner ID) | Debit | Holds collected investor funds designated for wholesale inventory and returns. |
| `PLATFORM_REVENUE` | System (Null Partner ID) | Credit | Platform retail margins, fees, and operational income. |
| `REFERRAL_BONUS_PAYABLE` | System (Null Partner ID) | Credit | Platform liability for pending partner referral commissions. |
| `LOCKED_CAPITAL` | Partner Profile Specific | Credit | Partner's active invested capital locked for 12 months under Option B. |
| `UNLOCKED_CAPITAL` | Partner Profile Specific | Credit | Partner's matured capital available for withdrawal or reinvestment. |
| `AVAILABLE_RETURNS` | Partner Profile Specific | Credit | Monthly 7% profit distributions available for instant withdrawal. |

---

## 3. Financial Transaction Workflows

### 3.1. Investment Activation & Capital Locking (Triggered upon Payment Settlement in Phase 6)
* **Debit:** `PLATFORM_ESCROW` (Total canonical EUR received)
* **Credit:** `Partner: LOCKED_CAPITAL` (Option B) OR `PLATFORM_REVENUE` (Option A retail sale)

### 3.2. Monthly Return Distribution (Option B Payout)
* **Debit:** `PLATFORM_ESCROW` (7% of batch capital in EUR)
* **Credit:** `Partner: AVAILABLE_RETURNS` (7% of batch capital in EUR)
* **Constraint:** Ledger service validates that `PLATFORM_ESCROW` has sufficient debit balance before execution.

### 3.3. Capital Maturity (End of 12-Month Lock Period)
* **Debit:** `Partner: LOCKED_CAPITAL` (Original capital amount)
* **Credit:** `Partner: UNLOCKED_CAPITAL` (Original capital amount)

---

## 4. Concurrency, Idempotency & Reconciliation

* **Idempotency Protection:** Every ledger mutation accepts an external reference and checks `LedgerTransaction.referenceNumber` uniqueness.
* **Database Transactions:** All ledger operations run inside PostgreSQL interactive transactions (`isolationLevel: 'Serializable'` or default `ReadCommitted` with row-level locks).
* **Automated Reconciliation Routine:**
  1. Transaction Balance Verifier: Asserts $\text{debits} - \text{credits} = 0$ for all records.
  2. Account Balance Verifier: Compares aggregate credit/debit sums per account against transaction logs.
