# PHASE 4 — AUTHENTICATION & IDENTITY ARCHITECTURE

**Project:** Xplain GH BV Investment Platform  
**Target Environment:** Hostinger (Node.js / Express + PostgreSQL + Redis)  
**Layer:** Core Authentication, Session Store, RBAC & Profile Engine  
**Status:** Completed & Validated  
**Date:** September 2026

---

## 1. System Overview

Phase 4 implements a complete, PostgreSQL-backed identity and authorization system. It replaces all legacy frontend mock authentication with server-side sessions, Argon2id hashing, secure cookies, and strict RBAC.

```
┌─────────────────────────────────────────────────────────────┐
│                      REACT FRONTEND                         │
│   AuthContext ──► useAuth() ──► apiClient (with credentials)│
└──────────────────────────────┬──────────────────────────────┘
                               │ HttpOnly Cookie (xplain_session)
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                    EXPRESS HTTP SERVER                      │
│   cookieParser ──► requireAuth ──► requireRole ──► validate │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                    AUTH SERVICE LAYER                       │
│   AuthService / UserService / AuditService / EmailService   │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                  POSTGRESQL DATABASE                        │
│   users, partner_profiles, sessions, financial_accounts,    │
│   email_verification_tokens, password_reset_tokens, audit   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. API Endpoints Implemented

### Authentication Routes (`/api/v1/auth`)

| Method | Path | Middleware / Validation | Description |
| :--- | :--- | :--- | :--- |
| `POST` | `/register` | `validate(registerSchema)` | Registers user, creates partner profile, sets `xplain_session` cookie |
| `POST` | `/login` | `strictAuthRateLimiter`, `validate(loginSchema)` | Authenticates credentials, creates session, sets cookie |
| `POST` | `/logout` | `requireAuth` | Revokes session in DB and clears cookie |
| `GET` | `/me` | `requireAuth` | Returns currently authenticated user and partner profile |
| `POST` | `/change-password` | `requireAuth`, `validate(changePasswordSchema)` | Verifies old password, hashes new password, revokes other sessions |
| `POST` | `/forgot-password` | `strictAuthRateLimiter`, `validate(forgotPasswordSchema)` | Creates single-use reset token and dispatches reset email |
| `POST` | `/reset-password` | `strictAuthRateLimiter`, `validate(resetPasswordSchema)` | Resets password with valid token and revokes all sessions |
| `POST` | `/verify-email` | `validate(verifyEmailSchema)` | Verifies email address using single-use token |

### User Profile Routes (`/api/v1/users`)

| Method | Path | Middleware / Validation | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/me` | `requireAuth` | Retrieves full profile with addresses |
| `PATCH` | `/me` | `requireAuth`, `validate(updateProfileSchema)` | Updates whitelisted profile fields (strict mass-assignment protection) |

---

## 3. Atomic Registration Lifecycle

When `POST /api/v1/auth/register` is called, the backend executes an atomic PostgreSQL transaction:
1. Normalizes email (`trim().toLowerCase()`) and phone (`trim()`).
2. Checks for unique collision on `User.email` or `User.phone`.
3. Computes Argon2id password hash.
4. Generates unique partner referral code (`XP-XXXXXX`).
5. Inserts `User` record (`role: INVESTOR`, `status: ACTIVE`).
6. Inserts `PartnerProfile` record (`fullName`, `preferredCurrency`, `resalePlan`, `referralCode`).
7. If referred by an existing partner, links in `Referral` table.
8. Initializes double-entry ledger accounts (`AVAILABLE_RETURNS`, `LOCKED_CAPITAL`, `UNLOCKED_CAPITAL`, `REFERRAL_BONUS_PAYABLE`).
9. Generates 32-byte crypto verification token; inserts `EmailVerificationToken` (SHA-256 hashed).
10. Generates 32-byte crypto session token; inserts `Session` (SHA-256 hashed, 7-day expiration).
11. Records immutable `AuditLog` row (`USER_REGISTERED`).
12. Dispatches verification email (non-blocking).
13. Returns `201 Created` with `Set-Cookie: xplain_session=...; HttpOnly; SameSite=Lax`.

---

## 4. Session Validation Pipeline

On every protected request:
1. `requireAuth` middleware inspects `req.cookies.xplain_session` (or `Authorization: Bearer <token>`).
2. If token is absent -> returns `401 UNAUTHORIZED`.
3. Computes SHA-256 hash of token and queries PostgreSQL `sessions` table.
4. Verifies `session.revokedAt === null` and `session.expiresAt > now()`.
5. Verifies `session.user.status === 'ACTIVE'`.
6. Attaches `req.user` (`SafeUser`) and `req.sessionToken` to the request object.
7. Next middleware executes (e.g. `requireRole('ADMIN')` or controller).

---

## 5. Frontend Integration Architecture

- **`src/services/apiClient.ts`**: Standardized HTTP client with `credentials: 'include'`.
- **`src/services/authService.ts`**: Typesafe client for `/api/v1/auth/*` and `/api/v1/users/*`.
- **`src/context/AuthContext.tsx`**: React context managing live session state, calling `authService.getMe()` on application mount to resolve authentication.
- **`src/components/forms/AuthForm.tsx`**: Cleaned of all demo strings and `setTimeout()` simulations, dispatching real registration and login calls.
