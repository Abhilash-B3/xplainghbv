# Phase 5: Financial & Product Repository Audit

**Platform:** Xplain GH BV Investment Platform  
**Target Phase:** Phase 5 — Real Products, Investments, Financial Ledger, Pricing, Returns & Payout Engine  
**Audit Scope:** Full repository search for mock, dummy, fake, placeholder, simulation, setTimeout, localStorage, and hardcoded financial balances/products.

---

## 1. Classification Schema

* **A. Legitimate automated test fixture:** Mock data or stubs isolated purely within test suites (`backend/tests/`) that never run in production.
* **B. Legitimate database seed:** Initial production/development seed catalogue data (`prisma/seed.ts`) used to populate PostgreSQL with real initial records.
* **C. Documentation:** Technical architecture markdown documents illustrating concepts or payload examples.
* **D. Runtime mock:** Files in `src/mock/` or memory-based objects used during early UI prototyping.
* **E. Fake financial implementation:** Client-side balance calculation, simulated returns, or `setTimeout` simulating payments/payouts.
* **F. Placeholder requiring replacement:** Code structures awaiting authoritative backend API integration.

---

## 2. Repository Search Results & Classification

| Artifact / File Location | Found Pattern / Variable | Classification | Action Required in Phase 5 |
| :--- | :--- | :---: | :--- |
| `src/mock/products.ts` | `XPLAIN_PRODUCTS`, `PRODUCT_CATEGORIES` | **D / B** | Used as source for initial Prisma seed; remove runtime frontend imports and query `GET /api/v1/products` instead. |
| `src/mock/appliances.ts` | `APPLIANCES` | **D / B** | Seeded into `showcase_appliances` in PostgreSQL; switch frontend to `GET /api/v1/showcase`. |
| `src/mock/partners.ts` | `DEMO_PARTNER` | **D / E** | Remove runtime demo partner usages; partner profile & financial stats must come from PostgreSQL session + ledger. |
| `src/mock/referrals.ts` | `MOCK_REFERRALS` | **D** | Hardcoded referral list in UI. Retain only as placeholder or empty state until Phase 7. |
| `src/mock/legal.ts` | `LEGAL_CONTENT` | **B** | Seeded into `legal_documents` / `legal_versions` in database. |
| `src/services/productService.ts` | In-memory filter over `XPLAIN_PRODUCTS` | **D / F** | Replaced with HTTP calls to Express backend (`/api/v1/products`). |
| `src/services/partnerService.ts` | `localStorage.setItem('xplain_partner_profile')` | **E** | Remove localStorage persistence for partner financial data. Auth/Profile handled via Phase 4 cookie session. |
| `src/components/investments/ProductCatalogueStep.tsx` | Direct import of `XPLAIN_PRODUCTS` & client discount calculation | **E / F** | Migrate to backend `GET /api/v1/products` and backend quote calculation (`POST /api/v1/investments/quote`). |
| `src/pages/DashboardPage.tsx` | `batches.map` with `MONTHLY_RATE` calculation | **E / F** | Connect to `GET /api/v1/users/me/financial-summary` and `GET /api/v1/investments`. |
| `src/components/dashboard/DashboardOverview.tsx` | UI calculation of `portfolioValue = capital + totalEarned` | **E / F** | Display authoritative backend ledger account balances. |
| `src/components/dashboard/DashboardHistory.tsx` | Synthetic monthly payout loops based on date diffs | **E / F** | Display actual scheduled/paid records from `payouts` table. |
| `src/components/dashboard/DashboardWithdraw.tsx` | Client-side 1-year date arithmetic for `unlockedCapital` | **E / F** | Read `UNLOCKED_CAPITAL` and `LOCKED_CAPITAL` financial accounts from PostgreSQL. |

---

## 3. Removal & Remediation Strategy

1. **Zero Runtime Mock Products**: All catalogue items served exclusively from PostgreSQL `products` table via `ProductService`.
2. **Zero Client-Side Financial Calculations**: Pricing multiplier (0.86), 7% return rates, and minimums calculated server-side in `PricingService`.
3. **No Fake Settlement in Production**: No frontend simulated payment; `PaymentTransaction` remains in `PENDING` status awaiting Phase 6 real provider integration.
4. **Authoritative Ledger as Single Source of Truth**: User balances derived directly from `financial_accounts` and balanced `ledger_entries`.
