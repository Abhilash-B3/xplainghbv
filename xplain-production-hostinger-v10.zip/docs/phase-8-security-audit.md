# Phase 8.3 — Security, RBAC & Balance Immutability Audit

## 1. Role-Based Access Control (RBAC) Permission Matrix

| Capability / Route | `INVESTOR` | `SUPPORT` | `ADMIN` | `SUPERADMIN` |
|---|---|---|---|---|
| View own investments, returns, referrals | ✅ Allowed | ✅ Allowed | ✅ Allowed | ✅ Allowed |
| Request withdrawal & manage destinations | ✅ Allowed | ✅ Allowed | ✅ Allowed | ✅ Allowed |
| Access `/api/v1/admin/*` | ❌ 403 Forbidden | ✅ Allowed | ✅ Allowed | ✅ Allowed |
| Read users, investments & audit logs | ❌ 403 Forbidden | ✅ Allowed (Read) | ✅ Allowed | ✅ Allowed |
| Approve / reject withdrawals | ❌ 403 Forbidden | ❌ 403 Forbidden | ✅ Allowed | ✅ Allowed |
| Settle completed withdrawals with proof | ❌ 403 Forbidden | ❌ 403 Forbidden | ✅ Allowed | ✅ Allowed |
| Update user role / privileged system config | ❌ 403 Forbidden | ❌ 403 Forbidden | ❌ 403 Forbidden | ✅ Allowed |
| **Arbitrary direct balance modification** | ❌ **PROHIBITED** | ❌ **PROHIBITED** | ❌ **PROHIBITED** | ❌ **PROHIBITED** |

---

## 2. Invariable Rule: Complete Balance Immutability

### Architectural Proof
1. **Schema Level**: The PostgreSQL table `FinancialAccount` contains **zero mutable balance columns** (`balance` does not exist as a column).
2. **Ledger Level**: Balances are calculated dynamically on-demand from double-entry `LedgerEntry` records (`sum(CREDIT) - sum(DEBIT)` for liabilities/equity, `sum(DEBIT) - sum(CREDIT)` for assets).
3. **Write Path Level**: All balance modifications must pass through `LedgerService.postTransaction`, which strictly enforces:
   - Atomic database transactions.
   - At least 2 balanced entries.
   - Exact mathematical equality: $\sum \text{Debits} == \sum \text{Credits}$.
   - Strictly positive entry amounts.
   - Immutable audit trail.

---

## 3. Insecure Direct Object References (IDOR) Audit

| Resource | Protected Entity | Enforcement Mechanism |
|---|---|---|
| **Bank Accounts** | `BankAccount` | Checked against `req.user.partnerProfile.id` in `DestinationService.deleteBankAccount`. |
| **MoMo Accounts** | `MoMoAccount` | Checked against `req.user.partnerProfile.id` in `DestinationService.deleteMoMoAccount`. |
| **Withdrawals** | `Withdrawal` | Checked against `req.user.partnerProfile.id` in `WithdrawalService.cancelWithdrawal`. |
| **Notifications** | `Notification` | Checked against `req.user.id` in `NotificationService.markAsRead`. |
| **Investments** | `Investment` | Filtered strictly by `partnerProfileId` in user queries. |

---

## 4. Web & Session Security Controls
- **Helmet**: Secures HTTP headers (`X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Strict-Transport-Security`).
- **CORS Policy**: Whitelist-only origin checking (`FRONTEND_URL`), blocking unauthorized cross-origin requests.
- **Session Cookies**:
  - `HttpOnly: true` (inaccessible to JavaScript, immune to XSS theft).
  - `SameSite: 'lax'` (protects against CSRF).
  - `Secure: true` in production environments (HTTPS transmission only).
- **Sensitive Data Masking**: Bank account numbers and mobile money phone numbers are masked (`•••• 7890`).
