# PHASE 3 — REPOSITORY AUDIT & BACKEND FOUNDATION BLUEPRINT

**Project:** Xplain GH BV Investment Platform  
**Phase:** Phase 3 — Real Backend & Database Foundation  
**Target Hosting:** Hostinger (Standalone Node.js / Express Server + PostgreSQL + Redis)  
**Date:** September 2026

---

## 1. Existing Architecture Overview

The repository currently consists of:
1. **Frontend (`src/`):** React 18, TypeScript, Vite 5, Tailwind CSS, Recharts, TanStack Query (prepared), Lucide React.
2. **Database Foundation (`prisma/`):** PostgreSQL Prisma schema (`prisma/schema.prisma`), Prisma 7 datasource config (`prisma.config.ts`), comprehensive seed script (`prisma/seed.ts`), and `.env.example`.
3. **Mock & Client State:** In-memory mock datasets in `src/mock/` (`products.ts`, `appliances.ts`, `partners.ts`, `referrals.ts`, `legal.ts`) and `localStorage` persistence in `src/services/partnerService.ts`.

---

## 2. Existing Backend & API Status

- **Status Prior to Phase 3:** No real Express backend server existed; the frontend functioned as a client-only single page application with client-side state management.
- **Goal in Phase 3:** Establish a clean, production-grade **Node.js + Express + TypeScript + Prisma + PostgreSQL + Redis** backend with strict validation, centralized error handling, structured logging, request IDs, rate limiting, and a live database-backed health check (`GET /api/v1/health`).

---

## 3. Comprehensive Mock & Client-Side Simulation Audit

| Occurrence Location | Type / Finding | Classification | Phase Action / Migration Path |
| :--- | :--- | :--- | :--- |
| `src/mock/products.ts` | 22+ Xplain appliances catalog with ex-works EUR pricing | **Seed Data / Frontend Fallback** | Used in `prisma/seed.ts`. Kept in frontend as fallback until Phase 5 (Products API integration). |
| `src/mock/appliances.ts` | 6 Landing page showcase items | **Seed Data / Static CMS Content** | Seeded in `ShowcaseAppliance` table; frontend consumes until CMS API. |
| `src/mock/partners.ts` | James Thornton demo investor profile | **Dev Seed / Runtime Demo Mock** | Seeded in database for dev. Frontend auth will replace this in Phase 4 (Auth API). |
| `src/mock/referrals.ts` | 4 hardcoded referral history records | **Runtime UI Mock** | Will be completely replaced by real `GET /api/v1/referrals/referees` in Phase 10. |
| `src/mock/legal.ts` | 4 Legal policies (Privacy, Cookies, Terms, Safeguarding) | **Seed Data / Static Content** | Seeded in `LegalDocument` & `LegalVersion` tables. |
| `src/services/partnerService.ts` | `localStorage` getItem/setItem for partner profile & batches | **Client Persistence (Temporary)** | To be replaced by authenticated session API client (`useAuth`, `usePartnerQuery`) in Phase 4/12. |
| `src/services/productService.ts` | In-memory filtering of products | **Client Service (Temporary)** | To be replaced by React Query hook `useProductsQuery` calling `GET /api/v1/products` in Phase 5. |
| `src/components/forms/AuthForm.tsx` | `setTimeout` & hardcoded `james.thornton@email.com` / `demo1234` | **Simulated Auth (To Remove)** | Will be replaced by real `POST /api/v1/auth/login` and `POST /api/v1/auth/register` in Phase 4. |
| `src/components/payments/PaymentStep.tsx` | `setTimeout` pretending to charge MoMo / Card | **Simulated Payment (To Remove)** | Will be replaced by real gateway intents and webhooks in Phase 7. |
| `src/components/dashboard/DashboardReferral.tsx` | Mapping `MOCK_REFERRALS` | **Mock UI Data** | Will connect to real referral endpoints in Phase 10. |

---

## 4. Security & Architectural Deficiencies Identified

1. **Client-Side Financial Calculations:** Investment line-item pricing, 14% Option B discounts, and 7% monthly yield projections currently compute in React state. *Server must become the authoritative calculation engine.*
2. **Missing Backend Application Layer:** No unified Express application, request logging, or CORS gateway was active.
3. **Unvalidated Environment Configuration:** Lack of runtime Zod validation for server secrets (`DATABASE_URL`, `SESSION_SECRET`, `PORT`, etc.).
4. **CORS Vulnerability Risk:** Need explicit whitelist origin mapping (`FRONTEND_URL`) to prevent cross-origin injection.
5. **Lack of Centralized Error Propagation:** Need strongly typed application error handling (`AppError`) to prevent internal database queries or stack traces leaking to clients.

---

## 5. Required Implementation Plan for Phase 3

### A. Directory Structure
```
backend/
├── src/
│   ├── config/
│   │   ├── env.ts             # Zod-validated environment configuration
│   │   ├── database.ts        # Prisma Client singleton with connection check & graceful disconnect
│   │   └── redis.ts           # Redis connection abstraction (ioredis)
│   ├── controllers/
│   │   └── health.controller.ts # Real database-backed health check controller
│   ├── middleware/
│   │   ├── errorHandler.ts    # Centralized typed error handler (AppError, Prisma error mapping)
│   │   ├── notFound.ts        # 404 handler for unmatched routes
│   │   ├── requestId.ts       # UUIDv4 request ID header injector
│   │   ├── rateLimiter.ts     # Express-rate-limit security middleware
│   │   ├── logging.ts         # Structured HTTP request logger
│   │   └── validate.ts        # Zod input validation middleware
│   ├── routes/
│   │   ├── index.ts           # Root v1 router (/api/v1)
│   │   └── health.routes.ts   # /api/v1/health endpoints
│   ├── services/
│   │   ├── health.service.ts  # Database connection ping & latency evaluation
│   │   └── audit.service.ts   # Reusable audit logging service
│   ├── utils/
│   │   ├── apiResponse.ts     # Standardized JSON response envelope
│   │   ├── appError.ts        # Typed application error hierarchy
│   │   ├── logger.ts          # Structured logger utility
│   │   └── transaction.ts     # Prisma transaction isolation helper
│   ├── types/
│   │   └── index.ts           # Shared backend TypeScript types
│   ├── app.ts                 # Express app initialization & middleware stack
│   └── server.ts              # HTTP server listener & graceful shutdown handlers
├── tests/
│   ├── health.test.ts         # Automated health endpoint & DB check tests
│   └── error.test.ts          # Automated centralized error handling & 404 tests
└── tsconfig.json              # Strict TypeScript configuration for backend
```

### B. Files to Create in Phase 3
- `backend/src/config/env.ts`
- `backend/src/config/database.ts`
- `backend/src/config/redis.ts`
- `backend/src/controllers/health.controller.ts`
- `backend/src/middleware/errorHandler.ts`
- `backend/src/middleware/notFound.ts`
- `backend/src/middleware/requestId.ts`
- `backend/src/middleware/rateLimiter.ts`
- `backend/src/middleware/logging.ts`
- `backend/src/middleware/validate.ts`
- `backend/src/routes/index.ts`
- `backend/src/routes/health.routes.ts`
- `backend/src/services/health.service.ts`
- `backend/src/services/audit.service.ts`
- `backend/src/utils/apiResponse.ts`
- `backend/src/utils/appError.ts`
- `backend/src/utils/logger.ts`
- `backend/src/utils/transaction.ts`
- `backend/src/types/index.ts`
- `backend/src/app.ts`
- `backend/src/server.ts`
- `backend/tsconfig.json`
- `backend/tests/health.test.ts`
- `backend/tests/error.test.ts`
- `docs/PHASE_3_REPOSITORY_AUDIT.md`
- `docs/PHASE_3_BACKEND_ARCHITECTURE.md`
- `docs/HOSTINGER_DEPLOYMENT_NOTES_PHASE_3.md`
- `docs/PHASE_3_COMPLETION_REPORT.md`

### C. Files to Modify in Phase 3
- `package.json` — Add backend scripts (`backend:dev`, `backend:build`, `backend:test`, `start`), dependencies (`express`, `helmet`, `cors`, `zod`, `express-rate-limit`, `ioredis`, `supertest`, `jest`, etc.).
- `.env.example` — Ensure complete coverage of all validated environment keys.

---

## 6. Hostinger Deployment Alignment
The backend will run as a standard standalone Node.js process (Node 18+ or 20+) managed by PM2 or Hostinger Node.js Application Manager, connecting to PostgreSQL over standard TCP and exposing `/api/v1` behind Nginx reverse proxy or direct port mapping.
